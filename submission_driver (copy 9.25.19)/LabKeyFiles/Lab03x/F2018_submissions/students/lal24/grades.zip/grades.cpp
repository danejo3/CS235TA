/*A-Breg*/

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <algorithm> //for counting the number of a particular character in a string

using namespace std;

/** Function to calculate & return exam letter grades based on class average grade */
char calculateLetter(const double &grade, const double &avg) {
	double diff = 0.0;
	diff = grade - avg;
	char letterGrade = 'X';
	const double GRADE_A = 15.0;
	const double GRADE_B = 5.0;
	const double GRADE_C = -5.0;
	const double GRADE_D = -15.0;
	if (diff >= GRADE_A) {
		letterGrade = 'A';
	}
	else if (diff > GRADE_B) {
		letterGrade = 'B';
	}
	else if (diff > GRADE_C) {
		letterGrade = 'C';
	}
	else if (diff >= GRADE_D) {
		letterGrade = 'D';
	}
	else {
		letterGrade = 'E';
	}
	return letterGrade;
}

int main(int argc, char *argv[]) {

	const int NAME_WIDTH = 20;
	const int GRADE_PR = 0;
	const int AVG_PR = 1;
	const int GRADE_WIDTH = 6;
	const int LETTER_WIDTH = 5;

	/**Open input and output text files*/

	cout << "Input file: " << argv[1] << endl;
	ifstream inFS(argv[1]);
	if (inFS.is_open()) {

		ofstream outFS(argv[2]);
		if (outFS.is_open()) {

			/**Read in first line of text file for number of students & number of exams*/
			int num_students;
			int num_exams;
			inFS >> num_students >> num_exams;

			/**Create arrays for student names, their exam grades, and the class average*/
			string *studentNames = new string[num_students];
			string *studentSurnames = new string[num_students];
			double **examGrades = new double*[num_students];
			//make examGrades 2D
			for (int i = 0; i < num_students; ++i) {
				examGrades[i] = new double[num_exams];
			}
			double *examAverage = new double[num_exams];
			//initialize examAverage array to zero
			for (int i = 0; i < num_exams; ++i) {
				examAverage[i] = 0.0;
			}

			/**Using input text file, populate array of students names, 2D array for their exam grades,
			and an array to use for the class average; output student's names and their exam scores to a text file*/
			outFS << "Student Scores:" << endl;
			for (int i = 0; i < num_students; ++i) {
				inFS >> studentNames[i];
				inFS >> studentSurnames[i];
				studentNames[i] += " ";
				studentNames[i] += studentSurnames[i];
				outFS << setw(NAME_WIDTH) << studentNames[i] << " ";
				for (int j = 0; j < num_exams; ++j) {
					inFS >> examGrades[i][j];
					examAverage[j] += examGrades[i][j];
					outFS << setw(GRADE_WIDTH) << examGrades[i][j];
				}
				outFS << endl;
			}

			/**Close input file*/
			inFS.close();

			/**Output the average grade for the class for each exam */
			outFS << "Exam Averages:" << endl;
			for (int i = 0; i < num_exams; ++i) {
				examAverage[i] = examAverage[i] / (double)num_students;
				outFS << "    Exam " << i + 1 << " Average =   " << fixed << setprecision(AVG_PR) << examAverage[i] << endl;
			}

			/**Output students' exams with the grade letter & create an array to use to tally up the total letters for each exam*/
			string *examLetterTotal = new string[num_exams];
			outFS << "Student Exam Grades:" << endl;
			for (int i = 0; i < num_students; ++i) {
				outFS << setw(NAME_WIDTH) << studentNames[i];
				for (int j = 0; j < num_exams; ++j) {
					char gradeLetter = calculateLetter(examGrades[i][j], examAverage[j]);
					outFS << setw(GRADE_WIDTH) << fixed << setprecision(GRADE_PR) << examGrades[i][j] << "(" << gradeLetter << ")";
					examLetterTotal[j] += gradeLetter;
				}
				outFS << endl;
			}

			/**Tally and output the number of grade letters for each exam*/
			outFS << "Exam Grades:" << endl;
			for (int i = 0; i < num_exams; ++i) {
				outFS << "    Exam  " << i + 1;
				for (char x = 'A'; x < 'F'; ++x) {
					outFS << setw(LETTER_WIDTH) << count(examLetterTotal[i].begin(), examLetterTotal[i].end(), x) << "(" << x << ")";
				}
				outFS << endl;
			}

			/**Calculate class average grade*/
			double classAverage = 0.0;
			for (int i = 0; i < num_exams; ++i) {
				classAverage += examAverage[i];
			}
			classAverage = classAverage / (double)num_exams;

			/**Create array to calculate each student's average grade & initialize to zero*/
			double *studentAverage = new double[num_students];
			//initialize studentAverage array to zero
			for (int i = 0; i < num_students; ++i) {
				studentAverage[i] = 0.0;
			}

			/**Output each student's final grade and grade letter; */
			outFS << "Student Final Grades:" << endl;
			for (int i = 0; i < num_students; ++i) {
				outFS << setw(NAME_WIDTH) << studentNames[i] << "  ";
				for (int j = 0; j < num_exams; ++j) {
					studentAverage[i] += examGrades[i][j];
				}
				double averageIn = studentAverage[i] / (double)num_exams;
				char gradeLetter = calculateLetter(averageIn, classAverage);
				outFS << fixed << setprecision(AVG_PR) << averageIn << "(" << gradeLetter << ")" << endl;
			}

			/**Output the class average final grade*/
			outFS << "Class Average Score = " << fixed << setprecision(AVG_PR) << classAverage << endl;

			/**Close output file*/
			outFS.close();

			/**delete pointers*/
			delete[] examAverage;
			delete[] examLetterTotal;
			delete[] studentAverage;
			for (int i = 0; i < num_students; ++i) {
				delete[] examGrades[i];
			}
			delete[] examGrades;
			delete[] studentSurnames;
			delete[] studentNames;
		}

		else {
			cout << "Could not open " << argv[2];
		}
	}
	else {
		cout << endl << "Could not open " << argv[1];
	}
	return 0;
}