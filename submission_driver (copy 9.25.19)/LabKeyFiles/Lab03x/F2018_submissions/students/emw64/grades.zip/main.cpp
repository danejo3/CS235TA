#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cmath>
#include <iomanip>
using namespace std;
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif


int main (int argc, char* argv[]){
    VS_MEM_CHECK
    ifstream inFile (argv[1]);
	ofstream outFile(argv[2]);
	outFile << "Student Scores:" << endl;
    if (!inFile){
        cerr << "Unable to open " << argv[1] << " for input" << endl;
        //system("pause");
        return 1;
    }
    int numStudents;
    int numExams;
    inFile >> numStudents >> numExams;
    inFile.ignore(10000, '\n'); //Clear the newline left over
	string **names = new string*[numStudents];//Create a list for the names of the students
	for (int i = 0; i < numStudents; ++i) {
		names[i] = new string[2];
	}
    int **scores = new int*[numStudents]; //Initialize the list for the scores
    for(int i = 0; i < numStudents; ++i){
        scores[i] = new int[numExams];
    } //Write the names and scores from the file to the lists
    for(int i = 0; i < numStudents; ++i){
        string line;
        getline(inFile,line);
        stringstream s(line);
			outFile << '\t';
            string var;
            s >> var;
            names[i][0] = var;
            s >> var;
            names[i][1] = var;
            outFile << names[i][0] << " " << names[i][1] << " ";
            for(int j = 0; j < numExams; ++j){
                int num;
                s >> num;
                scores[i][j] = num;
                outFile << right << scores[i][j] << '\t';
            }
        outFile << endl;
        }
    inFile.close();
	outFile << "Exam Averages:" << endl;
    float *averages = new float[numExams];
    for(int i = 0; i < numExams; ++i){ //Create a list for the averages
        averages[i] = 0;
        for(int j = 0; j < numStudents; ++j){
            averages[i] += scores[j][i];
        }
        averages[i] /= numStudents;
        outFile << '\t' << "Exam " << i+1 << " Average = " << "    " << fixed << setprecision(1) << averages[i] << endl;
    }
    char **grades = new char*[numStudents]; //Initialize the list for the grades
    for(int i = 0; i < numStudents; ++i){
        grades[i] = new char[numExams];
    }
    for(int i = 0; i < numStudents; ++i){
        for(int j = 0; j < numExams; ++j){
            if(abs(scores[i][j]-averages[j]) <= 5){
                grades[i][j] = 'C';
            }
            else if(((scores[i][j] - averages[j]) < 15) && ((scores[i][j] - averages[j]) > 5)){
                grades[i][j] = 'B';
            }
            else if(((scores[i][j] - averages[j]) >= -15) && ((scores[i][j] - averages[j]) < -5)){
                grades[i][j] = 'D';
            }
            else if((scores[i][j] - averages[j]) >= 15){
                grades[i][j] = 'A';
            }
            else{
                grades[i][j] = 'E';
            }
        }
    }
	outFile << "Student Exam Grades:" << endl;
    for(int i = 0; i < numStudents; ++i){
		outFile << '\t';
        for(int j = 0; j < numExams+2; ++j){
            if(j < 2){
                outFile << right << names[i][j] << " ";
				if (j == 1){
					outFile << '\t';
				}
            }
            else{
                outFile << right << scores[i][j-2] << "(" << grades[i][j-2] << ")\t";
            }
        }
        outFile << endl;
    }
	int **counter = new int*[numExams];//Initialize a list that will count the number of letter grades
	for (int i = 0; i < numExams; ++i) {
		counter[i] = new int[5];
	}
	for (int i = 0; i < numExams; ++i) {
		for (int j = 0; j < 5; ++j) {
			counter[i][j] = 0;
		}
	}
	for (int i = 0; i < numExams; ++i) {//Counts the different grades received
		for (int j = 0; j < numStudents; ++j) {
			if (grades[j][i] == 'A') {
				counter[i][0] += 1;
			}
			else if (grades[j][i] == 'B') {
				counter[i][1] += 1;
			}
			else if (grades[j][i] == 'C') {
				counter[i][2] += 1;
			}
			else if (grades[j][i] == 'D') {
				counter[i][3] += 1;
			}
			else{
				counter[i][4] += 1;
			}
		}
	}
	outFile << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; ++i) {
		outFile << right << '\t' << "Exam " << i+1 << '\t';
		for (int j = 0; j < 5; ++j) {
			outFile << right << counter[i][j];
			if (j == 0){
				outFile << "(A)\t";
			}
			else if (j == 1){
				outFile << "(B)\t";
			}
			else if (j == 2){
				outFile << "(C)\t";
			}
			else if (j == 3) {
				outFile << "(D)\t";
			}
			else {
				outFile << "(E)\t";
			}
		}
		outFile << endl;
	}
    //system("pause");
    for(int i = 0; i < numStudents; ++i){
        delete[] scores[i];
    }
    delete[] scores;
    for(int i = 0; i < numStudents; ++i){
        delete[] grades[i];
    }
    delete[] grades;
    for(int i = 0; i < numStudents; ++i){
        delete[] names[i];
    }
    delete[] names;
    for(int i = 0; i < numExams; ++i){
        delete[] counter[i];
    }
    delete[] counter;
    delete[] averages;
    return 0;
}