/***********************************************************************************
C S 235
Lab 01: Grades
21. September 2018

Reads input file using argv[1] and after sorting the given information on
said input file, outputs the organized information to output file saved in argv[2]
************************************************************************************/

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif


#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>
using namespace std;

int main(int argc, char* argv[])
{	
	VS_MEM_CHECK;

	//cout << "Input file: " << argv[1] << endl;
	ifstream inputFile(argv[1]);

	//checking if inputFile is open
	if (!inputFile.is_open())
	{
		cerr << "Unable to open file." << endl;
		inputFile.close();
		system("pause");
		return 0;
	}
	//If the file opens . . .
	else
	{
		//extracting number of students and exams.
		int numStudents = 0;
		int numExams = 0;
		inputFile >> numStudents >> numExams;
		//inputFile.ignore(numeric_limits<int>::max(), '\n');

		//Setting up the Arrays
		int rows = numStudents;
		int cols = numExams;
		string* nameArray = nullptr;
		nameArray = new string[rows];
		double **scoreArray = new double*[rows];

		for (int i = 0; i < rows; i++)
		{
			scoreArray[i] = new double[cols];
		}
		
		for (int i = 0; i < rows; i++)
		{
			//get the names
			string nameFirst;
			string nameLast;
			inputFile >> nameFirst >> nameLast;
			string nameFull = nameFirst + " " + nameLast; //***FIXME not outputting names***
			nameArray[i] = nameFull;
			
			for (int j = 0; j < cols; j++)
			{
				//get the scores
				int score = 0;
				inputFile >> score;
				scoreArray[i][j] = score;
			}
		}
		
		inputFile.close(); //close the input file. We're done.

		//Output
		ofstream outputFile(argv[2]);
		//If the output file doesn't open . . .
		if (!outputFile.is_open())
		{
			cerr << "Unable to open file: " << argv[2] << endl;
			outputFile.close();
		}
		//If the output file cooperates . . .
		else
		{
			//Student Scores
			outputFile << "Student Scores:" << endl;
			for (int i = 0; i < rows; i++)
			{
				outputFile << fixed << setw(20) << nameArray[i] << " ";

				for (int j = 0; j < cols; j++)
				{
					outputFile << fixed << setprecision(0) << setw(6) << scoreArray[i][j] << " ";
				}
				outputFile << endl;
			}

			//Exam Averages
			double *averageArray = new double[cols];
			outputFile << "Exam Averages:" << endl;
			for (int i = 0; i < cols; i++)
			{
				outputFile << fixed << setw(10) << "Exam " << i + 1 << " Average = ";
				double sum = 0;
				for (int j = 0; j < rows; j++)
				{
					sum = sum + scoreArray[j][i];
				}

				double average = sum / rows;
				averageArray[i] = average;
				outputFile << fixed << setw(6) << setprecision(1) << average << endl;
			}

			//Student Exam Grades
			int **examArray = new int*[cols];
			for (int i = 0; i < cols; i++)
			{
				examArray[i] = new int[5];
				for (int j = 0; j < 5; j++)
				{
					examArray[i][j] = 0;
				}
			}
			outputFile << "Student Exam Grades:" << endl;
			for (int i = 0; i < rows; i++)
			{
				outputFile << fixed << setw(20) << nameArray[i];

				for (int j = 0; j < cols; j++)
				{
					outputFile << fixed << setw(6) << setprecision(0) << scoreArray[i][j];
					const double FIFTEEN = 15.0;
					const double FIVE = 5.0;
					//outputFile << "****" << averageArray[j] << "****";

					//If the test score is greater than the average
					/*
					if (scoreArray[i][j] > (averageArray[i] + FIFTEEN)) // A
					{
						outputFile << "(A)";
						examArray[j][0]++;
					}
					else if (scoreArray[i][j] < (averageArray[i] - FIFTEEN)) // E
					{
						outputFile << "(E)";
						examArray[j][4]++;
					}
					else if ((scoreArray[i][j] <= (averageArray[i] + 15)) && (scoreArray[i][j] > (averageArray[i] + 5)))
					{
						outputFile << "(B)";
						examArray[j][1]++;
					}
					else if ((scoreArray[i][j] >= (averageArray[i] - 15)) && (scoreArray[i][j] < (averageArray[i] - 50)))
					{
						outputFile << "(D)";
						examArray[j][3]++;
					}
					else
					{
						outputFile << "(C)";
						examArray[j][2]++;
					}*/
					
					if (scoreArray[i][j] > averageArray[j])
					{
						if (scoreArray[i][j] > (averageArray[j] + FIFTEEN))
						{
							outputFile << "(A)";
							examArray[j][0]++;
						}
						else if (scoreArray[i][j] > (averageArray[j] + FIVE))
						{
							outputFile << "(B)";
							examArray[j][1]++;
						}
						else
						{
							outputFile << "(C)";
							examArray[j][2]++;
						}
					}
					//If the test score is less than the average
					else
					{
						if (scoreArray[i][j] < (averageArray[j] - FIFTEEN))
						{
							outputFile << "(E)";
							examArray[j][4]++;
						}
						else if (scoreArray[i][j] > (averageArray[j] - FIVE))
						{
							outputFile << "(C)";
							examArray[j][2]++;
						}
						else
						{
							outputFile << "(D)";
							examArray[j][3]++;
						}
					}		
				}


				outputFile << endl;
			}

			//Exam Grades
			outputFile << "Exam Grades:" << endl;
			for (int i = 0; i < cols; i++)
			{
				outputFile << fixed << setw(8) << "Exam " << i + 1 << " ";
				outputFile << fixed << setw(6) << examArray[i][0] << "(A) ";
				outputFile << fixed << setw(6) << examArray[i][1] << "(B) ";
				outputFile << fixed << setw(6) << examArray[i][2] << "(C) ";
				outputFile << fixed << setw(6) << examArray[i][3] << "(D) ";
				outputFile << fixed << setw(6) << examArray[i][4] << "(E) ";
				outputFile << endl;
			}

			delete[] averageArray;
			for (int i = 0; i < cols; i++)
			{
				delete[] examArray[i];
			}
			delete[] examArray;
		}
		
		outputFile.close();

		for (int i = 0; i < rows; ++i)
		{
			delete[] scoreArray[i];
		}
		delete[] scoreArray;
		delete[] nameArray;

	}
	//system("pause");
	return 0;
}