/*Dennis Rodman
I used a dynamically allocated array to hold average scores for each exam.
That seemed like a good way to handle the grade assignment for the 
"Student Exam Grades" section. I also used a function to assign grades
with params of average for that exam/final score and each student's score.
*/

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <sstream>
using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

/*This function is passed the average score on an exam or overall
and the score a student received on that thing, then returns their letter grade*/

string calculateScore(const double average, const double score)
{
	if ((score - average) < -15) return "E";
	else if ((score - average) > 15) return "A";
	else if ((score - average) < -5 && (score - average) > -15) return "D";
	else if ((score - average) > 5 && (score - average) < 15) return "B";
	else if ((score - average) <= 5 && (score - average) >= -5) return "C";
	else return "Q";
}

int main(int argc, char* argv[])
{
	VS_MEM_CHECK

	if (argc < 3)
	{
		cout << "Too few files";
		return 1;
	}
	ifstream in (argv[1]);
	if (!in)
	{
		cout << "Unable to open " << argv[1] << " for input.";
		return 2;
	}
	ofstream out (argv[2]);
	if (!out)
	{
		in.close();
		cout << "Unable to open " << argv[2] << " for output.";
		return 3;
	}

	int numStudents;
	int numExams;
	in >> numStudents >> numExams;
	in.ignore(10000, '\n');
	int **scoreArray = new int*[numStudents];
	for (int i = 0; i < numStudents; i++)
	{
		scoreArray[i] = new int[numExams];
	}
	string* nameArray = new string[numStudents];	
		
	for (int i = 0; i < numStudents; i++)
	{
		int position = 0;
		string line;
		string studentName;
		string studentScores;

		getline(in, line);
		while (!isdigit(line[position])) ++position;
		studentName = line.substr(0, position);	//studentName only takes name, does not affect line		
		nameArray[i] = studentName;
		line = line.substr(position);			//line only contains exam scores after this
		istringstream iss(line);
		for (int j = 0; j < numExams; j++)
		{
			iss >> scoreArray[i][j];
		}
	}

	out << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; i++)
	{
		out << setw(20) << nameArray[i] << " ";
		for (int j = 0; j < numExams; j++) 
		{
			out << fixed << setprecision(0) << setw(6) << scoreArray[i][j];
		}
		out << endl;
	}

	double *examAvgArray = new double[numExams];

	out << "Exam Averages:" << endl;
	for (int i = 0; i < numExams; i++)
	{
		double examSum = 0.0;
		double examAverage = 0.0;

		out << setw(15) << "Exam " << i + 1 << " Average =";
		for (int j = 0; j < numStudents; j++)
		{
			examSum += scoreArray[j][i];
		}
		examAverage = examSum / numStudents;
		examAvgArray[i] = examAverage;
		out << setw(6) << fixed << setprecision(1) << examAverage << endl;
	}

	out << "Student Exam Grades: " << endl;
	for (int i = 0; i < numStudents; i++)
	{
		out << setw(20) << nameArray[i];
		for (int j = 0; j < numExams; j++)
		{
				out << setw(6) << scoreArray[i][j] << "(" << 
					calculateScore(examAvgArray[j], scoreArray[i][j]) << ")";
		}
		out << endl;
	}

	out << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; i++)
	{
		out << setw(10) << "Exam " << i + 1;

		int numAs = 0;
		int numBs = 0;
		int numCs = 0;
		int numDs = 0;
		int numEs = 0;

		for (int j = 0; j < numStudents; j++)
		{
			if (calculateScore(examAvgArray[i], scoreArray[j][i]) == "A") numAs++;
			if (calculateScore(examAvgArray[i], scoreArray[j][i]) == "B") numBs++;
			if (calculateScore(examAvgArray[i], scoreArray[j][i]) == "C") numCs++;
			if (calculateScore(examAvgArray[i], scoreArray[j][i]) == "D") numDs++;
			if (calculateScore(examAvgArray[i], scoreArray[j][i]) == "E") numEs++;
		}
		out << setw(6) << numAs << "(A)";
		out << setw(6) << numBs << "(B)";
		out << setw(6) << numCs << "(C)";
		out << setw(6) << numDs << "(D)";
		out << setw(6) << numEs << "(E)";
		out << endl;
	}

	double classSum = 0.0;
	double classAverage = 0.0;
	
	for (int i = 0; i < numStudents; i++)		//class avg calculated
	{
		for (int j = 0; j < numExams; j++)
		{
			classSum += scoreArray[i][j];
		}
	}
	classAverage = classSum / (numStudents * numExams);

	double studentSum = 0.0;
	double studentAverage = 0.0;

	out << "Student Final Grades:" << endl;
	for (int i = 0; i < numStudents; i++)
	{
		out << setw(23) << nameArray[i];
		studentSum = 0.0;
		for (int j = 0; j < numExams; j++)		//student avg calculated
		{
			studentSum += scoreArray[i][j];
		}
		studentAverage = studentSum / numExams;
		out << fixed << setprecision(1) << studentAverage << 
			"(" << calculateScore(classAverage, studentAverage) << ")" << endl;
	}
	out << setw(20) << fixed << setprecision(1) << "Class Average Score = " << classAverage;

	for (int i = 0; i < numStudents; i++)
	{
		delete[] scoreArray[i];
	}
	delete[] scoreArray;
	delete[] nameArray;
	delete[] examAvgArray;
	in.close();
	out.close();

	return 0;
}