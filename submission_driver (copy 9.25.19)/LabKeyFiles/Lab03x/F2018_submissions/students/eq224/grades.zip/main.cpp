//
//  main.cpp
//  lab_1_grades

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#include <cmath>
using namespace std;

/*#define DEBUG_NEW new(__FILE__, __LINE__)
#define new DEBUG_NEW*/

void ExamAverages(int num_exams, int num_students, double** scores, double* &exam_averages, ofstream &out) {
    out << "Exam Averages:" << endl;
    for(int i = 0; i < num_exams; i++) {
        exam_averages[i] = 0;
    }
    for(int i = 0; i < num_exams; i++) {
        for(int k = 0; k < num_students; k++) {
            exam_averages[i] += scores[k][i];
        }
        exam_averages[i] = exam_averages[i]/num_students;
    }
    for(int i = 0; i < num_exams; i++) {
        out << std::setw(20);
        out << "Exam " << i + 1 << " Average = \t";
        out << std::fixed << std::setprecision(1) << exam_averages[i] << endl;
    }
}

void StudentScores(int num_exams, int num_students, double** scores, string names[], ofstream &out) {
    out << "Student Scores:" << endl;
    for(int i = 0; i < num_students; i++) {
        out << std::setw(20);
        out << names[i] << "\t";
        for(int k = 0; k < num_exams; k++) {
            out << std::fixed << std::setprecision(0) << std::setw(3);
            out << scores[i][k] << "\t";
        }
        out << endl;
    }
}
string ExamGrade(double difference, int exam, int** &grades) {
    if(difference <= 5 && difference > -5) {
        grades[exam][2]++;
        return "C";
    }
    else if(difference > 5 && difference < 15) {
        grades[exam][1]++;
        return "B";
    }
    else if(difference <= -5 && difference > -15) {
        grades[exam][3]++;
        return "D";
    }
    else if(difference >= 15) {
        grades[exam][0]++;
        return "A";
    }
    else if(difference <= -15){
        grades[exam][4]++;
        return "E";
    }
    cout << "error:  " << difference << endl;
    return "error";
}
string TotalGrade(double difference) {
    if(difference <= 5 && difference > -5) {
        //cout << "Difference: " << difference << endl;
        return "C";
    }
    else if(difference >= 5 && difference < 15) {
        //cout << "Difference: " << difference << endl;
        return "B";
    }
    else if(difference <= -5 && difference > -15) {
        return "D";
    }
    else if(difference >= 15) {
        return "A";
    }
    else if(difference <= -15){
        return "E";
    }
    cout << "error:  " << difference << endl;
    return "error";
}
void ExtraCredit(int num_students, double* student_averages, string names[], ofstream &out) {
    double classAverage = 0;
    double difference = 0;
    for(int i = 0; i < num_students; i++) {
        classAverage += student_averages[i];
    }
    classAverage = classAverage/((double)num_students);
    out << "Student Final Grades:" << endl;
    for(int i = 0; i < num_students; i++) {
        difference = student_averages[i] - classAverage;
        out << std::setw(20) << names[i] << "\t";
        out << std::setprecision(1) << student_averages[i];
        out << "(" << TotalGrade(difference) << ")" << endl;
    }
    out << "Class Average Score = " << classAverage << endl;
}
int** StudentExamGrades(int num_exams, int num_students, string names[], double** scores, double* exam_averages, ofstream &out) {
    out << "Student Exam Grades:" << endl;
    double difference = 0;
    int** grades = new int*[num_exams];
    int num_of_possible_grades = 5;
    for(int k = 0; k < num_exams; k++) {
        grades[k] = new int[num_of_possible_grades];
        for(int j = 0; j < num_of_possible_grades; j++) {
            grades[k][j] = 0;
        }
    }
    for(int i = 0; i < num_students; i++) {
        out << std::setw(20);
        out << names[i] << "\t";
        for(int k = 0; k < num_exams; k++) {
            difference = scores[i][k] - exam_averages[k];
            out << std::fixed << std::setprecision(0) << std::setw(3) << scores[i][k];
            out << "(" << ExamGrade(difference, k, grades) << ")";
            out << "\t";
        }
        out << endl;
    }
    return grades;
}
double* ExamGradeCount(int num_exams, int num_students, int** &grades, const string letter_grades[], double** scores, ofstream &out) {
    out << "Exam Grades:" << endl;
    int num_of_possible_grades = 5;
    for(int i = 0; i < num_exams; i++) {
        out << std::setw(20) << "Exam\t" << i + 1 << "\t";
        for(int k = 0; k < num_of_possible_grades; k++) {
            out << grades[i][k] << "(" << letter_grades[k] << ")" << "\t";
        }
        out << endl;
    }
    double* student_averages = new double[num_students];
    for(int i = 0; i < num_students; i++) {
        student_averages[i] = 0;
    }
    
    for(int i = 0; i < num_students; i++) {
        for(int k = 0; k < num_exams; k++) {
            student_averages[i] += scores[i][k];
        }
        student_averages[i] = student_averages[i]/((double)num_exams);
    }
    return student_averages;
}
int main(int argc, char* argv[]) {
    //testing the file input and sending an error back if it doesn't work
    if (argc < 3) {
        cerr << "Please provide name of input and output files";
        return 1;
    }
    //cout << "Input file: " << argv[1] << endl;
    ifstream in(argv[1]);
    if (!in) {
        cerr << "Unable to open " << argv[1] << " for input" << endl;
        return 2;
    }
    //cout << "Output file: " << argv[2] << endl;
    ofstream out(argv[2]);
    if (!out) {
        in.close();
        cerr << "Unable to open " << argv[2] << " for output";
        return 3;
    }
    
    int num_students;
    int num_exams;
    in >> num_students >> num_exams;
    in.ignore(std::numeric_limits<int>::max(), '\n');
    string line;
    int index = 0;
    string* names = new string[num_students];
    double** scores = new double*[num_students];
    double score = 0;
    string firstName = "";
    string lastName = "";
    while(!in.eof()) {
        getline(in, line);
        istringstream iss(line);
        iss >> firstName;
        iss >> lastName;
        names[index] = firstName + " " + lastName;
        scores[index] = new double[num_exams];
        
        for(int i = 0; i < num_exams; i++) {
            iss >> score;
            scores[index][i] = score;
        }
        index++;
    }
    double* exam_averages = new double[num_exams];
    StudentScores(num_exams, num_students, scores, names, out);
    ExamAverages(num_exams, num_students, scores, exam_averages, out);
    int** grades = StudentExamGrades(num_exams, num_students, names, scores, exam_averages, out);
    const string letter_grades[] = {"A", "B", "C", "D", "E"};

    double* student_averages = ExamGradeCount(num_exams, num_students, grades, letter_grades, scores, out);
    
    ExtraCredit(num_students, student_averages, names, out);
    for(int i = 0; i < num_exams; i++) {
        delete [] grades[i];
    }
    delete [] grades;
    delete [] student_averages;
    delete [] names;
    for(int i = 0; i < num_students; i++) {
        delete [] scores[i];
    }
    delete [] scores;
    delete [] exam_averages;
    return 0;
}
