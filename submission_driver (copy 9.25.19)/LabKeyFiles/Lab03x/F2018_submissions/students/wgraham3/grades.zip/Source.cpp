#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;

int main(int argc, char* argv[])
{
	VS_MEM_CHECK

	int numStudents;
	int numExams;

	ifstream inFile;
	ofstream outFile;

	inFile.open(argv[1]);
	outFile.open(argv[2]);

	//readfile
	inFile >> numStudents >> numExams;

	//creating 2-d array for scores
	int** gradesArray = new int*[numStudents];
	for (int i = 0; i < numStudents; ++i)
	{
		gradesArray[i] = new int[numExams];
	}

	//creating dynamic student names array
	string* studentNames = new string[numStudents];
	float* examAvgs = new float[numExams];
	//vector<float> examAvgs;

	string firstName;
	string lastName;

	//read data into correct arrays
	for (int i = 0; i < numStudents; ++i)
	{
		inFile >> firstName >> lastName;
		studentNames[i] = firstName + " " + lastName;
		for (int j = 0; j < numExams; ++j)
		{
			inFile >> gradesArray[i][j];
		}
	}

	// print first section
	outFile << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		outFile << studentNames[i] << " ";
		for (int j = 0; j < numExams; ++j)
		{
			outFile << gradesArray[i][j] << " ";
		}
		outFile << endl;
	}

	// print 2nd section
	float examAvg;
	float examSum;

	outFile << "Exam Averages:" << endl;
	
	for (int i = 0; i < numExams; ++i)
	{
		examAvg = 0;
		examSum = 0;
		for (int j = 0; j < numStudents; ++j)
		{
			examSum += gradesArray[j][i];
		}
		examAvg = examSum / numStudents;
		outFile << "Exam " << i + 1 << " Average =   ";
		outFile << fixed << setprecision(1) << examAvg << endl;
		examAvgs[i] = examAvg;
	}
	
	char letterGrade;
	int numGrades;
	numGrades = 5; //magic num

	int** examBreakdowns = new int*[numExams];
	for (int i = 0; i < numExams; ++i)
	{
		examBreakdowns[i] = new int[numGrades];
	}

	for (int i = 0; i < numExams; ++i)
	{
		for (int j = 0; j < numGrades; ++j)
		{
			examBreakdowns[i][j] = 0;
		}
	}

	outFile << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		outFile << studentNames[i] << "     ";
		for (int j = 0; j < numExams; ++j)
		{
			if (gradesArray[i][j] > examAvgs[j])
			{
				if ((gradesArray[i][j] - examAvgs[j]) >= 15) //magic number
				{
					letterGrade = 'A';
					examBreakdowns[j][0] += 1;
				}
				else if ((gradesArray[i][j] - examAvgs[j]) > 5)
				{
					letterGrade = 'B';
					examBreakdowns[j][1] += 1;
				}
				else
				{
					letterGrade = 'C';
					examBreakdowns[j][2] += 1;
				}
			}
			else
			{
				if ((examAvgs[j] - gradesArray[i][j]) >= 15)
				{
					letterGrade = 'E';
					examBreakdowns[j][4] += 1;
				}
				else if ((examAvgs[j] - gradesArray[i][j]) > 5)
				{
					letterGrade = 'D';
					examBreakdowns[j][3] += 1;
				}
				else
				{
					letterGrade = 'C';
					examBreakdowns[j][2] += 1;
				}
			}
			outFile << gradesArray[i][j] << "(" << letterGrade << ")";
			outFile << "     ";
		}
		outFile << endl;
	}

	outFile << "Exam Grades:";
	for (int i = 0; i < numExams; ++i)
	{
		outFile << endl << "     Exam " << i + 1 << "     ";
		for (int j = 0; j < numGrades; ++j)
		{
			outFile << examBreakdowns[i][j];
			if (j == 0)
			{
				outFile << "(A)     ";
			}
			else if (j == 1)
			{
				outFile << "(B)     ";
			}
			else if (j == 2)
			{
				outFile << "(C)     ";
			}
			else if (j == 3)
			{
				outFile << "(D)     ";
			}
			else
			{
				outFile << "(E)     ";
			}
		}
	}

	/*
	float finalAvg;
	float finalSum;
	float** finalAvgArray = new float*[numStudents];
	float classFinalSum;
	float classFinalAvg; 

	outFile << "Student Final Grades:" << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		finalAvg = 0;
		finalSum = 0;
		outFile << studentNames[i] << "   ";
		for (int j = 0; j < numExams; ++j)
		{
			finalSum += gradesArray[i][j];
		}
		finalAvg = finalSum / numExams;
		finalAvgArray[i] = finalAvg;
		outFile << finalAvg << endl;
		classFinalSum += finalAvg; 
	}

	classFinalSum = 
	outFile << "Class Average Score = " << classFinalAvg;
	*/

	delete [] studentNames;
	delete [] examAvgs;
	for (int i = 0; i < numExams; ++i)
	{
		delete examBreakdowns[i];
	}
	delete [] examBreakdowns;
	for (int i = 0; i < numStudents; ++i)
	{
		delete gradesArray[i];
	}
	delete [] gradesArray;
	
	return 0;
}