#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

//void gradeReader(int argc, char* argv[])
//{
//	// check that the files open
//	if (argc < 3)
//	{
//		cerr << "Please provide name of input and output files";
//		return;
//	}
//
//	cout << "Input file: " << argv[1] << endl;
//	ifstream in(argv[1]);
//	if (!in)
//	{
//		cerr << "Unable to open input file" << argv[1];
//		return;
//	}
//
//	cout << "Output file: " << argv[2] << endl;
//	ofstream out(argv[2]);
//	if (!out)
//	{
//		in.close();
//		cerr << "Unable to open output file " << argv[2];
//		return;
//	}
//
//	//initialize the multi-dimensional array
//	int num_students;
//	int num_exams;
//	in >> num_students >> num_exams;
//	in.ignore(std::numeric_limits<int>::max(), '\n');
//
//	int** examscores = new int*[num_students];
//	for (int i = 0; i < num_students; ++i)
//	{
//		examscores[i] = new int[num_exams];
//	}
//
//	//store the exam scores in the array
//	int tempgrade;
//	string line;
//	string sub_line;
//	size_t p = 0;
//	for (int i = 0; i < num_students; ++i)
//	{
//		p = 0;
//		getline(in, line);
//		while (!isdigit(line[p])) ++p;
//		sub_line = line.substr(p);
//		istringstream scores(sub_line);
//		for (int k = 0; k < num_exams; ++k)
//		{
//			scores >> examscores[i][k];
//		}
//	}
//	cout << examscores[1][2] << " " << examscores[0][0];
//	system("pause");
//}

int main(int argc, char* argv[])
{
	//check arguments and open file streams

	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}

	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open input file" << argv[1];
		return 2;
	}

	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open output file " << argv[2];
		return 3;
	}
	
	//initialize the multi-dimensional array
	int num_students;
	int num_exams;
	in >> num_students >> num_exams;
	in.ignore(std::numeric_limits<int>::max(), '\n');

	int** examscores = new int*[num_students];
	for (int i = 0; i < num_students; ++i)
	{
		examscores[i] = new int[num_exams];
	}

	//store the exam scores in the array and create array of student names
	string line;
	string sub_line;
	string first_name, last_name, full_name;
	size_t p = 0;
	string* student_names = new string[num_students];
	for (int i = 0; i < num_students; ++i)
	{
		p = 0;
		//first get the student's name
		getline(in, line);
		istringstream sstream(line);
		sstream >> first_name >> last_name;
		first_name = first_name.append(" ");
		full_name = first_name.append(last_name);
		student_names[i] = full_name;

		//get the students exam scores
		while (!isdigit(line[p])) ++p;
		sub_line = line.substr(p);
		istringstream scores(sub_line);
		for (int k = 0; k < num_exams; ++k)
		{
			scores >> examscores[i][k];
		}
	}

	//output student names and scores to file
	out << "Student Scores:" << endl;
	for (int i = 0; i < num_students; ++i)
	{
		out << setw(20) << student_names[i] << " ";

		for (int k = 0; k < num_exams; ++k)
		{
			out << fixed << setprecision(0) << setw(6) << examscores[i][k];
		}
		out << endl;
	}

	//calculate and output exam averages to file
	double exam_sum = 0;
	double* exam_avg = new double[num_exams];
	string exam_intro;
	out << endl << "Exam Averages:" << endl;
	for (int i = 0; i < num_exams; ++i)
	{
		exam_sum = 0;
		for (int k = 0; k < num_students; ++k)
		{
			exam_sum += examscores[k][i];
		}

		exam_avg[i] = exam_sum / num_students;

		exam_intro = "Exam " + to_string(i + 1) + " Average = ";

		out << setw(20) << exam_intro << setw(6) << fixed << setprecision(1) << exam_avg[i] << endl;
	}

	//calculate and output student grades to file
	string** student_grades = new string*[num_students];
	for (int i = 0; i < num_students; ++i)
	{
		student_grades[i] = new string[num_exams];
	}

	for (int i = 0; i < num_students; ++i)
	{
		for (int k = 0; k < num_exams; ++k)
		{
			if (examscores[i][k] >= exam_avg[k] + 15)
			{
				student_grades[i][k] = "A";
			}
			else if ((examscores[i][k] > exam_avg[k] + 5) && (examscores[i][k] < exam_avg[k] + 15))
			{
				student_grades[i][k] = "B";
			}
			else if ((examscores[i][k] >= exam_avg[k] - 5) && (examscores[i][k] <= exam_avg[k] + 5))
			{
				student_grades[i][k] = "C";
			}
			else if ((examscores[i][k] < exam_avg[k] - 5) && (examscores[i][k] > exam_avg[k] - 15))
			{
				student_grades[i][k] = "D";
			}
			else
			{
				student_grades[i][k] = "E";
			}
		}
	}

	out << endl << "Student Exam Grades:" << endl;
	for (int i = 0; i < num_students; ++i)
	{
		out << setw(20) << student_names[i] << " ";

		for (int k = 0; k < num_exams; ++k)
		{
			out << fixed << setprecision(0) << setw(6) << examscores[i][k] << "(" << student_grades[i][k] << ")";
		}
		out << endl;
	}


	//calculate and output letter grades for each exam to file
	int kindsofgrades = 5;
	int** exam_grades = new int*[num_exams];
	for (int i = 0; i < num_exams; ++i)
	{
		exam_grades[i] = new int[kindsofgrades];
	}


	int num_A = 0;
	int num_B = 0;
	int num_C = 0;
	int num_D = 0;
	int num_E = 0;
	for (int i = 0; i < num_exams; ++i)
	{
		num_A = 0;
		num_B = 0;
		num_C = 0;
		num_D = 0;
		num_E = 0;
		for (int k = 0; k < num_students; ++k)
		{
			if (student_grades[k][i] == "A")
			{
				num_A += 1;
			}
			else if (student_grades[k][i] == "B")
			{
				num_B += 1;
			}
			else if (student_grades[k][i] == "C")
			{
				num_C += 1;
			}
			else if (student_grades[k][i] == "D")
			{
				num_D += 1;
			}
			else if (student_grades[k][i] == "E")
			{
				num_E += 1;
			}
		}

		exam_grades[i][0] = num_A;
		exam_grades[i][1] = num_B;
		exam_grades[i][2] = num_C;
		exam_grades[i][3] = num_D;
		exam_grades[i][4] = num_E;

	}


	out << endl << "Exam Grades:" << endl;
	for (int i = 0; i < num_exams; ++i)
	{
		out << setw(20) << "Exam " << i + 1;
		out << setw(6) << exam_grades[i][0] << "(A)";
		out << setw(6) << exam_grades[i][1] << "(B)";
		out << setw(6) << exam_grades[i][2] << "(C)";
		out << setw(6) << exam_grades[i][3] << "(D)";
		out << setw(6) << exam_grades[i][4] << "(E)";
		out << endl;
	}

	system("pause");


	//delete dynamically allocated memory
	for (int i = 0; i < num_students; ++i)
	{
		delete[]examscores[i];
		delete[]student_grades[i];
	}
	for (int i = 0; i < num_exams; ++i)
	{
		delete[]exam_grades[i];
	}
	delete[]examscores;
	delete[]student_names;
	delete[]exam_avg;
	delete[]student_grades;
	delete[]exam_grades;

	return 0;
}