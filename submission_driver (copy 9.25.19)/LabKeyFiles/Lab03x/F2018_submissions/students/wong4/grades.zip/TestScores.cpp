
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
using namespace std;

int main(int argc, char* argv[])
{
	ifstream inputLab01(argv[1]);
	ofstream outputLab01(argv[2]);
	
	int num_students = 0;
	int num_exams = 0;
	
		
	if (inputLab01.is_open() && outputLab01.is_open())
	{
		inputLab01 >> num_students >> num_exams;

		string* firstName = new string[num_students];
		string* lastName = new string[num_students];
		int **testScores = new int*[num_students];

		outputLab01 << "Student Scores:" << endl;
		for (int i = 0; i < num_students; ++i)
		{
			testScores[i] = new int[num_exams];
		}
		for (int i = 0; i < num_students; ++i)
		{
			inputLab01 >> firstName[i] >> lastName[i];

			ostringstream studentFullName;
			studentFullName.str();
			studentFullName << firstName[i] << " " << lastName[i] << " ";
			outputLab01 << studentFullName.str();

			for (int j = 0; j < num_exams; ++j)
			{
				inputLab01 >> testScores[i][j];
				outputLab01 << testScores[i][j] << " ";
			}
			outputLab01 << endl;
		}

		// EXAM AVERAGES OUTPUT

		outputLab01 << "Exam Averages:" << endl;
		double* testAverages = new double[num_exams];
		int examScoreTotal = 0;

		for (int i = 0; i < num_exams; ++i)
		{
			for (int j = 0; j < num_students; ++j)
			{
				examScoreTotal += testScores[j][i];
			}
			testAverages[i] = examScoreTotal / (double)num_students; // Formula for Exam Averages
			outputLab01 << "Exam  " << i + 1 << " Average = " << fixed << setprecision(1) << testAverages[i] << endl;
			examScoreTotal = 0;
		}

		// STUDENT EXAM GRADES

		inputLab01.close();
		outputLab01.close();
	}
	return 0;
}
