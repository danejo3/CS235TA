#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <iostream>
#include <fstream>
#include <array>
#include <sstream>
#include <string>
#include <iomanip>
								// what's with the output file needed on argv[1]?
using namespace std;			// exception thrown at avg()
								// int i or j as argument for assign?

double avg(double **scores, int student_num , int j)
{
	double sum = 0;
	for (int i = 0; i < student_num; i++) // start grabbing from second exam rather than second student (see code below)
	{
		sum = sum + scores[i][j];
	}
	double average = sum / student_num; 
	return average;
}

char assign(double **scores, double average, int i, int j) // int i or j?  (see comment below)       May need  to return char letter_grade to ofstream
{
	char letter_grade;
	if (scores[i][j] <= average + 5 && scores[i][j] >= average - 5)
	{
		letter_grade = 'C';
	}
	else if (scores[i][j] > average + 5 && scores[i][j] < average + 15)
	{
		letter_grade = 'B';
	}
	else if (scores[i][j] >= average + 15)
	{
		letter_grade = 'A';
	}
	else if (scores[i][j] < average - 5 && scores[i][j] > average - 15)
	{
		letter_grade = 'D';
	}
	else if (scores[i][j] <= average - 15)
	{
		letter_grade = 'E';
	}
	return letter_grade;
} 

void print()
{
	
}

int main(int argc, char* argv[])
{
	VS_MEM_CHECK
	
	if (argc < 1)
	{
		cout << "No file name entered." << endl;;
		return -1;
	}
	
	string line;
	ifstream in_file(argv[1]);

	ofstream out_file(argv[2]);

	int student_num;
	int exam_num;

	
	if (in_file.is_open())
	{
		in_file >> student_num >> exam_num;

		const int first_and_last = 2;	// adding two to exam_num takes into account the first and last name when setting array columns

		string **names = new string*[student_num];
		for (int i = 0; i < student_num; i++)
		{
			names[i] = new string[first_and_last];
		}

		double **scores = new double*[student_num];
		for (int i = 0; i < student_num; i++)
		{
			scores[i] = new double[exam_num];
		}


		while (getline(in_file, line))
		{
			for (int i = 0; i < student_num; i++)
			{
				for (int j = 0; j < first_and_last; j++)
				{
					in_file >> names[i][j];
				}
				
				for (int j = 0; j < exam_num; j++)
				{
					in_file >> scores[i][j];
				}
			}
			
		}
	
		out_file << "Average Exam Scores:  ";
		
		for (int j = 0; j < exam_num; j++)
		{																	
			out_file << setw(8) << left << setprecision(3) << avg(scores, student_num, j) << " "; 
		}
		out_file << endl;
	
		for (int i = 0; i < student_num; i++)
		{
			for (int j = 0; j < first_and_last; j++)
			{
				out_file << setw(10) << left << names[i][j] << " ";
			}

			for (int j = 0; j < exam_num; j++)
			{
				out_file << setw(2) << left << scores[i][j] << " "
				<< "(" << assign(scores, avg(scores, student_num, j), i, j) << ")   ";
			}
			out_file << endl;
		}


																		
		for (int i = 0; i < student_num; i++) // i++ or ++i?
		{
			delete[] names[i];
		}
		delete[] names;

		for (int i = 0; i < student_num; i++)
		{
			delete[] scores[i];
		}
		delete[] scores;
	}
	else
	{
		cout << "Error.  Unable to open file " << argv[1] << "." << endl;
		return 1;
	}
	
	return 0;

}