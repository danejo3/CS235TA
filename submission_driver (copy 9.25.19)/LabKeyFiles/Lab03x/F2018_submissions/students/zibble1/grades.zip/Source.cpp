#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

using namespace std;

int main(int argc, char * argv[])
{
	VS_MEM_CHECK

	int numberStudents = 0;
	int numberExams = 0;

	ifstream input;
	input.open(argv[1]);

	ofstream output;
	output.open(argv[2]);

	input >> numberStudents >> numberExams;

	string* namesStudents = new string[numberStudents];
	double** examScores = new double*[numberStudents];
	double* avgScoresExam = new double[numberExams];

	for (int i = 0; i < numberStudents; i++)
	{
		string firstName;
		string lastName;

		examScores[i] = new double[numberExams];

		input >> firstName;
		input >> lastName;

		namesStudents[i] = firstName + " " + lastName;

		for (int j = 0; j < numberExams; j++)
		{
			input >> examScores[i][j];
		}
	}

	for (int i = 0; i < numberExams; i++)
	{
		double totalScore = 0;

		for (int j = 0; j < numberStudents; j++)
		{
			totalScore += examScores[j][i];
		}

		avgScoresExam[i] = totalScore / numberStudents;
	}

	output << "Student Scores:" << endl;

	for (int i = 0; i < numberStudents; i++)
	{
		output << setw(20) << right << namesStudents[i];

		for (int j = 0; j < numberExams; j++)
		{
			output << setw(8) << right << fixed << setprecision(0) << examScores[i][j];
		}

		output << endl;
	}
	
	output << endl << "Exam Averages:" << endl;

	for (int i = 0; i < numberExams; i++)
	{
		output << right << fixed << setprecision(1) << "Exam " << (i + 1) << " Average = " << avgScoresExam[i]<< endl;
	}

	output << endl << "Student Exam Grades:" << endl;

	for (int i = 0; i < numberStudents; i++)
	{
		output << setw(20) << right << namesStudents[i];

		for (int j = 0; j < numberExams; j++)
		{
			output << setw(8) << right << fixed << setprecision(0) << examScores[i][j];
			
			if (examScores[i][j] >= avgScoresExam[j] + 15)
			{
				output << "(A)";
			}

			else if (examScores[i][j] > avgScoresExam[j] + 5 && examScores[i][j] < avgScoresExam[j] + 15)
			{
				output << "(B)";
			}

			else if (examScores[i][j] <= avgScoresExam[j] + 5 && examScores[i][j] >= avgScoresExam[j] - 5)
			{
				output << "(C)";
			}

			else if (examScores[i][j] < avgScoresExam[j] - 5 && examScores[i][j] > avgScoresExam[j] - 15)
			{
				output << "(D)";
			}

			else if (examScores[i][j] <= avgScoresExam[j] - 15)
			{
				output << "(E)";
			}
		}

		output << endl;
	}
	
	output << endl << "Exam Grades: " << endl;

	for (int i = 0; i < numberExams; i++)
	{
		int gradesA = 0;
		int gradesB = 0;
		int gradesC = 0;
		int gradesD = 0;
		int gradesE = 0;

		for (int j = 0; j < numberStudents; j++)
		{
			if (examScores[j][i] >= avgScoresExam[i] + 15)
			{
				gradesA++;
			}

			else if (examScores[j][i] > avgScoresExam[i] + 5 && examScores[j][i] < avgScoresExam[i] + 15)
			{
				gradesB++;
			}

			else if (examScores[j][i] <= avgScoresExam[i] + 5 && examScores[j][i] >= avgScoresExam[i] - 5)
			{
				gradesC++;
			}

			else if (examScores[j][i] < avgScoresExam[i] - 5 && examScores[j][i] > avgScoresExam[i] - 15)
			{
				gradesD++;
			}

			else if (examScores[j][i] <= avgScoresExam[i] - 15)
			{
				gradesE++;
			}

		}
		output << right << fixed << setprecision(1) << "Exam " << (i+1) << " " << setw(8) << gradesA << "(A)" << "   " << gradesB << "(B)" << "   " << gradesC << "(C)" << "   " << gradesD
			<< "(D)" << "   " << gradesE << "(E)" << endl;
	}

	output << endl << "Student Final Grades:" << endl;

	double allExamTotal = 0;
	double allExamAverage = 0;

	for (int i = 0; i < numberStudents; i++)
	{
		double totalScore = 0;

		for (int j = 0; j < numberExams; j++)
		{
			totalScore += examScores[i][j];
		}

		double studentAvg = 0;
		studentAvg = totalScore / numberExams;
		allExamTotal += studentAvg;
		allExamAverage = allExamTotal / numberStudents;
	}

	for (int i = 0; i < numberStudents; i++)
	{
		double totalScore = 0;
		output << setw(20) << right << namesStudents[i];

		for (int j = 0; j < numberExams; j++)
		{
			totalScore += examScores[i][j];
		}

		double studentAvg = 0;
		studentAvg = totalScore / numberExams;
		output << setw(8) << right << fixed << setprecision(1) << " " << studentAvg;

		if (studentAvg >= allExamAverage + 15)
		{
			output << "(A)";
		}

		else if (studentAvg > allExamAverage + 5 && studentAvg < allExamAverage + 15)
		{
			output << "(B)";
		}

		else if (studentAvg <= allExamAverage + 5 && studentAvg >= allExamAverage - 5)
		{
			output << "(C)";
		}

		else if (studentAvg < allExamAverage - 5 && studentAvg > allExamAverage - 15)
		{
			output << "(D)";
		}

		else if (studentAvg <= allExamAverage - 15)
		{
			output << "(E)";
		}
		
		output << endl;
	}

	output << "Class Average Score = " << right << fixed << setprecision(1) << allExamAverage;
	
	input.close();
	output.close();

	for (int i = 0; i < numberStudents; i++)
	{
		delete[] examScores[i];
	}

	delete[] examScores;
	delete[] namesStudents;
	delete[] avgScoresExam;

	return 0;
}