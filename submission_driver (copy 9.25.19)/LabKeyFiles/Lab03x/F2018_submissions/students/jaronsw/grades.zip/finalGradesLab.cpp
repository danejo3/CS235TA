/*Grades Lab
Jaron Walker, Section 003
walkerjaron@gmail.com*/
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <math.h>
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <iomanip>

using namespace std;

int main(int argc, char*argv[])
{
	VS_MEM_CHECK
		if (argc < 3)
		{
			cerr << "Please provide name of input and output files";
			return 1;
		}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	int num_students;
	int num_exams;
	in >> num_students >> num_exams;
	in.ignore(numeric_limits<int>::max(), '\n');

	double **scores = new double*[num_students]; //allocate rows
	for (int i = 0; i < num_students; i++)
	{
		scores[i] = new double[num_exams]; // allocate columns
	}


	string *students = new string[num_students];
	for (int i = 0; i < num_students; i++)
	{
		students[i] = string();
	}

	string line;
	int cnt = 0;
	string firstName;
	string lastName;

	while (getline(in, line))
	{
		stringstream iss(line);
		iss >> firstName;
		iss >> lastName;
		for (int i = 0; i < num_exams; i++)
		{
			iss >> scores[cnt][i];
		}
		students[cnt] = string(firstName + " " + lastName);
		cnt++;
	}

	out << "Student Scores:" << endl;
	for (int i = 0; i < num_students; ++i)
	{
		out << setw(20) << students[i];
		for (int j = 0; j < num_exams; j++)
		{
			out << setw(6) << fixed << setprecision(0) << scores[i][j];
		}
		out << endl;
	}
	out << endl;

	double *examAvgs = new double[num_exams];
	for (int i = 0; i < num_students; i++)
	{
		examAvgs[i] = double();
	}

	out << "Exam Averages:" << endl;
	double total;
	for (int i = 0; i < num_exams; i++)
	{
		total = 0.0;
		for (int j = 0; j < num_students; j++)
		{
			total += scores[j][i];
		}
		examAvgs[i] = total / num_students;
	}

	for (int i = 0; i < num_exams; i++)
	{
		out << "\tExam " << i + 1 << " Average =\t" << fixed << setprecision(1) << examAvgs[i] << endl;
	}
	out << endl;


	out << "Student Exam Grades:" << endl;
	char grade;
	const int NUM_LETTER_GRADES = 5;

	int **gradeCtr = new int*[num_exams];
	for (int i = 0; i < num_exams; i++)
	{
		gradeCtr[i] = new int[NUM_LETTER_GRADES];
	}
	for (int i = 0; i < num_exams; i++)
	{
		for (int j = 0; j < NUM_LETTER_GRADES; j++)
		{
			gradeCtr[i][j] = 0;
		}
	}

	for (int i = 0; i < num_students; i++)
	{
		out << setw(20) << students[i];
		for (int j = 0; j < num_exams; j++)
		{
			if (scores[i][j] < examAvgs[j] + 5 && scores[i][j] > examAvgs[j] - 5)
			{
				grade = 'C';
			}
			else if (scores[i][j] < examAvgs[j] - 5 && scores[i][j] > examAvgs[j] - 15)
			{
				grade = 'D';
			}
			else if (scores[i][j] <= examAvgs[j] - 15)
			{
				grade = 'E';
			}
			else if (scores[i][j] >= examAvgs[j] + 15)
			{
				grade = 'A';
			}
			else if (scores[i][j] >= examAvgs[j] + 5 && scores[i][j] <= examAvgs[j] + 15)
			{
				grade = 'B';
			}
			out << fixed << setprecision(0) << setw(8) << scores[i][j] << "(" << grade << ")";
		}
		out << endl;
	}


	for (int i = 0; i < num_exams; i++)
	{
		int ctrA = 0;
		int ctrB = 0;
		int ctrC = 0;
		int ctrD = 0;
		int ctrE = 0;
		for (int j = 0; j < num_students; j++)
		{
			if (scores[j][i] < examAvgs[i] + 5 && scores[j][i] >= examAvgs[i] - 5)
			{
				++ctrC;
				gradeCtr[i][2] = ctrC;
			}
			else if (scores[j][i] < examAvgs[i] - 5 && scores[j][i] > examAvgs[i] - 15)
			{
				++ctrD;
				gradeCtr[i][3] = ctrD;
			}
			else if (scores[j][i] <= examAvgs[i] - 15)
			{
				++ctrE;
				gradeCtr[i][4] = ctrE;
			}
			else if (scores[j][i] > examAvgs[i] + 15)
			{
				++ctrA;
				gradeCtr[i][0] = ctrA;
			}
			else if (scores[j][i] >= examAvgs[j] + 5 && scores[j][i] <= examAvgs[i] + 15)
			{
				++ctrB;
				gradeCtr[i][1] = ctrB;
			}
		}
	}

	out << "Exam Grades:" << endl;
	for (int i = 0; i < num_exams; i++)
	{
		out << "\tExam	" << i + 1 << '\t';
		for (int j = 0; j < NUM_LETTER_GRADES; j++)
		{
			if (j == 0)
			{
				grade = 'A';
			}
			else if (j == 1)
			{
				grade = 'B';
			}
			else if (j == 2)
			{
				grade = 'C';
			}
			else if (j == 3)
			{
				grade = 'D';
			}
			else
			{
				grade = 'E';
			}
			out << gradeCtr[i][j] << "(" << grade << ")" << '\t';
		}
		out << endl;
	}


	double *studentGrades = new double[num_students];
	for (int i = 0; i < num_students; i++)
	{
		studentGrades[i] = double();
	}
	double classAvgScr = 0.0;

	out << "Student Final Grades:" << endl;
	for (int i = 0; i < num_students; i++)
	{
		total = 0.0;
		for (int j = 0; j < num_exams; j++)
		{
			total += scores[i][j];
		}
		studentGrades[i] = total / num_exams;
	}

	total = 0.0;
	for (int i = 0; i < num_students; i++)
	{
		total += studentGrades[i];
	}
	classAvgScr = total / num_students;

	for (int i = 0; i < num_students; i++)
	{
		out << setw(20) << students[i] << ' ';
		out << setw(6) << fixed << setprecision(1) << studentGrades[i];
		out << "(";
		if (studentGrades[i] < classAvgScr + 5 && studentGrades[i] > classAvgScr - 5)
		{
			grade = 'C';
		}
		else if (studentGrades[i] <= classAvgScr - 5 && studentGrades[i] >= classAvgScr - 15)
		{
			grade = 'D';
		}
		else if (studentGrades[i] < classAvgScr - 15)
		{
			grade = 'E';
		}
		else if (studentGrades[i] > classAvgScr + 15)
		{
			grade = 'A';
		}
		else if (studentGrades[i] >= classAvgScr + 5 && studentGrades[i] <= classAvgScr + 15)
		{
			grade = 'B';
		}
		out << grade << ")" << endl;
	}
	out << setw(21) << "Class Average Score = " << classAvgScr;
	in.close();
	out.close();


	for (int i = 0; i < num_students; ++i)
	{
		delete[] scores[i];
	}

	for (int i = 0; i < num_exams; ++i)
	{
		delete[] gradeCtr[i];
	}

	delete[] students;

	delete[] examAvgs;

	delete[] studentGrades;

	return 0;
}