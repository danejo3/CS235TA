//
//  main.cpp
//  Lab01_Grades
//
//  Created by Damyn Chipman on 9/6/18.
//  Copyright © 2018 Damyn Chipman. All rights reserved.
//

// Headers
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#include <cmath>

// Memory Checker
#ifdef _MSC_VER
  #define _CRTDBG_MAP_ALLOC
  #include <crtdbg.h>
  #define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF)
#else
  #define VS_MEM_CHECK
#endif

// Namespace
using namespace std;

// Global variables
const size_t EXTRAWHITE2 = 2;
int NSTUDENTS;
int NEXAMS;

/* float CalcExamAverage(int exam[])
 *
 * Computes the average for a given exam
 *
 * ARGUMENTS:
 *  int exam[]            - Array of size NSTUDENTS containing exam scores
 *
 * RETURNS:
 *  float avg             - Average for the given array of exam scores
 */
float CalcExamAverage(int exam[]) {
    // Calculate the sum
    float sum = 0;
    for (int i = 0; i < NSTUDENTS; i++) {
        sum += float(exam[i]);
    }
    
    // Return average
    float avg = sum/float(NSTUDENTS);
    return avg;
}

/* char CalcGrade(float studentScore, float examAvg)
 *
 * Determines the student's grade based off of the average and their score
 *
 * ARGUMENTS:
 *  float studentScore          - Student's score
 *  float examAvg               - Exam average
 *
 * RETURNS:
 *  char grad                   - Grade recieved by student
 */
char CalcGrade(float studentScore, float examAvg) {
    // Variables
    char grade;
    float diff = studentScore - examAvg; // High grade if positive, low grade if negative
    
    // Begin logic
    if (fabs(diff) <= 5.0) { // |diff| is between 0 and 5
        grade = 'C';
    }
    else if (fabs(diff) > 5.0 && fabs(diff) <= 15.0) { // |diff| is between 5 and 15
        if (diff > 0) {
            grade = 'B';
        }
        else {
            grade = 'D';
        }
    }
    else { // |diff| is larger than 15
        if (diff > 0) {
            grade = 'A';
        }
        else {
            grade = 'E';
        }
    }
    
    // Return grade
    return grade;
}

/* int main(int argc, const char* argv[])
 *
 * This program takes an input file containing names and scores of exams. The names are
 * scores are stored in dynamic arrays and different values are computed. An output file
 * is written containing the results of the computations.
 *
 * ARGUMENTS:
 *  int           argc         - Number of arguments in argv
 *  const char*   argv         - Array of pointers to pointers of arrays of char. Contains
 *                               the names of executable, input, and output files.
 *
 * RETURNS:
 *  0                          - Program ran successfully
 *  1                          - Invalid number of input and output files
 *  2                          - Unable to open input file
 *  3                          - Unable to close output file
 */
int main(int argc, const char * argv[]) {
    VS_MEM_CHECK            // check for memory leaks
    
    // Check for number of arguments
    if (argc < 3) {
        cerr << "Please provide name of input and output files." << endl;
        return 1;
    }
    
    // --- Input file processing ---
    ifstream in(argv[1]);
    
    if (!in) {
        // ERROR: Unable to open file
        cerr << "Unable to open " << argv[1] << endl;
        return 2;
    }
    else {
        // Process input file
        string line;
        size_t longestName = 0;
        
        // Read number of students and scores
        in >> NSTUDENTS >> NEXAMS;
        in.ignore(numeric_limits<int>::max(), '\n'); // Skip rest of line
        
        // Create 1D dynamic array for names
        string* names = new string[NSTUDENTS];
        
        // Create 2D dynamic array for scores
        int** scores = new int*[NSTUDENTS];
        for (int i = 0; i < NSTUDENTS; i++) {
            scores[i] = new int[NEXAMS];
        }
        
        // Processing input file:
        for (int i = 0; i < NSTUDENTS; i++) {
            getline(in,line); // Store line i in "line"
            
            size_t c = 0;
            
            
            while (!isdigit(line[c])) ++c; // Iterate until digit is reached
            
            // Create strings for names and scores to store in arrays
            string name_to_save = line.substr(0,c-EXTRAWHITE2);
            string scores_to_save = line.substr(c);
            istringstream iss(scores_to_save);
            
            // Get size of longest name for future formatting
            if (name_to_save.length() > longestName) {
                longestName = name_to_save.length();
            }
            
            // Store current name in names
            names[i] = name_to_save;
            
            // Iterate and store scores in arrays
            for (int j = 0; j < NEXAMS; j++) {
                iss >> scores[i][j];
            }
        }
        in.close();

        // --- Output file processing ---
        ofstream out(argv[2]);
        
        if (!out) {
            // ERROR: Unable to close file
            cerr << "Unable to close " << argv[2] << endl;
            return 3;
        }
        else {
            // Score summary section
            cout << "Student Scores:    " << endl;
            out << "Student Scores:    " << endl;
            for (int i = 0; i < NSTUDENTS; i++) {
                out << setw(int(longestName + EXTRAWHITE2)) << names[i];
                cout << setw(int(longestName + EXTRAWHITE2)) << names[i];
                for (int j = 0; j < NEXAMS; j++) {
                    out << setw(5) << scores[i][j];
                    cout << setw(5) << scores[i][j];
                }
                out << endl;
                cout << endl;
            }
            
            // Exam average section
            cout << "Exam Averages: " << endl;
            out << "Exam Averages: " << endl;
            int exam_scores[NSTUDENTS];
            float examAverages[NEXAMS];
            
            for (int i = 0; i < NEXAMS; i++) {
                for (int j = 0; j < NSTUDENTS; j++) {
                    exam_scores[j] = scores[j][i];
                }
                examAverages[i] = CalcExamAverage(exam_scores);
                out << setw(8) << "Exam " << i+1 << " Average =   ";
                out << fixed << setprecision(1) << examAverages[i] << endl;
                cout << setw(8) << "Exam " << i+1 << " Average =   ";
                cout << fixed << setprecision(1) << examAverages[i] << endl;
            }
            
            // Student exam grades section
            cout << "Student Exam Grades: " << endl;
            out << "Student Exam Grades: " << endl;
            for (int i = 0; i < NSTUDENTS; i++) {
                cout << setw(int(longestName + EXTRAWHITE2)) << names[i];
                out << setw(int(longestName + EXTRAWHITE2)) << names[i];
                for (int j = 0; j < NEXAMS; j++) {
                    out << setw(6) << scores[i][j] << "(" << CalcGrade(scores[i][j], examAverages[j]) << ")";
                    cout << setw(6) << scores[i][j] << "(" << CalcGrade(scores[i][j], examAverages[j]) << ")";
                }
                out << endl;
                cout << endl;
            }
            
            
            // Exam grades section
            
            // Student final grades section
            
            // Class average section
        }
        
        
        
        // Close input file
        in.close();
        
        // Delete allocated memory
        delete [] names;
        for (int i = 0; i<NSTUDENTS; i++) {
            delete [] scores[i];
        }
        delete [] scores;
    }
    
    return 0;
}
