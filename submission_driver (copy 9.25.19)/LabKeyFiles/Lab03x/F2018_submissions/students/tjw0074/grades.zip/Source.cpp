// CS 235 
// Lab 1 Grades
// Truman Welling
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <limits>

// Check for memory leaks
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;

int main(int argc, char *argv[])
{
   VS_MEM_CHECK               // enable memory leak check
   ////////////////////////////////////////////////////////////////////////////
   // Purpose of this section of Code:
   // Create a 2D array for the test scores
   // Create an array to store the names of the sudents
   ////////////////////////////////////////////////////////////////////////////
   int num_students;
   int num_exams;

   if (argc < 3)
   {
      cerr << "ERROR: Please provide name of input and output files\n";
      return 1;
   }

   cout << "The input file is " << argv[1] << endl;
   ifstream in(argv[1]);
   if (!in)
   {
      cerr << "ERROR: Unable to open " << argv[1] << " for input\n";
      return 2;
   }

   cout << "Output file: " << argv[2] << endl;
   ofstream out(argv[2]);
   if (!out)
   {
      in.close();
      cerr << "ERROR: Unable to open " << argv[2] << " for output.\n";
      return 3;
   }


   // If it was successful it takes in the values for the number of students
   // and exams and ignores the rest of the line.
   in >> num_students >> num_exams;
   in.ignore(std::numeric_limits<int>::max(), '\n');

   // Initializing the the two dimensional array that will store the student's
   // test scores. Each row will be students and each column will be a test
   // score.
   int **student_test_scores = new int*[num_students];
   for (int student_number = 0; student_number < num_students; student_number++)
   {
      student_test_scores[student_number] = new int[num_exams];
   }

   // Creating the array for the names of the students
   string *student_names = new string[num_students];

   cout << "num student:  " << num_students << "       num exams: " << num_exams << endl;
   ////////////////////////////////////////////////////////////////////////////
   // This next section of the code will address the storing of the data into 
   // the arrays.
   ////////////////////////////////////////////////////////////////////////////
   //This loop will repeat for every student and will store their scores and names into the respective arrays
   int student_number = 0;        // keeps trackof the student number, used when putting information in arrays
   string current_line;           // Initializing the string to store the line
   while (getline(in, current_line))
   {
      int test_number = 0;           // Keeps track of test number, 0 is the first entry
      stringstream line_of_info;     // Taking the string and putting it in stringstream for convenience
      line_of_info << current_line;
      string current_item;
      for (int loop_iterations = 0; loop_iterations <= (num_exams);) // num_exams because there is also a name
      {
         line_of_info >> current_item;
         // Initially storing the name in the name array
         if (!isdigit(current_item[0]) && loop_iterations < 1)
         {
            student_names[student_number] = current_item;
            loop_iterations++;
         }

         // This is to protect against names that have spaces or might have spaces
         else if (!isdigit(current_item[0]) && loop_iterations >= 1)
         {
            string first_name = student_names[student_number];
            student_names[student_number] = first_name + " " + current_item; 
            // Note there is no addition or incrementation to loop_iterations, this is because the first iteration will be 
            // used to write the name and the iterations after that will be used to input the test scores, thus if there
            // are multiple names, the loop iteration will remain at 1 until it starts getting exam scores
         }

         // To store the test scores
         else
         {
            student_test_scores[student_number][test_number] = stoi(current_item);
            test_number++;
            loop_iterations++;
         }


      }

      student_number++;

   }


   ////////////////////////////////////////////////////////////////////////////
   // This next part of the program will deal with the calculations.
   ////////////////////////////////////////////////////////////////////////////
   // First we will calculate the averages of the scores for each test
   
   // Initializing the array and setting all of the entries to 0
   float *test_score_averages = NULL;
   test_score_averages = new float[num_exams];
   for (int test_score_in_question = 0; test_score_in_question < num_exams; test_score_in_question++)
   {
      test_score_averages[test_score_in_question] = 0;
   }

   // Averaging the scores and writing them to the array
   int exam_number = 0;
   while (exam_number < num_exams)
   {
      float total_combined_test_scores = 0;
      int current_student = 0;
      while (current_student < num_students)
      {
         total_combined_test_scores += student_test_scores[current_student][exam_number];
         current_student++; // Move on to the next student
      }

      // Now taking the average
      test_score_averages[exam_number] = (total_combined_test_scores / num_students);

      // And increment the exam number and move on to the next one
      exam_number++;
   }


   // This array is for the average score of each student
   float *student_score_averages = NULL;
   student_score_averages = new float[num_students];
   for (int student_score_in_question = 0; student_score_in_question < num_students; student_score_in_question++)
   {
      student_score_averages[student_score_in_question] = 0;
   }

   // Averaging the Student's scores and storing them in an array
   for (int student_in_question = 0; student_in_question < num_students; student_in_question++)
   {
      float total_score = 0;
      for (int student_score_in_question = 0; student_score_in_question < num_exams; student_score_in_question++)
      {
         total_score += student_test_scores[student_in_question][student_score_in_question];
      }
      student_score_averages[student_in_question] = total_score / num_exams;
   }

   float average_of_all_scores = 0;
   float total_of_all_averages = 0;
   for (int exam_in_question = 0; exam_in_question < num_exams; exam_in_question++)
   {
      total_of_all_averages += test_score_averages[exam_in_question];
   }
   average_of_all_scores = total_of_all_averages / num_exams;

   ////////////////////////////////////////////////////////////////////////////
   // This section will be writing the output file
   // First it will write the averages for the exams
   // Second it will write the Students and their scores/letter grades
   // Third it will write the number of letter grades for each test
   ////////////////////////////////////////////////////////////////////////////

   // Writing the Students scores again
   out << "Student Scores: \n";
   for (int student_in_question = 0; student_in_question < num_students; student_in_question++)
   {
      out << fixed << setw(20) << student_names[student_in_question]; // The name

      // The scores (no letter grade)
      for (int exam_in_question = 0; exam_in_question < num_exams; exam_in_question++)
      {
         out << fixed << setw(6) << setprecision(1) << student_test_scores[student_in_question][exam_in_question];
      }

      out << endl;
   }


   // Writing the Average scores
   out << "Exam Averages:\n";
   for (int exam_in_question = 0; exam_in_question < num_exams; exam_in_question++)
   {
      out << "   Exam " << (exam_in_question + 1) << " Average =  " << test_score_averages[exam_in_question] << endl;
   }

   // Initializing the the two dimensional array that will store the number of each
   // letter grade. Each row will be the letter grades for the corrosponding exam
   int letter_grade_quantity = 5; // A, B, C, D, E
   const int A = 0;
   const int B = 1;
   const int C = 2;
   const int D = 3;
   const int E = 4;
   int **letter_grades_per_exam = new int*[num_exams];
   for (int exam_in_question = 0; exam_in_question < num_exams; exam_in_question++)
   {
      letter_grades_per_exam[exam_in_question] = new int[letter_grade_quantity];
   }

   // Initializing all values in the array to 0
   for (int exam_in_question = 0; exam_in_question < num_exams; exam_in_question++)
   {
      for (int desired_letter_grade = 0; desired_letter_grade < letter_grade_quantity;)
      {
         letter_grades_per_exam[exam_in_question][desired_letter_grade] = 0;
         desired_letter_grade++;
      }
   }

   // Writes the student names and their test scores, also stores the number of each letter grade in the array
   out << "Student Exam Grades:\n";
   for (int current_student = 0; current_student < num_students; current_student++)
   {
      out << right << setw(20) << student_names[current_student];
      out << fixed << setprecision(0) << setw(6) << left;


      for (int current_exam = 0; current_exam < num_exams; current_exam++)
      {
         out << fixed << setprecision(0) << setw(6) << right << student_test_scores[current_student][current_exam];

         // This next logic will determine the letter grade and write it to the output file
         if (student_test_scores[current_student][current_exam] >= (test_score_averages[current_exam] + 15))
         {
            out << fixed << setprecision(0) << setw(6) << left << "(A)";
            letter_grades_per_exam[current_exam][A]++;
         }

         else if (student_test_scores[current_student][current_exam] > (test_score_averages[current_exam] + 5)
            && student_test_scores[current_student][current_exam] < (test_score_averages[current_exam] + 15))
         {
            out << fixed << setprecision(0) << setw(6) << left << "(B)";
            letter_grades_per_exam[current_exam][B]++;
         }

         else if (student_test_scores[current_student][current_exam] >= (test_score_averages[current_exam] - 5)
            && student_test_scores[current_student][current_exam] <= (test_score_averages[current_exam] + 5))
         {
            out << fixed << setprecision(0) << setw(6) << left << "(C)";
            letter_grades_per_exam[current_exam][C]++;
         }

         else if (student_test_scores[current_student][current_exam] > (test_score_averages[current_exam] - 15)
            && student_test_scores[current_student][current_exam] < (test_score_averages[current_exam] - 5))
         {
            out << fixed << setprecision(0) << setw(6) << left << "(D)";
            letter_grades_per_exam[current_exam][D]++;
         }

         else if (student_test_scores[current_student][current_exam] <= (test_score_averages[current_exam] - 15))
         {
            out << fixed << setprecision(0) << setw(6) << left << "(E)";
            letter_grades_per_exam[current_exam][E]++;
         }
      }

      out << endl;
   }

   // The number of letter grades per exam
   out << "Exam Grades:\n";
   for (int exam_in_question = 0; exam_in_question < num_exams; exam_in_question++)
   {
      out << left << "   Exam " << (exam_in_question + 1) << fixed << setw(6)
         << setw(6) << right << letter_grades_per_exam[exam_in_question][A] << "(A)"
         << setw(6) << letter_grades_per_exam[exam_in_question][B] << "(B)"
         << setw(6) << letter_grades_per_exam[exam_in_question][C] << "(C)"
         << setw(6) << letter_grades_per_exam[exam_in_question][D] << "(D)"
         << setw(6) << letter_grades_per_exam[exam_in_question][E] << "(E)"
         << endl;
   }

   // The student Final grades and overall class average
   out << "Student Final Grades:\n";
   for (int student_in_question = 0; student_in_question < num_students; student_in_question++)
   {
      out << fixed << setw(20) << student_names[student_in_question];
      out << fixed << setw(6) << setprecision(1) << student_score_averages[student_in_question];

      // Finding the letter grade associated
      if (student_score_averages[student_in_question] >= (average_of_all_scores + 15))
      {
         out << "(A)\n";
      }

      else if (student_score_averages[student_in_question] > (average_of_all_scores + 5)
         && student_score_averages[student_in_question] < (average_of_all_scores + 15))
      {
         out << "(B)\n";
      }

      else if (student_score_averages[student_in_question] >= (average_of_all_scores - 5)
         && student_score_averages[student_in_question] <= (average_of_all_scores + 5))
      {
         out << "(C)\n";
      }

      else if (student_score_averages[student_in_question] > (average_of_all_scores - 15)
         && student_score_averages[student_in_question] < (average_of_all_scores - 5))
      {
         out << "(D)\n";
      }

      if (student_score_averages[student_in_question] <= (average_of_all_scores - 15))
      {
         out << "(E)\n";
      }
   }
   out << "Class Average Score = " << fixed << setprecision(1) << average_of_all_scores;

   out.close();

   // Deleting all of the dynamically allocatted arrays
   delete[] student_names;
   delete[] test_score_averages;
   delete[] student_score_averages;

   // Deleting 2D arrays
   for (int student_number = 0; student_number < num_students; ++student_number)
   {
      delete[] student_test_scores[student_number];
   }
   delete[] student_test_scores;
   

   for (int exam_number = 0; exam_number < num_exams; exam_number++)
   {
      delete[] letter_grades_per_exam[exam_number];
   }
   delete[] letter_grades_per_exam;
  

   return 0;
}