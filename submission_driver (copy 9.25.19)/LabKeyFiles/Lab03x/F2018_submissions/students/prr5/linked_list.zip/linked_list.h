#ifndef LINKED_LIST_H
#define LINKED_LIST_H
using std::string;
using std::ostream;
using std::stringstream;

/** Linked List */
template<typename T>
class LinkedList : public LinkedListInterface<T>
{
private:
	struct Node
	{
		T data;
		Node* next;
		Node(const T& d) : data(d), next(NULL) { }
		Node(const T& d, Node* n) : data(d), next(n) { }
		/** Node toString */
		string toString() const
		{
			stringstream out;
			out << this->data;
			return out.str();
		} // end toString()

		/** Override insertion operator */
		friend std::ostream& operator<< (ostream& os, const Node& node)
		{
			os << node.toString();
			return os;
		} // end operator<<
	};
	Node* head;

public:
	LinkedList() { this->head = NULL; }
	~LinkedList() { clear(); }

	/** Insert Node at beginning of list (no duplcates) */
	virtual bool insertHead(T value)
	{
		if (head == NULL)
		{
			head = new Node(value);
			return true;
		}
		Node* ptr = head;
		do
		{
			if (ptr->data == value) return false;
		} while ((ptr = ptr->next) != NULL);
		head = new Node(value, head);
		return true;
	}

	/** Insert Node at end of list (no duplcates) */
	virtual bool insertTail(T value)
	{
		if (head == NULL)
		{
			head = new Node(value);
			return true;
		}
		Node* ptr = head;
		while (1)
		{
			if (ptr->data == value) return false;
			if (ptr->next == NULL) break;
			ptr = ptr->next;
		}
		ptr->next = new Node(value);
		return true;
	}

	/** Insert node after matchNode (no duplcates) */
	virtual bool insertAfter(T matchNode, T value)
	{
		// empty list returns false
		if (head == NULL)
		{
			return false;
		}
		Node* ptr = head;
		// look for duplicate
		do
		{
			if (ptr->data == value) return false;
		} while ((ptr = ptr->next) != NULL);
		// find insertion point
		ptr = head;
		do
		{
			if (ptr->data == matchNode)
			{
				ptr->next = new Node(value, ptr->next);
				return true;
			}
			ptr = ptr->next;
		} while (ptr != NULL);
		return false;
	}

	/** Remove Node from list */
	virtual bool remove(T value)
	{
		// empty list returns false
		if (head == NULL)
		{
			return false;
		}
		// remove head
		if (head->data == value)
		{
			Node* temp = head->next;
			delete head;
			head = temp;
			return true;
		}
		// remove not head
		Node* ptr = head;
		while (ptr->next != NULL)
		{
			if (ptr->next->data == value)
			{
				Node* temp = ptr->next->next;
				delete ptr->next;
				ptr->next = temp;
				return true;
			}
			ptr = ptr->next;
		}
		return false;
	}

	/** Remove all Nodes from list */
	virtual bool clear()
	{
		// ??? repeatedly call remove?
		Node* ptr = head;
		while (ptr != NULL)
		{
			Node* temp = ptr->next;
			delete ptr;
			ptr = temp;
		}
		head = NULL;
		return true;
	}

	/** Return Node at index (0 based) */
	virtual bool at(int index, string& value)
	{
		if (head != NULL)
		{
			Node* ptr = head;
			// find indexed node or EOL
			while ((ptr->next != NULL) && (index > 0))
			{
				--index;
				ptr = ptr->next;
			}
			if (index == 0)
			{
				value = ptr->toString();
				return true;
			}
		}
		if (TRY_CATCH) throw string("Invalid Index");
		value = "Invalid Index";
		return false;
	}

	/** Returns the number of nodes in the list */
	virtual int size() const
	{
		int count = 0;
		Node* ptr = head;
		while (ptr != NULL)
		{
			count++;
			ptr = ptr->next;
		}
		return count;
	}


	/** Return a level order traversal of a Linked List as a string */
	//	virtual string toString() const
	string toString() const
	{
		stringstream out;
		Node* ptr = head;
		if (ptr == NULL) out << " Empty";
		else
		{
			while (ptr != NULL)
			{
				//out << " " << ptr->data;
				out << " " << ptr->toString();
				ptr = ptr->next;
			}
		}
		return out.str();
	} // end toString()

	  /** Override insertion operator to insert linked list string */
	friend std::ostream& operator<< (std::ostream& os, const LinkedList<T>& linkedList)
	{
		os << linkedList.toString();
		return os;
	} // end operator<<

#if (ITERATOR)
	  /** linked list iterator */
	class Iterator
	{
	private:
		Node* head;

	public:
		Iterator(Node* h) : head(h) {}
		bool operator!=(const Iterator& other) const { return this->head != NULL; }
		Iterator& operator++() { head = head->next; return *this; }
		Iterator operator++(int) { Iterator tmp(*this); head = head->next; return tmp; }
		T& operator*() const { return head->data; }				// dereference iterator
	};

	Iterator begin()
	{
		return LinkedList<T>::Iterator(head);
	}
	Iterator end()
	{
		return LinkedList<T>::Iterator(0);
	}
#endif
};

#endif	// LINKED_LIST_H
