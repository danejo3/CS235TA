// Linked List
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <stdlib.h>
#include <iomanip>

#define ITERATOR	1
#define TRY_CATCH	1

#include "LinkedListInterface.h"
#include "linked_list.h"
using namespace std;

#define TEST_NUM	5
#define DEBUG		0
#define ERRORS		0

#define ARGS		1
#define CONSOLE		0

#define DEBUGX(x) cout << x;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

typedef struct
{
	char* input;
	char* output;
} Tests;

Tests tests[] = { { "lab04_in_00.txt", "lab04_out_00.txt" },
{ "lab04_in_01.txt", "lab04_out_01.txt" },
{ "lab04_in_02.txt", "lab04_out_02.txt" },
{ "lab04_in_03.txt", "lab04_out_03.txt" },
{ "lab04_in_04.txt", "lab04_out_04.txt" },
{ "lab04_in_05.txt", "lab04_out_05.txt" }
};



/** Main program to test BST functions*/
int main(int argc, char* argv[])
{
	VS_MEM_CHECK				// enable memory leak check

#if ARGS
		if (argc < 3)
		{
			cerr << "Please provide name of input and output files.";
			return 1;
		}

	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input.";
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output.";
		return 3;
	}
#else
		cout << endl << "Input File: " << tests[TEST_NUM].input;
	ifstream in(tests[TEST_NUM].input);

	cout << endl << "Output File: " << tests[TEST_NUM].output << endl;
	std::ostream& out = (CONSOLE) ? std::cout : *(new std::ofstream(tests[TEST_NUM].output));
#endif

	int mode = 0;
	//LinkedLists* lls[4];
	//lls[0] = new LinkedList<int>();
	//lls[1] = new LinkedList<string>();

	LinkedList<int>* intLL = NULL;
	LinkedList<string>* stringLL = NULL;
	//LinkedListInterface<int>* intLL = NULL;
	//LinkedListInterface<string>* stringLL = NULL;

	string item1, item2, item3;
	// process input strings
	for (string line; getline(in, line);)
	{
		try {
			if (line.size() == 0) continue;
			istringstream iss(line);
			iss >> item1;
			iss >> item2;
			iss >> item3;
			if (item1 == "INT")
			{
				mode = 0;
				out << "INT " << "true" << endl;
				intLL = new LinkedList<int>();	// instantiate int LinkedList
			}
			else if (item1 == "STRING")
			{
				mode = 1;
				out << "STRING " << "true" << endl;
				stringLL = new LinkedList<string>();	// instantiate string LinkedList
			}
			else if (item1 == "size")
			{
				//out << endl << "size " << lls[mode]->size();
				out << "size ";
				if (mode == 0) out << intLL->size() << endl;
				else if (mode == 1) out << stringLL->size() << endl;
			}
			else if (item1 == "insertHead")
			{
				out << "insertHead " << item2 << " ";
				if (mode == 0) out << (intLL->insertHead(stoi(item2)) ? "true" : "false") << endl;
				else if (mode == 1) out << (stringLL->insertHead(item2) ? "true" : "false") << endl;
			}
			else if (item1 == "insertTail")
			{
				out << "insertTail " << item2 << " ";
				if (mode == 0) out << (intLL->insertTail(stoi(item2)) ? "true" : "false") << endl;
				else if (mode == 1) out << (stringLL->insertTail(item2) ? "true" : "false") << endl;
			}
			else if (item1 == "insertAfter")
			{
				out << "insertAfter " << item2 << " " << item3 << " ";
				if (mode == 0) out << (intLL->insertAfter(stoi(item2), stoi(item3)) ? "true" : "false") << endl;
				else if (mode == 1) out << (stringLL->insertAfter(item2, item3) ? "true" : "false") << endl;
			}
			else if (item1 == "remove")
			{
				out << "remove " << item2 << " ";
				if (mode == 0) out << (intLL->remove(stoi(item2)) ? "true" : "false") << endl;
				else if (mode == 1) out << (stringLL->remove(item2) ? "true" : "false") << endl;
			}
			else if (item1 == "at")
			{
				out << "at " << item2 << " ";
				string value;
				bool result = (mode == 0) ? intLL->at(stoi(item2), value) : stringLL->at(stoi(item2), value);
				if (result) out << value << " " << "true" << endl;
				else out << value << endl;
			}
			else if (item1 == "clear")
			{
				out << "clear ";
				if (mode == 0) out << (intLL->clear() ? "true" : "false") << endl;
				else if (mode == 1) out << (stringLL->clear() ? "true" : "false") << endl;
			}
			else if (item1 == "printList")
			{
				out << "printList";
				if (mode == 0) out << intLL->toString() << endl;
				else if (mode == 1) out << stringLL->toString() << endl;
			}
			else if (item1 == "iterateList")
			{
				out << "iterateList";
				if (mode == 0)
				{
					//if your basepointer was pointing to an instance of Derived then you could access it through a cast:
					LinkedList<int>::Iterator iter1 = static_cast<LinkedList<int>*>(intLL)->begin();
					while (iter1 != static_cast<LinkedList<int>*>(intLL)->end())
						out << " " << *iter1++;
				}
				else
				{
					//<string>::Iterator iter1 = stringLL->begin();
					LinkedList<string>::Iterator iter1 = static_cast<LinkedList<string>*>(stringLL)->begin();
					for (; iter1 != static_cast<LinkedList<string>*>(stringLL)->end(); ++iter1)
						out << " " << *iter1;
				}
				out << endl;
			}
			else
			{
				out << "????? " << "[" << line << "]" << endl;
			}
		}
		catch (string error) { out << error << endl; }
	}
	// delete tree (recover memory)
	//bst.clearTree();
	delete intLL;
	delete stringLL;

	// close files (no memory leaks)
#if ARGS
	out.close();
#elif !CONSOLE
	delete(&out);
#endif
	//in.close();
	return 0;
}
