/*
************************************************************************************************************************

Michael Molen
mbmolen@gmail.com
CS 235 Section 05
21 September 2018

DESCRIPTION: Reads a file stating the number of students and the number of exams and then calculates and outputs to a
	file each individual student score, the average exam scores, the grade determined from the class average, the
	number of each letter grade per exam, and (extra credit) the student's final score, letter grade, and the class
	average score.
INPUT: Command line argument input.txt
OUTPUT: Command line argument output.txt

************************************************************************************************************************
*/

#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;

/*	DETERMINE GRADE FUNCTION:
		If the student's score is within + or - 5 points of the average, give a grade of C.
		If the grade is more than 5 points but less than 15 points above (or below) the average, give a grade of B (D).
		If the grade is 15 points or more above (or below) the average, give a grade of A (E).
	Parameters: Score to compare against average score, average score
	Returns: Letter grade based on details above.
*/
char determineGrade(int score, double avg) {
	
	const int EXTREME_GRADE = 15; //Used for A and E grades
	const int MEDIUM_GRADE = 5; //Used for B and D grades
	//C grade is determined as being plus or minus 5 from the average

	//A grade
	if (score > EXTREME_GRADE + avg) {

		return 'A';
	}
	//B grade
	else if (score > MEDIUM_GRADE + avg && score <= avg + EXTREME_GRADE) {

		return 'B';
	}
	//C grade
	else if (score >= avg - MEDIUM_GRADE && score <= avg + MEDIUM_GRADE) {

		return 'C';
	}
	//D grade
	else if (score > avg - EXTREME_GRADE && score < avg - MEDIUM_GRADE) {

		return 'D';
	}
	//E grade
	else if (score <= avg - EXTREME_GRADE) {

		return 'E';
	}
	else {

		return 'X'; //Default case to signal error in processing
	}
}
/*	DETERMINE FINAL GRADE FUNCTION:
		If the student's score is within + or - 5 points of the average, give a grade of C.
		If the grade is more than 5 points but less than 15 points above (or below) the average, give a grade of B (D).
		If the grade is 15 points or more above (or below) the average, give a grade of A (E).
	Parameters: Student's final score to compare against class average score, class average score
	Returns: Letter grade based on details above.
*/
char determineFinalGrade(double score, double avg) {

	const int EXTREME_GRADE = 15; //Used for A and E grades
	const int MEDIUM_GRADE = 5; //Used for B and D grades
	//C grade is determined as being plus or minus 5 from the average

	//A grade
	if (score > EXTREME_GRADE + avg) {

		return 'A';
	}
	//B grade
	else if (score > MEDIUM_GRADE + avg && score <= avg + EXTREME_GRADE) {

		return 'B';
	}
	//C grade
	else if (score >= avg - MEDIUM_GRADE && score <= avg + MEDIUM_GRADE) {

		return 'C';
	}
	//D grade
	else if (score > avg - EXTREME_GRADE && score < avg - MEDIUM_GRADE) {

		return 'D';
	}
	//E grade
	else if (score <= avg - EXTREME_GRADE) {

		return 'E';
	}
	else {

		return 'X'; //Default case to signal error in processing
	}
}

int main(int argc, char* argv[]) {

	//VERIFY COMMAND LINE ARGUMENTS INCLUDED
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}

	//VERIFY INPUT FILE (argv[1]) EXISTS OF APPROPRIATE TYPE
	//cout << "Input file: " << argv[1] << endl; //Console window confirmation, not needed after testing
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}

	//VERIFY OUTPUT FILE (argv[2]) EXISTS OF APPROPRIATE TYPE
	//cout << "Output file: " << argv[2] << endl; //Console window confirmation, not needed after testing
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	//READ IN NUMBER OF STUDENTS AND EXAMS--Allows to establish dynamic arrays
	int numStudents;
	int numExams;

	in >> numStudents >> numExams;
	in.ignore(std::numeric_limits<int>::max(), '\n');

	//SET UP VARIABLES FOR PARSING RESULTS--2D array for scores, 1D array for names, line to parse
	string line;
	int **scores = new int*[numStudents];
	for (int i = 0; i < numStudents; i++) {

		scores[i] = new int[numExams];
	}
	string *names = new string[numStudents];

	//BEGIN PARSE--Get line from file, convert to istringstream, retreive name and scores for each student. Repeat.
	for (int i = 0; i < numStudents; i++) {

		getline(in, line);
		size_t p = 0;
		while (!isdigit(line[p])) p++;	// line[p] is the first digit, we just want the name for the first

		string name = line.substr(0, p);
		names[i] = name;
		line = line.substr(p);

		istringstream iss(line);
		for (int j = 0; j < numExams; j++) {

			iss >> scores[i][j];
		}

		iss.clear();
	}

	//OUTPUT STUDENT DETAILS TO OUTPUT FILE--Formatted as shown in lab detail
	//Student Scores
	const int STUDENT_SCORE_PRECISION = 0; //Output for student scores when integers
	const int STUDENT_NAME_WIDTH = 20; //Assuming students have total of <20 characters in name
	const int STUDENT_SCORE_WIDTH = 6; //Spacing between scores (max score: 100 (3 characters), double spacing)
	
	out << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; i++) {

		out << setw(STUDENT_NAME_WIDTH) << names[i] << " ";

		for (int j = 0; j < numExams; j++) {

			out << fixed << setprecision(STUDENT_SCORE_PRECISION) << setw(STUDENT_SCORE_WIDTH) << scores[i][j];
		}

		out << endl;
	}

	out << endl; //For output cleanliness and readability

	//Exam Averages
	const int AVERAGE_PRECISION = 1; //Precision used when outputting doubles for exam/class/student averages
	const int AVERAGE_WIDTH = 10; //Formatting output
	double* averages = new double[numExams]; //Holds average score for each exam
	for (int i = 0; i < numExams; i++) {

		averages[i] = 0.0;
	}

	out << "Exam Averages:" << endl;
	for (int i = 0; i < numExams; i++) {

		out << setw(AVERAGE_WIDTH) << "Exam " << (i + 1) << " Average = ";

		for (int j = 0; j < numStudents; j++) {

			averages[i] += scores[j][i];
		}

		averages[i] /= numStudents;
		out << setprecision(AVERAGE_PRECISION) << averages[i] << endl;
	}

	out << endl; //For output cleanliness and readability

	//Student Exam Grades
	const int LETTER_GRADES = 5; //Number of letter grades to pull from (in this case: A, B, C, D, and E = 5)
	char letterGrade;
	int **examGrades = new int*[LETTER_GRADES]; //Holds exam grades. Rows by letters (A = 0, B = 1, ...)
	for (int i = 0; i < LETTER_GRADES; i++) {

		examGrades[i] = new int [numExams];
	}
	for (int i = 0; i < LETTER_GRADES; i++) {

		for (int j = 0; j < numExams; j++) {

			examGrades[i][j] = 0;
		}
	}
	
	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; i++) {

		out << setw(STUDENT_NAME_WIDTH) << names[i] << " ";

		for (int j = 0; j < numExams; j++) {

			out << fixed << setprecision(STUDENT_SCORE_PRECISION) << setw(STUDENT_SCORE_WIDTH) << scores[i][j];
			letterGrade = determineGrade(scores[i][j], averages[j]); 
			out << '(' << letterGrade << ')';

			if (letterGrade == 'A') {

				examGrades[0][j]++;
			}
			else if (letterGrade == 'B') {

				examGrades[1][j]++;
			}
			else if (letterGrade == 'C') {

				examGrades[2][j]++;
			}
			else if (letterGrade == 'D') {

				examGrades[3][j]++;
			}
			else if (letterGrade == 'E') {
				
				examGrades[4][j]++;
			}
		}

		out << endl;
	}

	out << endl; //For output cleanliness and readability

	//Exam Grades
	const int EXAM_GRADES_WIDTH = 6; //Used to approximate formatting in example files

	out << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; i++) {

		out << setw(AVERAGE_WIDTH) << "Exam " << (i + 1);

		out << setw(EXAM_GRADES_WIDTH) << examGrades[0][i] << "(A)";
		out << setw(EXAM_GRADES_WIDTH) << examGrades[1][i] << "(B)";
		out << setw(EXAM_GRADES_WIDTH) << examGrades[2][i] << "(C)";
		out << setw(EXAM_GRADES_WIDTH) << examGrades[3][i] << "(D)";
		out << setw(EXAM_GRADES_WIDTH) << examGrades[4][i] << "(E)";

		out << endl;
	}


	//EXTRA CREDIT: Student Final Grades
	out << endl; //For output cleanliness and readability

	double studentAverage = 0.0;
	double classAverage = 0.0;

	//Step 1: Get class average. We need to compare student grades to class average to get letter grade.
	out << "Student Final Grades:" << endl;
	for (int i = 0; i < numStudents; i++) {

		for (int j = 0; j < numExams; j++) {

			classAverage += scores[i][j];
		}		
	}
	classAverage /= numExams * numStudents; //Average score on all tests per student

	//Step 2: Get individual student averages and output. When complete, output class average.
	for (int i = 0; i < numStudents; i++) {

		for (int j = 0; j < numExams; j++) {

			studentAverage += scores[i][j];
		}
		studentAverage /= numExams;
		out << setw(STUDENT_NAME_WIDTH) << names[i] << " "; //Output student's name formatted
		out << fixed << setprecision(AVERAGE_PRECISION) << studentAverage; //Output their average
		out << "(" << determineFinalGrade(studentAverage, classAverage) << ")" << endl; //Output letter grade
		
		//Reset counter
		studentAverage = 0;
	}
	out << "Class Average Score = " << fixed << setprecision(AVERAGE_PRECISION) << classAverage;


	//FREE MEMORY AND CLOSE FILES--Delete dynamically allocated arrays and close input/output
	for (int i = 0; i < numStudents; i++) {

		delete[] scores[i];
	}
	delete[] scores;
	for (int i = 0; i < LETTER_GRADES; i++) {

		delete[] examGrades[i];
	}
	delete[] examGrades;
	delete[] names;
	delete[] averages;

	in.close();
	out.close();

	return 0;
}