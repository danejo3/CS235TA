//Ian Clark
//CS 235-003
//iclark1B@gmail.com

//Test cases were all the sample input files given on the website.
//Test case 1:
// Input: File 01
// Output: Expected output in a new file.  Successful

//Test case 2:
// Input: File 02
// Output: Heap corruption.  Found that I was using the wrong parameter to initialize the arrays.  Fixed.
// Second try: Expected output in a new file.  Successful.

//Test case 3:
// Input: File 03
// Output: Expected output in a new file.  Successful.

#include<iostream>
#include<string>
#include<iomanip>
#include<fstream>
#include<sstream>

//Memory leak finder
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;

void loadArrays(string line, string *nameArray, double **scoreArray, int counter, int numScores);
void produceAverages(double **scoreArray, double *classAverage, int numStudents, int numScores);
void assignLetterGrade(double **scoreArray, double *classAverage, char **letterGrade, int numStudents, int numScores);
void produceStudentAverages(double **scoreArray, double *studentAverages, int numStudents, int numScores);
double totalAverage(double *studentAverages, int numStudents);
void assignMiniLetterGrade(char *miniLetterGrade, double *studentAverages, double allStudentAverages, int numStudents);


int main(int argc, char *argv[]) {
	VS_MEM_CHECK
	
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}

	cout << "Input file: " << argv[1] << endl;

	ifstream in(argv[1]);
	if (!in) {
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}

	cout << "Output file: " << argv[2] << endl;

	ofstream out(argv[2]);
	if (!out) {
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	//Initializing some necessary variables.
	int numStudents = 0;
	int numScores = 0;
	const int POSS_GRADES = 5;

	in >> numStudents >> numScores;
	in.ignore(std::numeric_limits<int>::max(), '\n');

	//Initialize pointer arrays.
	string *nameArray = new string[numStudents];
	double **scoreArray = new double*[numStudents];
	double *classAverage = new double[numStudents];
	double *studentAverages = new double[numStudents];
	char **letterGrade = new char*[numStudents];
	char *miniLetterGrade = new char[numStudents];
	int numLetters[POSS_GRADES];

	//Allocate space for the second dimension of the needed arrays.
	for (int i = 0; i < numStudents; i++) {
		scoreArray[i] = new double[numScores];
		letterGrade[i] = new char[numScores];
	}

	//Loading the arrays
	for(int counter = 0; counter < numStudents; counter++){
		string line;
		
		getline(in, line);
		loadArrays(line, nameArray, scoreArray, counter, numScores);
	}

	//Find the class averages and load the classAverage array.
	produceAverages(scoreArray, classAverage, numStudents, numScores);

	//Find the letter grades and load the letterGrade array.
	assignLetterGrade(scoreArray, classAverage, letterGrade, numStudents, numScores);

	//Load the output file
	//First part: Just the names and scores.
	out << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; i++) {
		out << setw(20) << nameArray[i] << " ";
		for (int j = 0; j < numScores; j++) {
			out << setw(6) << right << scoreArray[i][j];
		}
		out << endl;
	}

	//Second part: Exam averages.
	out << "Exam Averages:" << endl;
	for (int i = 0; i < numScores; i++) {
		out << setw(9) << "Exam " << i + 1 << " Average = ";
		out << right << fixed << setprecision(1) << setw(6) << classAverage[i] << endl;
	}

	//Third Part: Student Exam Grades
	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; i++) {
		out << setw(20) << nameArray[i];
		for (int j = 0; j < numScores; j++) {
			out << right << setw(6) << fixed << setprecision(0) << scoreArray[i][j] << "(" << letterGrade[i][j] << ")";
		}
		out << endl;
	}

	//Fourth Part: Exam Grades
	out << "Exam Grades:" << endl;
	for (int i = 0; i < numScores; i++) {
		out << setw(9) << "Exam " << setw(2) << i + 1;

		//Set the numLetters array to 0 for another use.
		for (int j = 0; j < POSS_GRADES; j++) {
			numLetters[j] = 0;
		}

		for (int j = 0; j < numStudents; j++) {
			if (letterGrade[j][i] == 'A') {
				numLetters[0] += 1;
			}

			else if (letterGrade[j][i] == 'B') {
				numLetters[1] += 1;
			}

			else if (letterGrade[j][i] == 'C') {
				numLetters[2] += 1;
			}

			else if (letterGrade[j][i] == 'D') {
				numLetters[3] += 1;
			}

			else {
				numLetters[4] += 1;
			}
		}

		out << right << setw(5) << numLetters[0] << "(A)"
			<< setw(5) << numLetters[1] << "(B)"
			<< setw(5) << numLetters[2] << "(C)"
			<< setw(5) << numLetters[3] << "(D)"
			<< setw(5) << numLetters[4] << "(E)" << endl;
	}

	//Fifth Part and Extra Credit: Student Final Grades
	out << "Student Final Grades:" << endl;

	produceStudentAverages(scoreArray, studentAverages, numStudents, numScores);
	double allStudentAverage = 0;

	allStudentAverage = totalAverage(studentAverages, numStudents);

	assignMiniLetterGrade(miniLetterGrade, studentAverages, allStudentAverage, numStudents);

	for (int i = 0; i < numStudents; i++) {
		out << setw(20) << nameArray[i] << " ";
		out << setw(5) << right << fixed << setprecision(1) << studentAverages[i]
			<< "(" << miniLetterGrade[i] << ")" << endl;
	}

	out << "Class Average Score = " << allStudentAverage;

	//CLEANUP!!
	for (int i = 0; i < numStudents; i++) {
		delete[] scoreArray[i];
		delete[] letterGrade[i];
	}

	delete[] scoreArray;
	delete[] letterGrade;
	delete[] nameArray;
	delete[] classAverage;
	delete[] studentAverages;
	delete[] miniLetterGrade;

	return 0;
}

/*****************************
** This function aims to load all the necessary information into each array. **
	@param line - The line taken from the input file earlier.
	@param nameArray - The array that stores all the students' names.
	@param scoreArray - Each students' exam scores for every exam.
	@param counter - An indexer.
	@param numScores - The number of exams.
******************************/

void loadArrays(string line, string *nameArray, double **scoreArray, int counter, int numScores) {
	stringstream s(line);

	string firstName;
	string lastName;
	string fullName;

	s >> firstName >> lastName;
	fullName = firstName + " " + lastName;
	nameArray[counter] = fullName;

	for (int i = 0; i < numScores; i++) {
		s >> scoreArray[counter][i];
	}

	return;
}

/****************
** This function will find the class average scores for each test. **
	@param scoreArray - Each students' exam scores for every exam.
	@param classAverage - The class's average score for each exam.
	@param numStudents - The number of students in the class.
	@param numScores - The number of exams.
****************/

void produceAverages(double **scoreArray, double *classAverage, int numStudents, int numScores) {
	double scoreTotal = 0.0;

	for (int i = 0; i < numScores; i++) {
		scoreTotal = 0;

		for (int j = 0; j < numStudents; j++) {
			scoreTotal += scoreArray[j][i];
		}

		classAverage[i] = scoreTotal / numStudents;
	}

	return;
}

/*******************
** This function will find each students' class average **
	@param scoreArray - Each students' exam scores for every exam.
	@param studentAverages - An array of each students' average scores across all tests.
	@param numStudents - The number of students in the class.
	@param numScores - The number of exams.
********************/

void produceStudentAverages(double **scoreArray, double *studentAverages, int numStudents, int numScores) {
	double scoreTotal = 0.0;

	for (int i = 0; i < numStudents; i++) {
		scoreTotal = 0;

		for (int j = 0; j < numScores; j++) {
			scoreTotal += scoreArray[i][j];
		}

		studentAverages[i] = scoreTotal / numScores;
	}

	return;
}

/***********************
** This function will find the letter grade for the students' exams **
	@param scoreArray - Each students' exam scores for every exam.
	@param classAverage - The class's average score for each exam.
	@param letterGrade - The letter grade each student receives for each exam.
	@param numStudents - The number of students in the class.
	@param numScores - The number of exams.
************************/

void assignLetterGrade(double **scoreArray, double *classAverage, char **letterGrade, int numStudents, int numScores) {
	const double WIDE_MARKER = 15;
	const double NARROW_MARKER = 5;

	for (int i = 0; i < numStudents; i++) {
		for (int j = 0; j < numScores; j++) {
			if (scoreArray[i][j] >= classAverage[j] + WIDE_MARKER) {
				letterGrade[i][j] = 'A';
			}

			else if (scoreArray[i][j] <= classAverage[j] - WIDE_MARKER) {
				letterGrade[i][j] = 'E';
			}

			else if ((scoreArray[i][j] > classAverage[j] + NARROW_MARKER) &&
				(scoreArray[i][j] < classAverage[j] + WIDE_MARKER)) {
				letterGrade[i][j] = 'B';
			}

			else if ((scoreArray[i][j] < classAverage[j] - NARROW_MARKER) &&
				(scoreArray[i][j] > classAverage[j] - WIDE_MARKER)) {
				letterGrade[i][j] = 'D';
			}

			else {
				letterGrade[i][j] = 'C';
			}
		}
	}

	return;
}

/*********************
** This function simpy finds the average of all students' average scores **
	@param studentAverages - An array of each students' average scores across all tests.
	@param num Students - The number of students in the class.
**********************/
double totalAverage(double *studentAverages, int numStudents) {
	double average = 0;

	for (int i = 0; i < numStudents; i++) {
		average += studentAverages[i];
	}

	average = average / numStudents;

	return average;
}

/************************
** This function finds the class letter grades for the extra credit portion **
	@param miniLetterGrade - An array of each students' letter grade for the whole class.
	@param studentAverages - An array of each students' average scores across all tests.
	@param allStudentAverage - The average class score.
	@param num Students - The number of students in the class.
*************************/

void assignMiniLetterGrade(char *miniLetterGrade, double *studentAverages, double allStudentAverage, int numStudents) {
	const double WIDE_MARKER = 15;
	const double NARROW_MARKER = 5;

	for (int i = 0; i < numStudents; i++) {
		if (studentAverages[i] >= allStudentAverage + WIDE_MARKER) {
			miniLetterGrade[i] = 'A';
		}

		else if (studentAverages[i] <= allStudentAverage - WIDE_MARKER) {
			miniLetterGrade[i] = 'E';
		}

		else if ((studentAverages[i] > allStudentAverage + NARROW_MARKER) &&
			(studentAverages[i] < allStudentAverage + WIDE_MARKER)) {
			miniLetterGrade[i] = 'B';
		}

		else if ((studentAverages[i] < allStudentAverage - NARROW_MARKER) &&
			(studentAverages[i] > allStudentAverage - WIDE_MARKER)) {
			miniLetterGrade[i] = 'D';
		}

		else {
			miniLetterGrade[i] = 'C';
		}
	}

	return;
}