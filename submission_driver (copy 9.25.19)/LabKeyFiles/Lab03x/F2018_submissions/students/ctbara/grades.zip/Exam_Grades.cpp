#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>

using namespace std;

char GetColumn(int column) {
	char letterGrade = '?';
	const int COLUMN_A = 0;
	const int COLUMN_B = 1;
	const int COLUMN_C = 2;
	const int COLUMN_D = 3;
	const int COLUMN_E = 4;

	if (column == COLUMN_A) {
		letterGrade = 'A';
	}
	else if (column == COLUMN_B) {
		letterGrade = 'B';
	}
	else if (column == COLUMN_C) {
		letterGrade = 'C';
	}
	else if (column == COLUMN_D) {
		letterGrade = 'D';
	}
	else if (column == COLUMN_E) {
		letterGrade = 'E';
	}
	
	return letterGrade;
}
char GetLetterGrade(double difference) {
	char letter = '?';
	const int HIGH_GRADE = 15;
	const int MEDIUM_GRADE = 5;
	const int LOW_GRADE = -5;
	const int FAILING_GRADE = -15;

	if (difference >= HIGH_GRADE) {
		letter = 'A';
	}
	else if ((difference > MEDIUM_GRADE) && (difference < HIGH_GRADE)) {
		letter = 'B';
	}
	else if ((difference >= LOW_GRADE) && (difference <= MEDIUM_GRADE)) {
		letter = 'C';
	}
	else if ((difference < LOW_GRADE) && (difference > FAILING_GRADE)) {
		letter = 'D';
	}
	else if (difference <= FAILING_GRADE) {
		letter = 'E';
	}

	return letter;
}

void GetExamGrade(char letter, int examNum, int**& examGrades) {

	if (letter == 'A') {
		++examGrades[examNum][0];
	}
	else if (letter == 'B') {
		++examGrades[examNum][1];
	}
	else if (letter == 'C') {
		++examGrades[examNum][2];
	}
	else if (letter == 'D') {
		++examGrades[examNum][3];
	}
	else if (letter == 'E') {
		++examGrades[examNum][4];
	}

	return;
}

double* AvgScoresExam(double**& examScores, int scores, double students) {
	double totalScores = 0.0;
	double avgScore = 0.0;
	double* scoreArr = new double[scores];

	for (int i = 0; i < scores; i++) {
		for (int j = 0; j < students; j++) {
			totalScores += examScores[j][i];
		}
		avgScore = totalScores / students;
		scoreArr[i] = avgScore;
		totalScores = 0.0;
		avgScore = 0.0;
	}

	return scoreArr;
}

double* AvgScoresStudent(double**& examScores, double scores, int students) {
	double avgdScore = 0.0;
	double totalpoints = 0.0;
	double* studScoreArr = new double[students];

	for (int i = 0; i < students; i++) {
		for (int j = 0; j < scores; j++) {
			totalpoints += examScores[i][j];
		}
		avgdScore = totalpoints / scores;
		studScoreArr[i] = avgdScore;
		avgdScore = 0.0;
		totalpoints = 0.0;
	}

	return studScoreArr;
}

int main(int argc, char* argv[]) {
	VS_MEM_CHECK
	int numStudents = 0;
	int numScores = 0;
	int numGrades = 5;
	char letterGrade = '?';
	char grade = '?';
	double currDif = 0.0;
	double* scoreArr = nullptr;
	double* studScoreArr = nullptr;
	ifstream inFS;
	string line = "";
	ofstream outFS;
	stringstream SS;

	// open input file, get out the array size and create arrays for student names and scores
	inFS.open(argv[1]);
	inFS >> numStudents >> numScores;

	string* studFirstNames = new string[numStudents];
	string* studLastNames = new string[numStudents];
	// exam scores is for reading in the values from in input file
	double** examScores = new double*[numStudents];
	for (int i = 0; i < numStudents; i++) {
		examScores[i] = new double[numScores];
	}
	// exam grades is the 2d array that shows how many letter grades are given for each test
	int** examGrades = new int*[numScores];
	for (int i = 0; i < numScores; i++) {
		examGrades[i] = new int[numGrades];
	}

	for (int i = 0; i < numScores; i++) {
		for (int j = 0; j < numGrades; j++) {
			examGrades[i][j] = 0;
		}
	}

	inFS.ignore();
	for (int i = 0; i < numStudents; i++) {
		getline(inFS, line);
		SS << line << endl;

		SS >> studFirstNames[i];
		SS >> studLastNames[i];
		for (int j = 0; j < numScores; j++) {
			SS >> examScores[i][j];
		}
	}
	inFS.close();

	//for (int i = 0; i < numStudents; i++) {
	//	cout << studFirstNames[i] << " ";
	//	cout << studLastNames[i] << " ";
	//	for (int j = 0; j < numScores; j++) {
	//		cout << examScores[i][j] << " ";
	//	}
	//	cout << endl;
	//}
	//for (int i = 0; i < numScores; i++) {
	//	cout << "Exam " << i << " ";
	//	for (int j = 0; j < numGrades; j++) {
	//		cout << examGrades[i][j];
	//	}
	//	cout << endl;
	//}

	scoreArr = AvgScoresExam(examScores, numScores, numStudents);

	studScoreArr = AvgScoresStudent(examScores, numScores, numStudents);

	// open the file to read your averaged values to.
	outFS.open(argv[2]);

	outFS << "Student Scores: " << endl;
	for (int i = 0; i < numStudents; i++) {
		outFS << studFirstNames[i] << " ";
		outFS << studLastNames[i] << " ";
		for (int j = 0; j < numScores; j++) {
			outFS << examScores[i][j] << " ";
		}
		outFS << endl;
	}

	outFS << "Exam Averages: " << endl;
	for (int i = 0; i < numScores; i++) {
		outFS << fixed << setprecision(1) << "Exam " << i+1 
			<< " Average = " << scoreArr[i] << endl;
	}

	outFS << "Student Exam Grades: " << endl;
	for (int i = 0; i < numStudents; i++) {
		outFS << studFirstNames[i] << " ";
		outFS << studLastNames[i] << " ";
		for (int j = 0; j < numScores; j++) {
			outFS << setprecision(0) << examScores[i][j];
			currDif = examScores[i][j] - scoreArr[j];
			letterGrade = GetLetterGrade(currDif);
			GetExamGrade(letterGrade, j, examGrades);
			outFS << "(" << letterGrade << ") ";
		}
		outFS << endl;
	}
	
	// create exam grade array
	for (int i = 0; i < numScores; i++) {
		for (int j = 0; j < numGrades; j++) {
			
		}
	}

	outFS << "Exam Grades: " << endl;
	for (int i = 0; i < numScores; i++) {
		outFS << "Exam " << i+1 << " ";
		for (int j = 0; j < numGrades; j++) {
			grade = GetColumn(j);
			outFS << examGrades[i][j] << "(" << grade << ")" << " ";
		}
		outFS << endl;
	}

	//close it
	outFS.close();

	delete[] studFirstNames;
	delete[] studLastNames;
	delete[] studScoreArr;
	delete[] scoreArr;

	for (int i = 0; i < numStudents; i++) {
		delete[] examScores[i];
	}
	delete[] examScores;

	for (int i = 0; i < numScores; i++) {
		delete[] examGrades[i];
	}
	delete[] examGrades;

	system("pause");

	return 0;
}
