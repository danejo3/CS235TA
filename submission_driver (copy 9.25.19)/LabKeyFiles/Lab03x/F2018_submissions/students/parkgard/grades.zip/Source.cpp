#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

int main(int argc, char* argv[])
{
	cout << "Inputfile:" << argv[1] << endl;
	cout << "Outputfile:" << argv[2] << endl;
	ifstream in(argv[1]);
	if (in.is_open())
	{
		int numberOfStudents;
		int numberOfExams;

		//input the number of students/number of exams and skip to next line
		in >> numberOfStudents >> numberOfExams;

		//building array for exam scores
		int **examInfo = new int*[numberOfStudents];
		for (int i = 0; i < numberOfStudents; i++)
		{
			examInfo[i] = new int[numberOfExams];
		}
		string* studentNames = new string[numberOfStudents];

		//loading in the names/test scores from the input file
		for (int i = 0; i < numberOfStudents; i++)
		{
			string firstName;
			string lastName;
			in >> firstName >> lastName;
			studentNames[i] = firstName + lastName;

			for (int j = 0; j < numberOfExams; j++)
			{
				int examScore;
				in >> examScore;
				examInfo[i][j] = examScore;
			}
		}

		//calculate average for each exam
		double* averageScores = new double[numberOfExams];
		for (int i = 0; i < numberOfExams; i++)
		{
			double average = 0;

			for (int j = 0; j < numberOfStudents; j++)
			{

				average = average + examInfo[j][i];

			}

			average = average / numberOfStudents;
			averageScores[i] = average;

		}

		//build array for grades
		char **examLetterGrades = new char*[numberOfStudents];
		for (int i = 0; i < numberOfStudents; i++)
		{
			examLetterGrades[i] = new char[numberOfExams];
		}

		//set up array for holding the number of each letter grade
		int **numberOfEachLetterGrade = new int*[5];
		for (int i = 0; i < 5; i++)
		{
			numberOfEachLetterGrade[i] = new int[numberOfExams];
		}

		//initialize the value of array locations to zero
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < numberOfExams; j++)
			{
				numberOfEachLetterGrade[i][j] = 0;
			}
		}

			//calculate grades for each student and number of each grade	
			int differenceForA = 15;
			int differenceForC = 5;
			int differenceForE = 15;
			for (int i = 0; i < numberOfExams; i++)
			{
				for (int j = 0; j < numberOfStudents; j++)
				{
					if (examInfo[j][i] >= averageScores[i] + differenceForA)
					{
						examLetterGrades[j][i] = 'A';
						numberOfEachLetterGrade[0][i]++;
					}
					else if (examInfo[j][i] < averageScores[i] + differenceForA && examInfo[j][i] > averageScores[i] + differenceForC)
					{
						examLetterGrades[j][i] = 'B';
						numberOfEachLetterGrade[1][i]++;;
					}
					
					else if (examInfo[j][i] > averageScores[i] - differenceForE && examInfo[j][i] < averageScores[i] - differenceForC)
					{
						examLetterGrades[j][i] = 'D';
						numberOfEachLetterGrade[3][i]++;
					}
					else if (examInfo[j][i] <= averageScores[i] - differenceForE)
					{
						examLetterGrades[j][i] = 'E';
						numberOfEachLetterGrade[4][i]++;
					}
					else if (examInfo[j][i] <= averageScores[i] + differenceForC || examInfo[j][i] >= averageScores[i] - differenceForC)
					{
						examLetterGrades[j][i] = 'C';
						numberOfEachLetterGrade[2][i]++;
					}					
				}
			}
			
			//outputting student scores
			ofstream out(argv[2]);
			out << "Student Scores:" << endl;
			for (int i = 0; i < numberOfStudents; i++)
			{
				out << setw(20) << studentNames[i] << " ";
				for (int j = 0; j < numberOfExams; j++)
				{
					out << fixed << setprecision(0) << setw(6) << examInfo[i][j] << setw(25);
				}
				out << endl;
			}

			//outputting exam averages
			int examcounter = 1;
			out << fixed << setw(0) << "Exam Averages:" << endl;
			for (int i = 0; i < numberOfExams; i++)
			{
				out << fixed << setprecision(1) << setw(10) << "Exam " << examcounter << " Average = " << setw(6) << averageScores[i];
				out << endl;
				examcounter++;
			}

			//outputting student exam grades
			out << fixed << setw(0) << "Student Exam Grades: " << endl;
			for (int i = 0; i < numberOfStudents; i++)
			{
				out << setw(20) << studentNames[i] << " ";
				for (int j = 0; j < numberOfExams; j++)
				{
					out << fixed << setprecision(0) << setw(6) << examInfo[i][j] << "(" << examLetterGrades[i][j] << ")" << setw(25);
				}
				out << endl;
			}

			//outputting exam grades
			examcounter = 1;
			out << fixed << setw(0) << "Exam Grades:" << endl;
			for (int j = 0; j < numberOfExams; j++)
			{
				int i = 0;
				
				out << fixed << setw(6) << "Exam " << examcounter << setw(10) << numberOfEachLetterGrade[i][j] << "(A) ";
				i++;
				out << numberOfEachLetterGrade[i][j] << "(B) ";
				i++;
				out << numberOfEachLetterGrade[i][j] << "(C) ";
				i++;
				out << numberOfEachLetterGrade[i][j] << "(D) ";
				i++;
				out << numberOfEachLetterGrade[i][j] << "(E)" << endl;
				examcounter++;
			

			}
			
			//deletion of all dynamically allocated memory
			for (int i = 0; i < numberOfStudents; i++)
			{
				delete [] examInfo[i];
			}
			delete[] examInfo;
			delete[] studentNames;
			delete[] averageScores;
			for (int i = 0; i < numberOfStudents; i++)
			{
				delete [] examLetterGrades[i] ;
			}
			delete[] examLetterGrades;
			for (int i = 0; i < 5; i++)
			{
				delete[] numberOfEachLetterGrade[i];
			}
			delete [] numberOfEachLetterGrade;

			
	}
	system("pause");
	return(0);
}