//  main.cpp
//  Amber Oldroyd
//  Lab 1 - Grades
//  19 September 2018


#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <sstream>
#include <cmath>
using namespace std;

string PopulateArray(const int& numStudent, const int& numTest, int**& scores, string students[], ostream& out, istream& in)
{
   for (int i = 0; i < numStudent; ++i)
   {
      string line;
      getline(in, line);
      size_t p = 0;
      
      while (!isdigit(line[p])) ++p;
      students[i] = line.substr(0,p);
      out << setw(20) << students[i];
      
      string indScores = line.substr(p);
      istringstream iss(indScores);
      for (int j = 0; j < numTest; ++j)
      {
         iss >> scores[i][j];
         out << setw(6) << scores[i][j];
      }
      out << endl;
   }
   return students[numStudent];
}

float CalcAverage(int **scores, const int STUDENT, const int TEST_NUM)
{
   float temp = 0;
   for (int i = 0; i < STUDENT; ++i)
   {
      temp += scores[i][TEST_NUM];
   }
   return temp/STUDENT;
}

char CalcGrade(const float score, const float avg)
{
   float val = 0;
   char grade;
   val = score - avg;
   
   if (val > 15) grade = 'A';
   else if (val > 5) grade = 'B';
   else if (val > -5) grade = 'C';
   else if (val > -15) grade = 'D';
   else grade = 'E';

   return grade;
}

void PrintGrades(ostream& out, char**& grades, const int numStudent, const int numTest)
{
   for (int i = 0; i < numTest; ++i)
   {
      int numA = 0;
      int numB = 0;
      int numC = 0;
      int numD = 0;
      int numE = 0;
      
      char currentGrade;
      
      for (int j = 0; j < numStudent; j++)
      {
         currentGrade = grades[j][i];
         
         switch (currentGrade)
         {
            case 'A':
               numA++;
               break;
            case 'B':
               numB++;
               break;
            case 'C':
               numC++;
               break;
            case 'D':
               numD++;
               break;
            case 'E':
               numE++;
               break;
            default:
               cout << "No grade was assigned" << endl;
               break;
         }
      }
      
      out << "    Exam  " << i + 1 << setw(5) << numA << "(A)" << setw(5) <<  numB << "(B)";
      out << setw(5) << numC << "(C)" << setw(5) << numD << "(D)" << setw(5) << numE << "(E)" << endl;
   }
   return;
}

void StudentGrade (ostream& out, int numStudent, int numTest, char**& grades, string students[], float*& avg, int**& scores)
{
   for(int i = 0; i < numStudent; ++i)
   {
      grades[i] = new char[numTest];
      out << setw(20) << students[i];
      for (int j = 0; j < numTest; ++j)
      {
         grades[i][j] = CalcGrade(scores[i][j], avg[j]);
         out << setw(6) << scores[i][j] << "(" << grades[i][j] << ")";
      }
      out << endl;
   }
   return;
}

void GetStudAvg(float*& avg, const int numTest, const int numStudent, int**& scores, ostream& out)
{
   for (int i = 0; i < numTest; ++i)
   {
      avg[i] = CalcAverage(scores, numStudent, i);
      out << "    Exam " << i + 1 << " Average = " << setprecision(1) << fixed << avg[i] << endl;
   }
   return;
}

float FinalGrades(int& numStudent, int& numTest, int**& scores, string students[], ostream& out)
{
   float sumScores = 0;
   float *indScore = new float[numStudent];
   for (int i = 0; i < numStudent; ++i)
   {
      for (int j = 0; j < numTest; ++j)
      {
         indScore[i] += scores[i][j];
      }
      indScore[i] /= numTest;
      sumScores += indScore[i];
   }
   float avgScore = 0;
   avgScore = sumScores/numStudent;
   for (int i = 0; i < numStudent; i++)
   {
      char finalGrade;
      finalGrade = CalcGrade(indScore[i], avgScore);
      out << setw(20) << students[i] << setprecision(1) << indScore[i] << "(" << finalGrade << ")" << endl;
   }
   delete[] indScore;
   return avgScore;
}

void DeallocateMem(char**& file1, int**& file2, const int& size)
{
   for(int i = 0; i < size; ++i)
   {
      delete file1[i];
   }
   delete[] file1;
   
   for(int i = 0; i < size; ++i)
   {
      delete file2[i];
   }
   delete[] file2;
   return;
}

int main(int argc, char* argv[])
{
   if (argc < 3)
   {
      cerr << "Please provide input and output file names";
      return 1;
   }
   ifstream in(argv[1]);
   if (!in)
   {
      cerr << "Unable to open input file " << argv[1];
      return 2;
   }
   ofstream out(argv[2]);
   if (!out)
   {
      in.close();
      cerr << "Unable to open output file " << argv[2];
      return 3;
   }

   int numStudent;
   int numTest;
   in >> numStudent >> numTest;
   in.ignore(numeric_limits<int>::max(), '\n');
   int **scores = new int*[numStudent];
   for(int i = 0; i < numStudent; ++i)
   {
      scores[i] = new int[numTest];
   }
   
   out << "Student Scores:" << endl;
   string students[numStudent];
   PopulateArray(numStudent, numTest, scores, students, out, in);
   in.close();

   out << "Exam Averages:" << endl;
   float *avg = new float[numTest];
   GetStudAvg(avg, numTest, numStudent, scores, out);
   
   out << "Student Exam Grades:" << endl;
   char **grades = new char*[numStudent];
   StudentGrade(out, numStudent, numTest, grades, students, avg, scores);
   delete[] avg;
   
   out << "Exam Grades:" << endl;
   PrintGrades(out, grades, numStudent, numTest);
   
   out << "Student Final Grades:" << endl;
   float avgScore = 0;
   avgScore = FinalGrades(numStudent, numTest, scores, students, out);
   out << "Class Average Score = " << avgScore;
   
   DeallocateMem(grades, scores, numStudent);
   out.close();
   return 0;
}
