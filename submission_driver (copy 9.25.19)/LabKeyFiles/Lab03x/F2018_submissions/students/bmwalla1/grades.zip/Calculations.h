

#ifndef Calculations_h
#define Calculations_h

#include <iostream>

using namespace std;

double ComputeAverage(int **scores, int whichTest, int numStudents);
char ComputeGrade(double *averages, int whichTest, int score);
int HowManyAs(int **scores, int whichTest, int numStudents, double *averages);
int HowManyBs(int **scores, int whichTest, int numStudents, double *averages);
int HowManyCs(int **scores, int whichTest, int numStudents, double *averages);
int HowManyDs(int **scores, int whichTest, int numStudents, double *averages);
int HowManyEs(int **scores, int whichTest, int numStudents, double *averages);
double ComputeFinalAvrg(int whichStudent, int **scores, int numExams);
char ComputeFinalGrade(double *studentavgscore, int whichStudent, double classavg);

#endif /* Calculations_h */
