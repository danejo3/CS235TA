#include "Calculations.h"
using namespace std;

double ComputeAverage(int **scores, int whichTest, int numStudents)
{
    double average = 0;
    
    for (int i = 0; i < numStudents; i++)
    {
        average += scores[i][whichTest];
    }
    average = average/numStudents;
    
    
    return average;
}

char ComputeGrade(double *averages, int whichTest, int score)
{
    char grade;
    
    if (score <= averages[whichTest] + 5 &&  score >= averages[whichTest] - 5)
    {
        grade = 'C';
    }
    else if (score > averages[whichTest] + 5 && score < averages[whichTest] + 15)
    {
        grade = 'B';
    }
    else if (score < averages[whichTest] - 5 && score > averages[whichTest] - 15)
    {
        grade = 'D';
    }
    else if (score >= averages[whichTest] + 15)
    {
        grade = 'A';
    }
    else if (score <= averages[whichTest] - 15)
    {
        grade = 'E';
    }
    else
    {
        grade = 'X'; //ERROR CHECK
    }
    
    
    return grade;
}

int HowManyAs(int **scores, int whichTest, int numStudents, double *averages)
{
    int counter = 0;
    
    for (int i = 0; i < numStudents; i++)
    {
        if (scores[i][whichTest] >= averages[whichTest] + 15)
        {
            counter++;
        }
    }
    
    return counter;
}

int HowManyBs(int **scores, int whichTest, int numStudents, double *averages)
{
    int counter = 0;
    
    for (int i = 0; i < numStudents; i++)
    {
        if (scores[i][whichTest] > averages[whichTest] + 5 && scores[i][whichTest] < averages[whichTest] + 15)
        {
            counter++;
        }
    }
    
    return counter;
}

int HowManyCs(int **scores, int whichTest, int numStudents, double *averages)
{
    int counter = 0;
    
    for (int i = 0; i < numStudents; i++)
    {
        if (scores[i][whichTest] <= averages[whichTest] + 5 &&  scores[i][whichTest] >= averages[whichTest] - 5)
        {
            counter++;
        }
    }
    
    return counter;
}

int HowManyDs(int **scores, int whichTest, int numStudents, double *averages)
{
   int counter = 0;
    
    for (int i = 0; i < numStudents; i++)
    {
        if (scores[i][whichTest] < averages[whichTest] - 5 && scores[i][whichTest] > averages[whichTest] - 15)
        {
            counter++;
        }
    }
    
   return counter;
}

int HowManyEs(int **scores, int whichTest, int numStudents, double *averages)
{
   int counter = 0;
    
    for (int i = 0; i < numStudents; i++)
    {
        if (scores[i][whichTest] <= averages[whichTest] - 15)
        {
            counter++;
        }
    }
    
   return counter;
}

double ComputeFinalAvrg(int whichStudent, int **scores, int numExams)
{
    double avrg = 0.0;
    
    for (int i = 0; i < numExams; i++)
    {
        avrg += scores[whichStudent][i];
    }
    
    avrg = avrg / numExams;
    
    return avrg;
}

char ComputeFinalGrade(double *studentavgscore, int whichStudent, double classavg)
{
    char grade;
    
    if (studentavgscore[whichStudent] <= classavg + 5 &&  studentavgscore[whichStudent] >= classavg - 5)
    {
        grade = 'C';
    }
    else if (studentavgscore[whichStudent] > classavg + 5 && studentavgscore[whichStudent] < classavg + 15)
    {
        grade = 'B';
    }
    else if (studentavgscore[whichStudent] < classavg - 5 && studentavgscore[whichStudent] > classavg - 15)
    {
        grade = 'D';
    }
    else if (studentavgscore[whichStudent] >= classavg + 15)
    {
        grade = 'A';
    }
    else if (studentavgscore[whichStudent] <= classavg - 15)
    {
        grade = 'E';
    }
    else
    {
        grade = 'X'; //ERROR CHECK
    }
    
    
    return grade;
}
