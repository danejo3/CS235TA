#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include <sstream>

#include "Calculations.h"


using namespace std;

int main(int argc, const char* argv[])
{
    VS_MEM_CHECK               // enable memory leak check
    
    int numStudents = 0;
    int numExams = 0;
    string firstName;
    string lastName;
    
   
  
    //ERROR CHECK FOR COMMAND LINE
    if (argc < 3)
    {
        cerr << "Please provide name of input and output files";
        return 1;
    }
    cout << "Input file: " << argv[1] << endl;
    ifstream in(argv[1]);
    if (!in)
    {
        cerr << "Unable to open " << argv[1] << " for input";
        return 2;
    }
    cout << "Output file: " << argv[2] << endl;
    ofstream out(argv[2]);
    if (!out)
    {
        in.close();
        cerr << "Unable to open " << argv[2] << " for output";
        return 3;
    }

    
    //READ FROM FILE FOR ROWS AND COLS
    in >> numStudents >> numExams;
    in.ignore(std::numeric_limits<int>::max(), '\n');
    
    int rows = numStudents;
    int cols = numExams;
    
    //DECLARE ARRAYS
    int **scoresArray = new int*[rows];
    for(int i = 0; i < rows; ++i)
    {
        scoresArray[i] = new int[cols];
    }

    string *nameArray = new string[numStudents];
    
    double *averageArray = new double[numExams];
    
    double *finalAverageArray = new double [numStudents];

    //READ FROM FILE
    for (int i = 0; i < numStudents; i++)
    {
        string line;
        getline(in, line);
        istringstream iss(line);
        iss >> firstName >> lastName;
 
        nameArray[i] = firstName + " " + lastName;
      
        
        int examScore = 0;
        int counter = 0;
        
       while (iss >> examScore)
       {
           scoresArray[i][counter] = examScore;
           counter++;
       }
    }

    
    // OUTPUT TO FILE
    out << "Student Scores:" << endl;
    for (int i = 0; i < numStudents; i++)
    {
        out << setw(20) << nameArray[i] << " ";
        for (int j = 0; j < numExams; j++)
        {
            out << fixed << setprecision(0) << setw(6) << scoresArray[i][j];
        }
        out << endl;
    }
    
    out << "Exam Averages:" << endl;
    for (int i = 0; i < numExams; i++)
    {
        out << setw(10) << "Exam " << i+1 << " Average = ";
        double average = 0.0;
        average = ComputeAverage(scoresArray, i, numStudents);
        out << fixed << setprecision(1) << average;
        out << endl;
        averageArray[i] = average;
    }
    
    out << "Student Exam Grades:" << endl;
    for (int i = 0; i < numStudents; i++)
    {
        out << setw(20) << nameArray[i] << " ";
        for (int j = 0; j < numExams; j++)
        {
            out << fixed << setprecision(0) << setw(6) << scoresArray[i][j] << "(" << ComputeGrade(averageArray, j, scoresArray[i][j]) <<  ")";
        }
        out << endl;
    }
    
    out << "Exam Grades:" << endl;
    for (int i = 0; i < numExams; i++)
    {
        out << setw(10) << "Exam " << i+1;
        out << fixed << setprecision(0) << setw(6) << HowManyAs(scoresArray, i, numStudents, averageArray) << "(A)";
        out << fixed << setprecision(0) << setw(6) << HowManyBs(scoresArray, i, numStudents, averageArray) << "(B)";
        out << fixed << setprecision(0) << setw(6) << HowManyCs(scoresArray, i, numStudents, averageArray) << "(C)";
        out << fixed << setprecision(0) << setw(6) << HowManyDs(scoresArray, i, numStudents, averageArray) << "(D)";
        out << fixed << setprecision(0) << setw(6) << HowManyEs(scoresArray, i, numStudents, averageArray) << "(E)";
        out << endl;
        
    }
    
    out << "Student Final Grades:" << endl;
    
    for (int i = 0; i < numStudents; i++)
    {
        finalAverageArray[i] = ComputeFinalAvrg(i, scoresArray, numExams);
    }
    
    double finalClassAverage = 0;
    for (int i = 0; i < numStudents; i++)
    {
        finalClassAverage += finalAverageArray[i];
    }
    finalClassAverage /= numStudents;
    
    for (int i = 0; i < numStudents; i++)
    {
        out << setw(20) << nameArray[i] << " ";
        out << fixed << setprecision(1) << finalAverageArray[i] << "(" << ComputeFinalGrade(finalAverageArray, i, finalClassAverage) << ")";
        out << endl;
    }
    
    out << "Class Average Score = ";
    out << fixed << setprecision(1) << finalClassAverage;
    
    //DELETE DYNAMIC ARRAYS
    delete [] finalAverageArray;
    delete [] averageArray;
    delete [] nameArray;
    
    for (int i = 0; i < rows; i++)
    {
        delete [] scoresArray[i];
    }
    delete [] scoresArray;
    
    return 0;
}
