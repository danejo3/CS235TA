#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK;
#endif
//Function to get the average score to each exam
double GetAverage(int **studentPtr, int numStudents, int examNum)
{
	double examAvg = 0.0;
	for (int i = 0; i < numStudents; ++i)
	{
		examAvg = examAvg + studentPtr[i][examNum];
	}
	examAvg = examAvg / numStudents;

	return examAvg;
}
//Function gets the average score for the whole class
double GetClassAverage(int **studentPtr, int numStudents, int numGrades)
{
	double examAvg = 0.0;
	for (int i = 0; i < numStudents; ++i)
	{
		for (int j = 0; j < numGrades; ++j)
		{
			examAvg = examAvg + studentPtr[i][j];
		}
	}
	examAvg = examAvg / (numStudents*numGrades);

	return examAvg;
}

int main(int argc, char* argv[])
{
	VS_MEM_CHECK			// check for memory leak
		
	ifstream classOne(argv[1]);
	if (!classOne.is_open())
	{
		cout << "Could not open file" << endl;
	}
	else
	{
		
		int numStudents, numGrades;
		string firstName, lastName;

		classOne >> numStudents;
		classOne >> numGrades;

		//ARRAY CREATION
		int** studentPtr = new int*[numStudents];
		for (int i = 0; i < numStudents; ++i)
		{
			studentPtr[i] = new int[numGrades];
		}

		string** gradePtr = new string*[numStudents];
		for (int i = 0; i < numStudents; ++i) 
		{
			gradePtr[i] = new string[numGrades];
		}

		string* studentNames;
		studentNames = new string[numStudents];
		
		//PLACING INFO INTO THE RIGHT LOCATION
		for (int k = 0; k < numStudents; ++k)
		{
			classOne >> firstName;
			classOne >> lastName;
			studentNames[k] = firstName + " " + lastName; 
			
			for (int j = 0; j < numGrades; ++j)
			{
				classOne >> studentPtr[k][j];
			}
			
		}

		// EXAM AVERAGE SECTION
		cout << "Exam Averages: " << endl;
		for (int i = 0; i < numGrades ; ++i)
		{
			cout << "Exam " << i + 1 << " Average = ";
			double examAverage = GetAverage(studentPtr, numStudents, i);
			cout << setprecision(1) << fixed << examAverage;

			int numA = 0;
			int numB = 0;
			int numC = 0;
			int numD = 0;
			int numE = 0;

			for (int j = 0; j < numStudents; ++j) 
			{
				if (studentPtr[j][i] > examAverage - 5 && studentPtr[j][i] <= examAverage + 5)
				{
					++numC;
					gradePtr[j][i] = "(C)";
				}
				else if (studentPtr[j][i] > examAverage + 5 && studentPtr[j][i] <= examAverage + 15)
				{
					++numB;
					gradePtr[j][i] = "(B)";
				}
				else if (studentPtr[j][i] > examAverage + 15)
				{
					++numA;
					gradePtr[j][i] = "(A)";
				}
				else if (studentPtr[j][i] > examAverage - 15 && studentPtr[j][i] <= examAverage - 5)
				{
					++numD;
					gradePtr[j][i] = "(D)";
				}
				else
				{
					++numE;
					gradePtr[j][i] = "(E)";
				}
			}

			// OUTPUT THE EXAM GRADES
			cout << setw(5) << numA << "(A)";
			cout << setw(5) << numB << "(B)";
			cout << setw(5) << numC << "(C)";
			cout << setw(5) << numD << "(D)";
			cout << setw(5) << numE << "(E)";
			cout << endl;

			numA = 0;
			numB = 0;
			numC = 0;
			numD = 0;
			numE = 0;
			examAverage = 0.0;
		}
		cout << endl;

		//STUDENT INFO
		cout << "Student Exam Grades: " << endl;
		for (int i = 0; i < numStudents; ++i)
		{
			cout << setw(20) << right << studentNames[i] << " ";

			for (int j = 0; j < numGrades; ++j)
			{
				cout << setw(5) << right << studentPtr[i][j] << gradePtr[i][j] << " ";
			}
			cout << endl;
		}
		
		cout << endl << "**Bonus**" << endl;
		double classAverage = GetClassAverage(studentPtr, numStudents, numGrades);
		cout << "Class Average = " << classAverage;
		cout << endl;
		cout << "Student Final Exam Grade:" << endl;
			
		double studentAvg = 0.0; 
		for (int i = 0; i < numStudents; ++i)
		{
			cout << setw(20) << right << studentNames[i] << " ";
			for (int j = 0; j < numGrades; ++j)
			{
				studentAvg = studentAvg + studentPtr[i][j];
			}
			studentAvg = studentAvg / numGrades;

			cout << studentAvg;
			if (studentAvg > classAverage - 5 && studentAvg <= classAverage + 5)
			{
				cout << "(C)" << endl;
			}
			else if (studentAvg > classAverage - 15 && studentAvg <= classAverage - 5)
			{
				cout << "(D)" << endl;
			}
			else if (studentAvg > classAverage + 5 && studentAvg <= classAverage + 15)
			{
				cout << "(B)" << endl;
			}
			else if (studentAvg > classAverage + 15) 
			{
				cout << "(A)" << endl;
			}
			else
			{
				cout << "(E)" << endl;
			}
			studentAvg = 0.0;
		}
		 
	
		
		//DELETE FROM MEMORY
		
		for (int i = 0; i < numStudents; i++)
		{
			delete[] studentPtr[i];
			delete[] gradePtr[i];
		}
		delete[] studentPtr;
		delete[] gradePtr;
		delete[] studentNames;
	}
	return 0;
}