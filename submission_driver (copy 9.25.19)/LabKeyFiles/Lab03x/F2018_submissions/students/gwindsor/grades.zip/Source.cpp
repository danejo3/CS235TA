/* LAB 0: GRADES

Net ID: gwindsor
Email: goop434@gmail.com
*/
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>

#define NAME_W 20
#define GRADE_W 7
#define GRADE_PRECISION 1
#define B_OR_D 5
#define A_OR_E 15
#define LETTER_AMOUNT 5
#define A_POS 0
#define B_POS 1
#define C_POS 2
#define D_POS 3
#define E_POS 4


using namespace std;
int main(int argc, char* argv[])
{
	ifstream in(argv[1]);
	ofstream out(argv[2]);
	if (in.is_open())
	{

		int numStudents = 0;
		int numExams = 0;
		in >> numStudents;
		in >> numExams;

		int** scores = new int*[numStudents];												// Allocates dynamic two-dimensional array for scores
		for (int i = 0; i < numStudents; i++)           
		{
			scores[i] = new int[numExams];					
		}

		string firstName;
		string lastName;
		string studentName;
		string* names = new string[numStudents];

		out << "Student Scores:" << endl;

		for (int i = 0; i < numStudents; i++)												//Reads from file to populate and output arrays of students and exam scores
		{
			in >> firstName >> lastName;													//Student Names
			studentName = firstName + " " + lastName;
			names[i] = studentName;
			out << fixed << setw(NAME_W) << names[i];

			for (int j = 0; j < numExams; j++)												//Exam Scores
			{
				in >> scores[i][j];
				out << setw(GRADE_W) << scores[i][j];
			}
			out << endl;
		}
		in.close();

		double scoreSum = 0.0;
		double* examAvgs = new double[numExams];
		out << "Exam Averages:" << endl;
		for (int i = 0; i < numExams; i++)													//Calculates and outputs exam averages
		{
			for (int j = 0; j < numStudents; j++)
			{
				scoreSum += static_cast<double>(scores[j][i]);
			}
			examAvgs[i] = scoreSum / numStudents;
			out << "    Exam " << (i + 1) << " Average = ";
			out << setprecision(GRADE_PRECISION) << examAvgs[i] << endl;
			scoreSum = 0.0;
		}
		
		int** letterCount = new int*[numExams];
		for (int i = 0; i < numExams; i++)													// Allocates dynamic two-dimensional array for counting letters
		{
			letterCount[i] = new int[LETTER_AMOUNT];
			for (int j = 0; j < B_OR_D; j++)												//Sets every element in LetterCount[][] to 0
			{
				letterCount[i][j] = 0;
			}
		}

		out << "Student Exam Grades:" << endl;
		for (int i = 0; i < numStudents; i++)												//Assigns letter grades and counts number of letters for each exam
		{
			out << setw(NAME_W) << names[i];
			for (int j = 0; j < numExams; j++)
			{
				out << setw(GRADE_W) << scores[i][j];
				if (scores[i][j] > examAvgs[j] + B_OR_D)
				{
					if (scores[i][j] > examAvgs[j] + A_OR_E)
					{
						out << "(A)";
						letterCount[j][A_POS]++;
					}
					else
					{
						out << "(B)";
						letterCount[j][B_POS]++;
					}
				}
				else if (scores[i][j] < examAvgs[j] - B_OR_D)
				{
					if (scores[i][j] < examAvgs[j] - A_OR_E)
					{
						out << "(E)";
						letterCount[j][E_POS]++;
					}
					else
					{
						out << "(D)";
						letterCount[j][D_POS]++;
					}
				}
				else
				{
					out << "(C)";
					letterCount[j][C_POS]++;
				}
			}
			out << endl;
		}

		out << "Exam Grades:" << endl;
		for (int i = 0; i < numExams; i++)													//Outputs the counted Letters
		{
			out << "    Exam " << (i+1);
			for (int j = 0; j < LETTER_AMOUNT; j++)
			{
				out << setw(GRADE_W) << letterCount[i][j];
				switch (j)
				{
				case A_POS : out << "(A)";
					break;
				case B_POS: out << "(B)";
					break;
				case C_POS: out << "(C)";
					break;
				case D_POS: out << "(D)";
					break;
				case E_POS: out << "(E)";
					break;
				default:
					break;
				}

			}
			out << endl;
		}

		double classAvg = 0.0;
		double* studentAvg = new double[numStudents];
		out << "Student Final Grades:" << endl;
		for (int i = 0; i < numStudents; i++)												//Stores the student averages in an array, then calculates the class average
		{				
			studentAvg[i] = 0.0;
			for (int j = 0; j < numExams; j++)
			{
				studentAvg[i] += scores[i][j];
			}
			studentAvg[i] /= numExams;
			classAvg += studentAvg[i];
		}
		classAvg /= numStudents;

		for (int i = 0; i < numStudents; i++)												//Outputs the student and class averages and assigns each student a letter grade
		{
			out << setw(NAME_W) << names[i];
			out << setw(GRADE_W)<< setprecision(GRADE_PRECISION) << studentAvg[i];

			if (studentAvg[i] > classAvg + B_OR_D)
			{
				if (studentAvg[i] > classAvg + A_OR_E)
				{
					out << "(A)";
				}
				else
				{
					out << "(B)";
				}
			}
			else if (studentAvg[i] < classAvg - B_OR_D)
			{
				if (studentAvg[i] < classAvg - A_OR_E)
				{
					out << "(E)";
				}
				else
				{
					out << "(D)";
				}
			}
			else
			{
				out << "(C)";
			}
			out << endl;
		}
		out << "Class Average Score = " << setprecision(GRADE_PRECISION) << classAvg << endl;
		 
		delete[] studentAvg;																//Deallocates all pointer variables to prevent memory leaks
		for (int i = 0; i < numExams; i++)
		{
			delete[] letterCount[i];
		}
		delete[] letterCount;
		delete[] examAvgs;
		delete[] names;
		for (int i = 0; i < numStudents; i++)
		{	
			delete[] scores[i];	
		}
		delete[] scores;
	}
	else
	{
		out << "Unable to open file" << endl;
	}
	out.close();
	return 0;
} 