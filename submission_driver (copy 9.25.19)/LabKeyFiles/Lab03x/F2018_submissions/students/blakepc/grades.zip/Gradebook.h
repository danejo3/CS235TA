#ifndef GRADEBOOK_H
#define GRADEBOOK_H
#endif
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip> 
using namespace std;

class Gradebook {
public:
	Gradebook(int numStudents, int numExams, string outFileName) {
		this->numStudents = numStudents;
		this->examAverages = new double[numExams];
		this->numExams = numExams;
		out.open(outFileName);
		this->studentNames = new string[numStudents];
		this->studentAverage = new double[numStudents];
		this->studentGrades = new double*[numStudents];
		for (int i = 0; i < numStudents; ++i) {
			studentGrades[i] = new double[numExams];
		}

	}
	~Gradebook() {
		for (int i = 0; i < numStudents; ++i)
		{
			delete[] studentGrades[i];
		}
		delete[] studentGrades;
		delete[] examAverages;
		delete[] studentAverage;
		delete[] studentNames;
		out.close();
	}
	void SetNames(string firstName, string lastName, int nameCounter);
	void SetScores(double currentScore, int testNumber, int nameCounter);
	void DisplayStudentScores();
	void CalculateAverages();
	void DisplayAverages();
	void StudentExamGrades();
	void ExamGrades();
	void StudentsFinalGrades();

private:
	int numAs;
	int numBs;
	int numCs;
	int numDs;
	int numEs;
	double* studentAverage;
	double classAverage;
	double* examAverages;
	double** studentGrades;
	string* studentNames;
	int numExams;
	int numStudents;
	ofstream out;
};
