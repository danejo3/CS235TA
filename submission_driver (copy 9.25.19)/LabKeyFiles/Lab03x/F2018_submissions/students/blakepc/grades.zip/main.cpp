#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "Gradebook.h"
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif
using namespace std;

int main(int argc, char* argv[]) {
	int numStudents;
	int numExams;
	string line;
	ifstream in(argv[1]);
	string outFileName = argv[2];
	in >> numStudents;
	in >> numExams;
	getline(in, line);
	Gradebook Gradebook(numStudents, numExams, outFileName);
	int nameCounter = 0;
	while (getline(in, line)){
		int testNumber = 0;
		stringstream lineTwo(line);
		string firstName;
		string lastName;
		double currentScore;
		lineTwo >> firstName;
		lineTwo >> lastName;
		Gradebook.SetNames(firstName, lastName, nameCounter);
		while (lineTwo >> currentScore) {
			Gradebook.SetScores(currentScore, testNumber, nameCounter);
			testNumber = testNumber + 1;
		}
		nameCounter = nameCounter + 1;
		testNumber = 0;
	}
	Gradebook.DisplayStudentScores();
	Gradebook.CalculateAverages();
	Gradebook.DisplayAverages();
	Gradebook.StudentExamGrades();
	Gradebook.ExamGrades();
	Gradebook.StudentsFinalGrades();
	in.close();

	system("pause");
	return 0;

}