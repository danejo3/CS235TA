#include "Gradebook.h"

void Gradebook::SetNames(string firstName, string lastName, int nameCounter) {
	studentNames[nameCounter] = firstName + " " + lastName;
}

void Gradebook::SetScores(double currentScore, int testNumber, int nameCounter) {
	studentGrades[nameCounter][testNumber] = currentScore;
}
void Gradebook::CalculateAverages() {
	double averageScore = 0;
	for (int i = 0; i < numExams ; ++i) {
		averageScore = 0;
		for (int j = 0; j < numStudents ; ++j) {
			averageScore = averageScore + studentGrades[j][i];
		}
		averageScore = averageScore / numStudents;
		examAverages[i] = averageScore;
	}
}
void Gradebook::StudentsFinalGrades() {
	double studentsGrade = 0;
	classAverage = 0;
	for (int i = 0; i < numStudents; ++i) {
		for (int j = 0; j < numExams; ++j) {
			studentsGrade = studentsGrade + studentGrades[i][j];
		}
		studentsGrade = studentsGrade / numExams;
		studentAverage[i] = studentsGrade;
		studentsGrade = 0;
	}
	for (int i = 0; i < numStudents; ++i) {
		classAverage = classAverage + studentAverage[i];
	}
	classAverage = classAverage / numStudents;
	out << "Student Final Grades:" << endl;
	for (int i = 0; i < numStudents; ++i) {
		out << setprecision(1) << setw(20) << studentNames[i] << "  " << studentAverage[i];
		if (studentAverage[i] > classAverage + 5) {
			if (studentAverage[i] > classAverage + 15) {
				out << "(A) ";
			}
			else {
				out << "(B) ";
			}
		}
		else if (studentAverage[i] > classAverage - 5) {
			out << "(C) ";
		}
		else if (studentAverage[i] > classAverage - 15) {
			out << "(D) ";
		}
		else {
			out << "(E) ";
		}
		out << endl;
	}
	out << "Class Average Score = " << classAverage << endl;
}
void Gradebook::ExamGrades() {
	
	out << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; ++i) {
		numAs = 0;
		numBs = 0;
		numCs = 0;
		numDs = 0;
		numEs = 0;
		for (int j = 0; j < numStudents; ++j) {
			if (studentGrades[j][i] > examAverages[i] + 5) {
				if (studentGrades[j][i] > examAverages[i] + 15) {
					numAs = numAs + 1;
				}
				else {
					numBs = numBs + 1;
				}
			}
			else if (studentGrades[j][i] > examAverages[i] - 5) {
				numCs = numCs + 1;
			}
			else if (studentGrades[j][i] > examAverages[i] - 15) {
				numDs = numDs + 1;
			}
			else {
				numEs = numEs + 1;
			}
		}
		out << setw(10) << "Exam  " << i + 1 << setw(5) << numAs << "(A)" << setw(5) 
			 << numBs << "(B)" << setw(5) << numCs << "(C)" << setw(5) << numDs << "(D)" << setw(5) << numEs << "(E)" << endl;
	}
}
void Gradebook::StudentExamGrades() {
	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; ++i) {
		out << setw(20);
		out << studentNames[i];
		out << setw(7);
		for (int j = 0; j < numExams; ++j) {
			out << setprecision(0) << studentGrades[i][j];
			if (studentGrades[i][j] > examAverages[j] + 5){
				if (studentGrades[i][j] > examAverages[j] + 15) {
					out << "(A) ";
				}
				else {
					out << "(B) ";
				}
			}
			else if (studentGrades[i][j] > examAverages[j] - 5){
				out << "(C) ";
			}
			else if (studentGrades[i][j] > examAverages[j] - 15) {
				out << "(D) ";
			}
			else {
				out << "(E) ";
			}
			out << setw(5);

		}

		out << endl;
	}

}
void Gradebook::DisplayAverages() {
	out << "Exam Averages:" << endl;
	for (int i = 0; i < numExams; ++i) {
		out << setw(9);
		out << "Exam " << i + 1 << " Average =";
		out << setw(7);
		out << fixed << setprecision(1) << examAverages[i];
		out << endl;

	}
}
void Gradebook::DisplayStudentScores() {
	out << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; ++i) {
		out << setw(20);
		out << studentNames[i];
		out << setw(7);
		for (int j = 0; j < numExams; ++j) {
			out << studentGrades[i][j] << " ";
			out << setw(5);

		}
		
		out << endl;
	}
}