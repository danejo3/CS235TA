//
//  main.cpp
//  Lab01
//
//  Created by Jacob Roberts on 9/16/18.
//  Copyright © 2018 Jacob Roberts. All rights reserved.
//



#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

using namespace std;

int main(int argc, const char * argv[]) {
   //VS_MEM_CHECK               // enable memory leak check
   
   const int NUM_POSSIBLE_GRADES = 5;

   // MARK: - Load Input and Output Data
   if (argc < 3)
   {
      cerr << "Please provide name of input and output files";
      return 1;
   }
   cout << "Input file: " << argv[1] << endl;
   ifstream in(argv[1]);
   if (!in)
   {
      cerr << "Unable to open " << argv[1] << " for input";
      return 2;
   }
   
   cout << "Output file: " << argv[2] << endl;
   ofstream out(argv[2]);
   if (!out)
   {
      in.close();
      cerr << "Unable to open " << argv[2] << " for output";
      return 3;
   }
   
   int num_students;
   int num_exams;
   in >> num_students >> num_exams;
   // Skip the rest of the line
   in.ignore(std::numeric_limits<int>::max(), '\n');
   
   int rows = num_students;
   int cols = num_exams;
   int **myArray = new int*[rows];
   for(int i = 0; i < rows; ++i)
   {
      myArray[i] = new int[cols];
   }
   
   string *studentName = new string[num_students];
   
   for(int i = 0; i < num_students; i++)
   {
      string line;
      getline(in, line);
      size_t p = 0;
      while (!isdigit(line[p])) ++p;   // line[p] is the first digit
      studentName[i] = line.substr(0, p - 1);
      string scores = line.substr(p);
      // Put this into an istringstream
      istringstream iss(scores);
      for(int j = 0; j < num_exams; j++)
      {
         iss >> myArray[i][j];
      }
   }
   
   float examAverages[num_exams];
   float examTotals[num_exams];
   for(int i = 0; i < num_exams; i++) {
      examTotals[i] = 0;
   }
   
   for(int i = 0; i < num_exams; i++){
      for (int j = 0; j < num_students; j++) {
         examTotals[i] += myArray[j][i];
      }
   }
   for(int i = 0; i < num_exams; i++) {
      examAverages[i] = examTotals[i] / (float)num_students;;
   }
   
   
   // Output
   out << "Student Scores:" << endl;
   for (int i = 0; i < num_students; i++)
   {
      string name = studentName[i];
      out << setw(20) << name;
      
      for(int j = 0; j < num_exams; j++) {
         out << fixed << setprecision(0) << setw(6) << myArray[i][j];
      }
      out << endl;
   }
   out << "Exam Averages:" << endl;
   
   for(int i = 0; i < num_exams; i++)
   {
      out << setw(9) << "Exam " << i + 1 << " Average =   " << fixed << setprecision(1) << examAverages[i] << endl;
   }
   
   out << "Student Exam Grades:" << endl;
   
   int (*numberOfLetters)[NUM_POSSIBLE_GRADES] = new int[num_exams][NUM_POSSIBLE_GRADES];
   
   for(int i = 0; i < num_exams; i++) {
      for(int j = 0; j < NUM_POSSIBLE_GRADES; j++) {
         numberOfLetters[i][j] = 0;
      }
   }
   
   for (int i = 0; i < num_students; i++)
   {
      string name = studentName[i];
      out << setw(20) << name;
      
      for(int j = 0; j < num_exams; j++) {
         string grade;
         float score = myArray[i][j];
         float avg = examAverages[j];
         float test = score - avg;
         if (test <= 5 && test >= -5)
         {
            grade = "C";
            numberOfLetters[j][2] = numberOfLetters[j][2] + 1;
         } else if (test >5 && test < 15)
         {
            grade = "B";
            numberOfLetters[j][1] = numberOfLetters[j][1] + 1;
         } else if (test >= 15)
         {
            grade = "A";
            numberOfLetters[j][0] = numberOfLetters[j][0] + 1;
         } else if (test < -5 && test > -15)
         {
            grade = "D";
            numberOfLetters[j][3] = numberOfLetters[j][3] + 1;
         } else {
            grade = "E";
            numberOfLetters[j][4] = numberOfLetters[j][4] + 1;
         }
         
         out << fixed << setprecision(0) << setw(5) << myArray[i][j] << "(" << grade << ")";
      }
      out << endl;
   }
   
   out << "Exam Grades:" << endl;
   for (int i = 0;i < num_exams; i++) {
      out << setw(10) << "Exam  " << i+1 << " ";
      out << setw(4) << numberOfLetters[i][0] << "(A)";
      out << setw(4) << numberOfLetters[i][1] << "(B)";
      out << setw(4) << numberOfLetters[i][2] << "(C)";
      out << setw(4) << numberOfLetters[i][3] << "(D)";
      out << setw(4) << numberOfLetters[i][4] << "(E)";
      out << endl;
   }
   
   out << "Student Final Grades:" << endl;
   
   float studentAvg[num_students];
   for(int i = 0; i < num_students; i++) {
      studentAvg[i] = 0.0;
   }
   
   for(int i = 0; i < num_students; i++ ) {
      for (int j = 0; j < num_exams; j++) {
         studentAvg[i] += myArray[i][j];
      }
      studentAvg[i] = studentAvg[i] / num_exams;
   }
   
   float averageScore = 0.0;
   for(int i = 0; i < num_students; i++) {
      averageScore += studentAvg[i];
   }
   averageScore = averageScore / (float)num_students;
   
   for (int i = 0; i < num_students; i++)
   {
      string name = studentName[i];
      out << setw(20) << name << "  ";
      
      string grade;
      float score = studentAvg[i];
      float avg = averageScore;
      float test = score - avg;
      if (test <= 5 && test >= -5)
      {
         grade = "C";
      } else if (test >5 && test < 15)
      {
         grade = "B";
      } else if (test >= 15)
      {
         grade = "A";
      } else if (test < -5 && test > -15)
      {
         grade = "D";
      } else {
         grade = "E";
      }
      
      out << fixed << setprecision(1) << score << "(" << grade << ")";
      
      out << endl;
   }
   out << "Class Average Score = " << fixed << setprecision(1) << averageScore;
   // Dealloc
   delete[] studentName;
   for(int i = 0; i < rows; ++i)
   {
      delete [] myArray[i];
   }
   delete [] myArray;

   delete [] numberOfLetters;
   
   return 0;
}
