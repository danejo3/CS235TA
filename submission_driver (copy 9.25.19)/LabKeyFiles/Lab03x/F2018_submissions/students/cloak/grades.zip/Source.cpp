#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>
using namespace std;

int main(int argc, char* argv[]) {

	//verify there are input and output files provided
	if (argc < 3) {
		cerr << "Please provide name of input and output files";
		return 1;
	}

	//verify the input file is open
	//cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in) {
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}

	//verify the output file is open
	//cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out) {
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	int numStudents;
	in >> numStudents;

	string* studentNames = new string[numStudents];

	int numExams;
	in >> numExams;

	//cout << "Rows: " << numStudents << endl;

	//create 2D array
	double** examScores = new double*[numStudents];
	for (int i = 0; i < numStudents; ++i) {
		examScores[i] = new double[numExams];
	}

	//populate arrays and output initial values read from the input file
	int i = 0;
	int j = 0;
	string firstName;
	string lastName;
	string fullName;
	out << "Student Scores:" << endl;
	while (i < numStudents) {
		for (j = 0; j < 2; ++j) {
			if (j == 0) {
				in >> firstName;
			}
			else if (j == 1) {
				in >> lastName;
				fullName = firstName + " " + lastName;
				studentNames[i] = fullName;
				out << studentNames[i];
				//string temp = studentNames[i];
			}
		}
		for (j = 0; j < numExams; ++j) {
			in >> examScores[i][j];
			out << " " << examScores[i][j];
			//double temp = examScores[i][j];
		}
		out << endl;
		++i;
	}

	//check studentName array contents
	/*cout << "Students:" << endl;
	for (int i = 0; i < numStudents; ++i) { 
		cout << studentNames[i] << endl;
	}*/

	//check examScores array contents
	/*cout << "Exam Scores:" << endl;
	for (int i = 0; i < numStudents; ++i) {
		for (int j = 0; j < numExams; ++j) {
			cout << examScores[i][j] << endl;
		}
	}*/

	//calculate and output exam averages
	out << "Exam Averages:" << endl;
	double* examAverage = new double[numExams];
	for (int i = 0; i < numExams; ++i) {
		double totalScore = 0;
		for (int j = 0; j < numStudents; ++j) {
			totalScore += examScores[j][i];
		}
		examAverage[i] = totalScore / numStudents;
		out << fixed << setprecision(1);
		out << "Exam " << i + 1 << " Average = " << examAverage[i] << endl;
		
	}

	//output each student's exam grades in evenly spaced columns
	out << "Student Exam Grades:" << endl;
	out << setprecision(0);
	for (int i = 0; i < numStudents; ++i) {
		out << setw(20);
		out << studentNames[i];
		for (int j = 0; j < numExams; ++j) {
			out << setw(7);
			out << examScores[i][j];
			if (examScores[i][j] <= examAverage[j] - 15.0) {
				out << "(E)";
			}
			else if (examScores[i][j] < examAverage[j] - 5.0) {
				out << "(D)";
			}
			else if (examScores[i][j] <= examAverage[j] + 5.0) {
				out << "(C)";
			}
			else if (examScores[i][j] < examAverage[j] + 15.0) {
				out << "(B)";
			}
			else {
				out << "(A)";
			}
		}
		out << endl;
	}

	//output the quantity of each grade for each exam
	out << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; ++i) {
		int A = 0;
		int B = 0;
		int C = 0;
		int D = 0;
		int E = 0;
		out << "Exam " << i + 1;
		for (int j = 0; j < numStudents; ++j) {
			if (examScores[j][i] <= examAverage[i] - 15.0) {
				++E;
			}
			else if (examScores[j][i] < examAverage[i] - 5.0) {
				++D;
			}
			else if (examScores[j][i] <= examAverage[i] + 5.0) {
				++C;
			}
			else if (examScores[j][i] < examAverage[i] + 15.0) {
				++B;
			}
			else {
				++A;
			}
		}
		out << setw(4);
		out << A << "(A)";
		out << setw(4);
		out << B << "(B)";
		out << setw(4);
		out << C << "(C)";
		out << setw(4);
		out << D << "(D)";
		out << setw(4);
		out << E << "(E)";
		out << endl;
	}

	//calculate student's final percentage
	double* studentFinalGrade = new double[numStudents];
	for (int i = 0; i < numStudents; ++i) {
		studentFinalGrade[i] = 0;
		for (int j = 0; j < numExams; ++j) {
			studentFinalGrade[i] += examScores[i][j];
		}
		studentFinalGrade[i] = studentFinalGrade[i] / numExams;
	}

	//calculate class average
	double classAverage = 0;
	for (int i = 0; i < numStudents; ++i) {
		classAverage += studentFinalGrade[i];
	}
	classAverage = classAverage / numStudents;

	//calculate and output student's final grade
	out << "Student Final Grades:" << endl;
	for (int i = 0; i < numStudents; ++i) {
		out << setw(20);
		out << studentNames[i];
		out << setw(7) << setprecision(1);
		out << studentFinalGrade[i];
		if (studentFinalGrade[i] <= classAverage - 15.0) {
			out << "(E)";
		}
		else if (studentFinalGrade[i] < classAverage - 5.0) {
			out << "(D)";
		}
		else if (studentFinalGrade[i] <= classAverage + 5.0) {
			out << "(C)";
		}
		else if (studentFinalGrade[i] < classAverage + 15.0) {
			out << "(B)";
		}
		else {
			out << "(A)";
		}
		out << endl;
	}
	out << "Class Average Score = " << classAverage;

	//delete allocated memory
	for (int i = 0; i < numStudents; ++i) {
		delete[] examScores[i];
	}
	delete[] examScores;

	delete[] studentNames;

	delete[] examAverage;

	delete[] studentFinalGrade;

	in.close();

	out.close();
	
	//system("pause");

	return 0;
}