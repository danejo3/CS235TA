/*
Whatabop Itsyaboi
C S 235 Section 003
Input:
	6 8
	Cody Coder  84 100 100 70 100 80 100 65
	Harry Houdini  77 68 65 100 96 100 86 100
	Harry Potter  100 100 95 91 100 70 71 72
	Mad Mulligun  88 96 100 90 93 100 100 100
	George Washington  100 72 100 76 82 71 82 98
	Abraham Lincoln  93 88 100 100 99 77 76 93
Expected Output:
	Student Scores:
	Cody Coder    84   100   100    70   100    80   100    65
	Harry Houdini    77    68    65   100    96   100    86   100
	Harry Potter   100   100    95    91   100    70    71    72
	Mad Mulligun    88    96   100    90    93   100   100   100
	George Washington   100    72   100    76    82    71    82    98
	Abraham Lincoln    93    88   100   100    99    77    76    93
	Exam Averages:
	Exam 1 Average =  90.3
	Exam 2 Average =  87.3
	Exam 3 Average =  93.3
	Exam 4 Average =  87.8
	Exam 5 Average =  95.0
	Exam 6 Average =  83.0
	Exam 7 Average =  85.8
	Exam 8 Average =  88.0
	Student Exam Grades:
	Cody Coder    84(D)   100(B)   100(B)    70(E)   100(C)    80(C)   100(B)    65(E)
	Harry Houdini    77(D)    68(E)    65(E)   100(B)    96(C)   100(A)    86(C)   100(B)
	Harry Potter   100(B)   100(B)    95(C)    91(C)   100(C)    70(D)    71(D)    72(E)
	Mad Mulligun    88(C)    96(B)   100(B)    90(C)    93(C)   100(A)   100(B)   100(B)
	George Washington   100(B)    72(E)   100(B)    76(D)    82(D)    71(D)    82(C)    98(B)
	Abraham Lincoln    93(C)    88(C)   100(B)   100(B)    99(C)    77(D)    76(D)    93(C)
	Exam Grades:
	Exam 1     0(A)     2(B)     2(C)     2(D)     0(E)
	Exam 2     0(A)     3(B)     1(C)     0(D)     2(E)
	Exam 3     0(A)     4(B)     1(C)     0(D)     1(E)
	Exam 4     0(A)     2(B)     2(C)     1(D)     1(E)
	Exam 5     0(A)     0(B)     5(C)     1(D)     0(E)
	Exam 6     2(A)     0(B)     1(C)     3(D)     0(E)
	Exam 7     0(A)     2(B)     2(C)     2(D)     0(E)
	Exam 8     0(A)     3(B)     1(C)     0(D)     2(E)
	Student Final Grades:
	Cody Coder  87.4(C)
	Harry Houdini  86.5(C)
	Harry Potter  87.4(C)
	Mad Mulligun  95.9(B)
	George Washington  85.1(C)
	Abraham Lincoln  90.8(C)
	Class Average Score = 88.8
*/

#include <iostream>
#include <string>
#include <fstream>
#include <limits>
#include <iomanip>
using namespace std;

int main(int argc, char *argv[])
{
	const int GRADES_POSSIBLE = 5;
	const int NAME_WIDTH = 20;
	const int SCORE_WIDTH = 6;
	int numStudents;
	int numExams;

	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	in >> numStudents >> numExams;
	in.ignore(std::numeric_limits<int>::max(), '\n');

	string* studentNames = new string[numStudents];
	double** examScores = new double*[numStudents];
	for (int i = 0; i < numStudents; i++)
	{
		examScores[i] = new double[numExams];
	}

	out << "Student Scores:" << endl;

	for (int i = 0; i < numStudents; i++)
	{
		string firstName;
		string lastName;

		in >> firstName >> lastName;
		studentNames[i] = firstName + " " + lastName;

		out << setw(NAME_WIDTH) << studentNames[i];

		for (int j = 0; j < numExams; j++)
		{
			in >> examScores[i][j];
			out << setw(SCORE_WIDTH) << examScores[i][j];
		}

		out << endl;

		in.ignore(std::numeric_limits<int>::max(), '\n');
	}

	in.close();

	out << "Exam Averages:" << endl;

	out << fixed << setprecision(1);

	double* examAverages = new double[numExams];

	for (int i = 0; i < numExams; i++)
	{
		out << setw(NAME_WIDTH) << "Exam " << i + 1 << " Average =";

		double totalScore = 0;
		for (int j = 0; j < numStudents; j++)
		{
			totalScore += examScores[j][i];
		}

		examAverages[i] = totalScore / numStudents;

		out << setw(SCORE_WIDTH) << examAverages[i] << endl;
	}

	out << "Student Exam Grades:" << endl;

	out << setprecision(0);

	int** examGrades = new int*[numExams];
	for (int i = 0; i < numExams; i++)
	{
		examGrades[i] = new int[GRADES_POSSIBLE];
		for (int j = 0; j < GRADES_POSSIBLE; j++)
		{
			examGrades[i][j] = 0;
		}
	}

	for (int i = 0; i < numStudents; i++)
	{
		out << setw(NAME_WIDTH) << studentNames[i];

		for (int j = 0; j < numExams; j++)
		{
			out << setw(SCORE_WIDTH) << examScores[i][j];
			if (examScores[i][j] >= examAverages[j] + 15)
			{
				out << "(A)";
				examGrades[j][0]++;
			}
			else if (examScores[i][j] > examAverages[j] + 5)
			{
				out << "(B)";
				examGrades[j][1]++;
			}
			else if (examScores[i][j] >= examAverages[j] - 5)
			{
				out << "(C)";
				examGrades[j][2]++;
			}
			else if (examScores[i][j] >= examAverages[j] - 15)
			{
				out << "(D)";
				examGrades[j][3]++;
			}
			else
			{
				out << "(E)";
				examGrades[j][4]++;
			}
		}

		out << endl;

	}

	delete[] examAverages;

	out << "Exam Grades:" << endl;

	for (int i = 0; i < numExams; i++)
	{
		out << "\tExam " << i + 1;

		for (int j = 0; j < GRADES_POSSIBLE; j++)
		{
			out << setw(SCORE_WIDTH) << examGrades[i][j];
			switch (j)
			{
				case 0:
					out << "(A)";
					break;
				case 1:
					out << "(B)";
					break;
				case 2:
					out << "(C)";
					break;
				case 3:
					out << "(D)";
					break;
				default:
					out << "(E)";
					break;
			}
		}

		out << endl;

	}

	for (int i = 0; i < numExams; i++)
	{
		delete[] examGrades[i];
	}

	delete[] examGrades;

	out << "Student Final Grades:" << endl;

	out << setprecision(1);

	double* studentAverages = new double[numStudents];
	double classAverage = 0;

	for (int i = 0; i < numStudents; i++)
	{
		double totalScore = 0;
		for (int j = 0; j < numExams; j++)
		{
			totalScore += examScores[i][j];
		}

		studentAverages[i] = totalScore / numExams;
	}

	for (int i = 0; i < numStudents; i++)
	{
		classAverage = classAverage + studentAverages[i];
	}

	classAverage = classAverage / numStudents;

	for (int i = 0; i < numStudents; i++)
	{
		delete[] examScores[i];
	}

	delete[] examScores;

	for (int i = 0; i < numStudents; i++) {
		out << setw(NAME_WIDTH) << studentNames[i];

		out << setw(SCORE_WIDTH) << studentAverages[i];
		if (studentAverages[i] >= classAverage + 15)
		{
			out << "(A)";
		}
		else if (studentAverages[i] > classAverage + 5)
		{
			out << "(B)";
		}
		else if (studentAverages[i] >= classAverage - 5)
		{
			out << "(C)";
		}
		else if (studentAverages[i] >= classAverage - 15)
		{
			out << "(D)";
		}
		else
		{
			out << "(E)";
		}

		out << endl;
	}

	out << "Class Average Score = " << classAverage;


	delete[] studentNames;
	delete[] studentAverages;

	return 0;
}