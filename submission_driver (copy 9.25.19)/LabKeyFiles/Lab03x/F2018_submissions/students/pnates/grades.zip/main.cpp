#include "stdlib.h"
#include <fstream>
#include <string>
#include <iomanip>
#include <iostream>
#include <sstream>
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;





int main(int argc,char* argv[])
{
    VS_MEM_CHECK
    //open the files
    ifstream in(argv[1]);
    ofstream out(argv[2]);
    
    
    if (out.is_open() && in.is_open())
    {
        int peopleNumber = 0;
        int testNumber = 0;
        string words;
        
        
        getline(in, words);
        stringstream line(words); //that puts the first line into a stream
        line >> peopleNumber;
        line >> testNumber;
        
        string* names = new string[peopleNumber];
        
        
        int rows = peopleNumber;
        int cols = testNumber;
        
        int **scores = new int *[rows];
        
        for(int i = 0; i < rows; ++i)
        {
            scores[i] = new int[cols];
        }
        
        out << "Student Scores:" << endl;
        int lineNumber = 0;
        while(getline(in, words)) //that puts a line of the file into the string line
        {
            stringstream line(words); //that puts the line into a stream again
            
            string name1;//this part inputs the name
            string name2;
            line >> name1 >> name2;
            names[lineNumber] = name1 + " " + name2;
            out << right << setw(20) << names[lineNumber];
            
            int testCounter = 0; //this part inputs the test scores
            while (testCounter < testNumber)
            {
                line >> scores[lineNumber][testCounter];
                out << right << setw(5) <<scores[lineNumber][testCounter] << " ";
                testCounter++;
            }
            out << endl;
            lineNumber++;
        }
        in.close(); //in has now inputted everything
        
        
        //this next part does the test averages section
        out << "Exam Averages:" << endl;
        int testCounter = 0;
        int scoreCounter = 0;
        double* average = new double[testNumber];// the average of each test goes in this array for future use
        
        for(int i = 0; i < testNumber; ++i)
        {
                average[i] = 0;
        }
        
        while (scoreCounter < testNumber)
        {
            
            testCounter = 0;
            
            while (testCounter < peopleNumber)
            {
                average[scoreCounter] = average[scoreCounter] + scores[testCounter][scoreCounter];
                testCounter++;
            }
            double testNumberDouble = peopleNumber;
            average[scoreCounter] = average[scoreCounter] / testNumberDouble;
            out << right << setw(8) << "Exam " << scoreCounter + 1 << " Average =   " << fixed << setprecision(1) << average[scoreCounter] << endl;
            scoreCounter++;
        }
        
        //here begins the student exam grades with letter grades
        
        out << "Student Exam Grades:" << endl;
        rows = testNumber;
        cols = 5;
        int **letterGradeTracker = new int *[rows];
        
        for(int i = 0; i < rows; ++i)
        {
            letterGradeTracker[i] = new int[cols];
            for (int j = 0; j< cols; j++)
            {
                letterGradeTracker[i][j] = 0;
            }
        }
        
        double grade = 0;
        testCounter = 0;
        int personCounter = 0;
        string letterGrade;
        double a = 0;
        double b = 0;
        double c = 0;
        double d = 0;
        while (personCounter < peopleNumber)
        {
            out << right << setw(20) << names[personCounter];
            testCounter = 0;
            while (testCounter < testNumber)
            {
                grade = scores[personCounter][testCounter]; // this part tells for each test what would be the letter grade
                a = average[testCounter] + 15;
                b = average[testCounter] + 5;
                c = average[testCounter] - 5;
                d = average[testCounter] - 15;
                
                if (grade > a)
                {
                    letterGrade = "A";
                    letterGradeTracker[testCounter][0] ++;
                }
                else if (grade > b)
                {
                    letterGrade = "B";
                    letterGradeTracker[testCounter][1] ++;
                }
                else if (grade > c)
                {
                    letterGrade = "C";
                    letterGradeTracker[testCounter][2] ++;
                }
                else if (grade > d)
                {
                    letterGrade = "D";
                    letterGradeTracker[testCounter][3] ++;
                }
                else if (grade <= d)
                {
                    letterGrade = "E";
                    letterGradeTracker[testCounter][4] ++;
                }
                
                out << right << setw(6) << scores[personCounter][testCounter] << "(" << letterGrade << ")";
                
                testCounter++;
            }
            
            out << endl;
            
            personCounter++;
        }
        
        //this part outputs the exam grades section
        int letterGradeNumber = 5;
        int letterGradeCounter = 0;
        testCounter = 0;
        string letterGrades[5] = {"A", "B", "C", "D", "E"};
        out << "Exam Grades:" << endl;
        
        while (testCounter < testNumber)
        {
            letterGradeCounter = 0;
            out << right << setw(8) << "Exam" << "  " << testCounter + 1;
            while (letterGradeCounter < letterGradeNumber)
            {
                out << right << setw(5) << letterGradeTracker[testCounter][letterGradeCounter];
                out << "(" << letterGrades[letterGradeCounter] << ")";
                letterGradeCounter++;
            }
            out << endl;
            testCounter++;
        }
        
        double* personAverage = new double[peopleNumber];
        personCounter = 0;
        while (personCounter < peopleNumber)
        {
            grade = 0;
            testCounter = 0;
            while(testCounter < testNumber)
            {
                grade = grade + scores[personCounter][testCounter];
                testCounter++;
            }
            grade = grade / testNumber;
            personAverage[personCounter] = grade;
            personCounter++;
        }
        
        double classAverage = 0;
        personCounter = 0;
        while (personCounter < peopleNumber)
        {
            classAverage = classAverage + personAverage[personCounter];
            personCounter ++;
        }
        classAverage = classAverage / peopleNumber;
        
        a = classAverage + 15;
        b = classAverage + 5;
        c = classAverage - 5;
        d = classAverage - 15;
        
        out << "Student Final Grades:" << endl;
        
        personCounter = 0;
        while (personCounter < peopleNumber)
        {
            grade = personAverage[personCounter];
            
            
            if (grade > a)
            {
                letterGrade = "A";
            }
            else if (grade > b)
            {
                letterGrade = "B";
            }
            else if (grade > c)
            {
                letterGrade = "C";
            }
            else if (grade > d)
            {
                letterGrade = "D";
            }
            else if (grade <= d)
            {
                letterGrade = "E";
            }
            
            out << right << setw(20) << names[personCounter] << right << setw(6) << personAverage[personCounter];
            out << "(" << letterGrade << ")" << endl;
            
            personCounter++;
        }
        out << "Class Average Score = " << classAverage;
        //now close out
        rows = testNumber;
        for(int i = 0; i < rows; ++i)
        {
            delete[] letterGradeTracker[i];
        }
        delete [] letterGradeTracker;
        
        rows = peopleNumber;
        for(int i = 0; i < rows; ++i)
        {
            delete [] scores[i];
        }
        delete [] scores;
        
        delete [] average;
        delete [] personAverage;
        delete [] names;
        out.close();
    }
    
    
    else
    {
        cout << "it didnt work!" << endl;
        return 1;
    }
         
    return 0;
}
