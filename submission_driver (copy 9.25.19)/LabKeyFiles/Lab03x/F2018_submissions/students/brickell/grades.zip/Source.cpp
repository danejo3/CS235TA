#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
using namespace std;

int main(int argc, char* argv[]) {
	string line;
	int rows;
	int cols;
	ifstream in(argv[1]);
	ofstream out(argv[2]);
	if (in.is_open()) {
		getline(in, line);
		stringstream s(line);
		s >> rows;
		s >> cols;
		int **testScores = new int*[rows];
		for (int i = 0; i < rows; ++i)
		{
			testScores[i] = new int[cols];
		}
		string* studentNames = new string[rows];
		int j = 0;
		while (getline(in, line)) {
			stringstream s(line);
			string firstName;
			string lastName;
			s >> firstName >> lastName;
			studentNames[j] = firstName + " " + lastName;
			int k = 0;
			int testScore;
			while (s >> testScore) {
				testScores[j][k] = testScore;
				k++;
			}
			j++;
		}
		in.close();
		double *testAverages = new double[cols];
		for (int i = 0; i < cols; i++) {
			testAverages[i] = 0;
		}
		out << "Student Scores:" << endl;
		for (int i = 0; i < rows; i++) {
			out << setw(20) << studentNames[i] << " ";
			for (int j = 0; j < cols; j++) {
				out << fixed << setprecision(0) << setw(6) << testScores[i][j];
				testAverages[j] += static_cast<double>(testScores[i][j]) / rows;
			}
			out << endl;
		}
		out << "Exam Averages:" << endl;
		for (int i = 0; i < cols; i++) {

			out << setw(9) << "Exam " << i + 1 << " Average =";
			out << fixed << setprecision(1) << setw(6) << testAverages[i] << endl;
		}
		out << "Student Exam Grades:" << endl;
		for (int i = 0; i < rows; i++) {
			out << setw(20) << studentNames[i] << " ";
			for (int j = 0; j < cols; j++) {
				out << fixed << setprecision(0) << setw(6) << testScores[i][j];
				out << "(";
				if (abs(testScores[i][j] - testAverages[j]) <= 5) {
					out << "C";
				}
				if (testScores[i][j] - testAverages[j] > 5 && testScores[i][j] - testAverages[j] <= 15) {
					out << "B";
				}
				if (testScores[i][j] - testAverages[j] < -5 && testScores[i][j] - testAverages[j] >= -15) {
					out << "D";
				}
				if (testScores[i][j] - testAverages[j] > 15) {
					out << "A";
				}
				if (testScores[i][j] - testAverages[j] < -15) {
					out << "E";
				}
				out << ")";
			}
			out << endl;
		}

	}
	else {
		cout << "Error";
	}
}
