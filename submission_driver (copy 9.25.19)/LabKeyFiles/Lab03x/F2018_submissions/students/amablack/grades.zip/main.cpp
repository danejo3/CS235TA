#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#ifdef _MSC_VER //memory leak check
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif
using namespace std;

int main(int argc, char* argv[]) {
	VS_MEM_CHECK
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}
	
	int numStudents = 0;
	int numExams = 0;
	in >> numStudents >> numExams;
	in.ignore(std::numeric_limits<int>::max(), '\n');

	int rows = numStudents;
	int cols = numExams;
	int **studentScores = new int*[rows]; // create dynamic array of scores
	for (int i = 0; i < rows; i++)
	{
		studentScores[i] = new int[cols];
	}

	out << "Student Scores:" << endl;
	string* studentNames;
	studentNames = new string[rows]; // create array of student names
	for (int i = 0; i < rows; i++) { //continue creating array of scores
		string line;
		string firstName;
		string lastName;
		int scores;

		getline(in, line);
		istringstream in(line); //populate array of student names before getting the scores
		in >> firstName >> lastName;
		string fullName = firstName + " " + lastName;
		studentNames[i] = fullName;
		out << setw(20) << studentNames[i] << " ";

		size_t p = 0; //create a string for the list of scores (starting after the student names)
		while (!isdigit(line[p])) p++;
		string fragment = line.substr(p);
		istringstream iss(fragment);
		for (int j = 0; j < cols; j++) { //populate array of scores with student scores
			iss >> scores;
			studentScores[i][j] = scores;
			out << fixed << setprecision(0) << setw(6) << studentScores[i][j];
		}
		out << endl;
		iss.ignore(std::numeric_limits<int>::max(), '\n');
	}

	double* averageScore;//Averaging Exam scores
	averageScore = new double[numExams]; //create array to hold the average scores so they can be used later
	out << "Exam Averages:" << endl;
	for (int j = 0; j < cols; j++) {
		double sumScore = 0;
		for (int i = 0; i < rows; i++) {
			sumScore = sumScore + studentScores[i][j];
		}
		averageScore[j] = sumScore / rows;
		out << fixed << setprecision(1) << setw(6) << "Exam " << j + 1 << " Average = " << averageScore[j] << endl;
	}

	out << "Student Exam Grades:" << endl; //Determining Student Exam Grades
	string **grades = new string*[rows]; //create array to hold the letter grades, will be used later
	for (int i = 0; i < rows; i++) {
		out << setw(20) << studentNames[i] << " ";
		grades[i] = new string[cols];
		for (int j = 0; j < cols; j++) {
			out << fixed << setprecision(0) << setw(6) << studentScores[i][j];
			if (studentScores[i][j] > averageScore[j] + 15) {
				out << "(A)";
				grades[i][j] = "A";
			}
			else if (studentScores[i][j] < averageScore[j] - 15) {
				out << "(E)";
				grades[i][j] = "E";
			}
			else if (studentScores[i][j] > averageScore[j] + 5) {
				out << "(B)";
				grades[i][j] = "B";
			}
			else if (studentScores[i][j] < averageScore[j] - 5) {
				out << "(D)";
				grades[i][j] = "D";
			}
			else {
				out << "(C)";
				grades[i][j] = "C";
			}
		}
		out << endl;
	}

	out << "Exam Grades:" << endl; //Exam Grades
	for (int j = 0; j < cols; j++)
	{
		int numA = 0;
		int numB = 0;
		int numC = 0;
		int numD = 0;
		int numE = 0;
		out << setw(20) << "Exam " << j + 1 << " ";
		for (int i = 0; i < rows; i++) {
			if (grades[i][j] == "A") {
				numA = numA + 1;
			}
			else if (grades[i][j] == "B") {
				numB = numB + 1;
			}
			else if (grades[i][j] == "C") {
				numC = numC + 1;
			}
			else if (grades[i][j] == "D") {
				numD = numD + 1;
			}
			else if (grades[i][j] == "E") {
				numE = numE + 1;
			}
		}
		out << numA << "(A)" << numB << "(B)" << numC << "(C)" << numD << "(D)" << numE << "(E)" << endl;
	}

	for (int i = 0; i < rows; i++)
	{
		delete[] studentScores[i];
	}
	delete[] studentScores;
	for (int i = 0; i < rows; i++)
	{
		delete[] grades[i];
	}
	delete[] grades;
	delete[] studentNames;
	delete[] averageScore;
	
	//system("pause");
	return 0;
}