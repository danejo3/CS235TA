#include <iostream>
#include <fstream>
#include <string>
#include <ios>
#include<cstring>
#include <sstream>
#include <iomanip>

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;

void inputGrades(ifstream &in,int **myArray, string *studentNames, int &num_students, int &num_exams);
void calcAverages(int **myArray,double *examAverages, int &num_students, int &num_exams);
void curveGrades(int **myArray,string *studentNames, char **examLetterGrades, double *examAverages, int &num_students, int &num_exams);
void letterCounter(char **examLetterGrades,int **numLetterExams, int &numstudents, int &num_exams);
void printStudentScores(int **myArray, string *studentNames, int num_students, int num_exams, ofstream& out);
void printExamAverages(double *examAverages, int num_exams, ofstream& out);
void printStudentExamGrades(int **myArray, string *studentNames, char **examLetterGrades, int num_students, int num_exams, ofstream& out);
void printExamGrades(int **numLettersExam, int num_exams, ofstream& out);
void printStudentFinalGrades(int **myArray, string *studentNames, int num_students, int num_exams, ofstream& out);


int main(int argc, char *argv[])
{
	VS_MEM_CHECK;

	//Check if there are aguments for the program and if they are valid
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}


	int num_students;
	int num_exams;
	in >> num_students >> num_exams;
	in.ignore(std::numeric_limits<int>::max(), '\n');


	//Initiate empty array to store the percentages each student achieved on each exam
	int **myArray = new int*[num_students];
	for (int i = 0; i < num_students; ++i)
	{
		myArray[i] = new int[num_exams];
	}

	//Initiate empty array for storing what the students' curved letter grades are
	char **examLetterGrades = new char*[num_students];
	for (int i = 0; i < num_students; ++i)
	{
		examLetterGrades[i] = new char[num_exams];
	}

	//Initiate empty array for storing how many of each letter grade amounts occurs on each test and set to 0
	int **numLettersExam = new int*[num_exams];
	for (int i = 0; i < num_exams; ++i)
	{
		numLettersExam[i] = new int[5];
		for (int z = 0; z < 5; z++)
		{
			numLettersExam[i][z] = 0;
		}
	}


	//Create array to store names of students
	string *studentNames = new string[num_students];
	double *examAverages = new double[num_exams];


	//Take in values from input into array
	inputGrades(in, myArray, studentNames, num_students, num_exams);


	//Calculate the averages across all students in each exam
	calcAverages(myArray, examAverages, num_exams, num_students);

	//Determine what the letter grade associated with each score is
	curveGrades(myArray, studentNames, examLetterGrades, examAverages, num_students, num_exams);

	//Figure out how many of each letter grade occured on each exam
	letterCounter(examLetterGrades, numLettersExam, num_students, num_exams);

	//Print all the information required for output file
	printStudentScores(myArray, studentNames, num_students, num_exams, out);
	printExamAverages(examAverages, num_exams, out);
	printStudentExamGrades(myArray, studentNames, examLetterGrades, num_students, num_exams, out);
	printExamGrades(numLettersExam, num_exams, out);
	printStudentFinalGrades(myArray, studentNames, num_students, num_exams, out);

	for (int i = 0; i < num_students; ++i)
	{
		delete[] myArray[i];
		delete[] examLetterGrades[i];

		/*if (i < num_exams)
		{
			delete[] numLettersExam[i];
		}*/
	}
	for (int i = 0; i < num_exams; ++i)
	{
		delete[] numLettersExam[i];
	}
		delete[] myArray;
		delete[] examLetterGrades;
		delete[] numLettersExam;
		delete[] studentNames;
		delete[] examAverages;
	return 0;
	/*for (int i = 0; i < num_students; ++i)
	{
		delete[] myArray[i];
	}
	delete[] myArray;*/
}



void inputGrades(ifstream &in, int ** myArray, string *studentNames, int &num_students, int &num_exams)
{
	for (int i = 0; i < num_students; i++)
	{
		int student = i;
		string line;
		getline(in, line);
		string firstname;
		string lastname;
		string fullname;
		istringstream ss(line);
		ss >> firstname >> lastname;
		fullname = firstname + " " + lastname;
		studentNames[i] = fullname;
		for (int i = 0; i < num_exams; i++)
		{
			int testscore;
			ss >> testscore;
			myArray[student][i] = testscore;
		}
	}
}



void calcAverages(int ** myArray, double * examAverages,int &num_exams, int &num_students)
{
	for (int z = 0; z < num_exams; z++)
	{
		double totalsum = 0;
		for (int i = 0; i < num_students; i++)
		{
			totalsum += myArray[i][z];
		}
		examAverages[z] = totalsum / num_students;
	}
}



void curveGrades(int ** myArray, string *studentNames, char **examLetterGrades, double * examAverages, int & num_students, int & num_exams)
{
	for (int i = 0; i < num_students; i++)
	{
		for (int z = 0; z < num_exams; z++)
		{
			int mygrade = myArray[i][z];
			double classgrade = examAverages[z];
			double diff = mygrade - classgrade; //Determine what the difference is between the average of the class and the individual's test score
			if (diff <= 5 && diff >= -5)	//Convert that number to a letter grade and store to separate array
			{
				examLetterGrades[i][z] = 'C';
			}
			else if (diff <= 15 && diff > 5)
			{
				examLetterGrades[i][z] = 'B';
			}
			else if (diff >= -15 && diff < -5)
			{
				examLetterGrades[i][z] = 'D';
			}
			else if (diff < -15)
			{
				examLetterGrades[i][z] = 'E';
			}
			else if (diff > 15 && diff <= 25)
			{
				examLetterGrades[i][z] = 'A';
			}
			else
			{
				examLetterGrades[i][z] = '?';
			}
		}
		cout << endl;
	}
}



//Go through array that stored letter grades and count how many of each there are; save to an array
void letterCounter(char ** examLetterGrades, int ** numLettersExam, int &num_students, int &num_exams)
{
	for (int i = 0; i < num_students; i++)	
	{
		for (int z = 0; z < num_exams; z++)
		{
			switch (examLetterGrades[i][z])
			{
			case 'A':
				numLettersExam[z][0] += 1;
				break;
			case 'B':
				numLettersExam[z][1] += 1;
				break;
			case 'C':
				numLettersExam[z][2] += 1;
				break;
			case 'D':
				numLettersExam[z][3] += 1;
				break;
			case 'E':
				numLettersExam[z][4] += 1;
				break;
			}
		}
	}
}



void printStudentScores(int ** myArray, string * studentNames,int num_students, int num_exams, ofstream& out)
{
	out << right << "Student Scores:" << endl;
	for (int i = 0; i < num_students; i++)
	{
		out << setw (20) << studentNames[i];
		for (int z = 0; z < num_exams; z++)
		{
			out << setw(6) << myArray[i][z] << " ";
		}
		out << endl;
	}
}



void printExamAverages(double * examAverages, int num_exams, ofstream& out)
{
	out << "Exam Averages:" << endl;
	for (int i = 0; i < num_exams; i++)
	{
		out << " Exam " << (i+1) << " Average = ";
		out << setprecision(1) << fixed << examAverages[i] << endl;

	}
}



void printStudentExamGrades(int ** myArray, string * studentNames, char ** examLetterGrades, int num_students, int num_exams, ofstream& out)
{
	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < num_students; i++)
	{
		out << setw(20) << studentNames[i];
		for (int z = 0; z < num_exams; z++)
		{
			out << setw(6) << myArray[i][z] << "(" << examLetterGrades[i][z] << ")";
		}
		out << endl;
	}
}



void printExamGrades(int ** numLettersExam, int num_exams, ofstream& out)
{
	out << "Exam Grades:" << endl;
	string letters = "ABCDE";
	for (int i = 0; i < num_exams; i++)
	{
		out << setw (10) << right << "Exam  " << (i + 1) << "     ";
		for (int z = 0; z < 5; z++)
		{
			out << numLettersExam[i][z] << "(" << letters[z] << ")  ";
		}
		out << endl;
	}
}

void printStudentFinalGrades(int ** myArray, string *studentNames, int num_students, int num_exams, ofstream& out)
{
	out << "Student Final Grades: " << endl;
	double *studentAvg = new double[num_students];
	for (int i = 0; i < num_students; i++)
	{
		double totalscores = 0;
		for (int z = 0; z < num_exams; z++)
		{
			totalscores += myArray[i][z];
		}
		double avg = totalscores / num_exams;
		studentAvg[i] = avg;

	}
	double totalAverage = 0;
	for (int i = 0; i < num_students; i++)
	{
		totalAverage += studentAvg[i];
	}
	totalAverage = totalAverage / num_students;
	for (int i = 0; i < num_students; i++)
	{
		out << setw(20) << right << studentNames[i] << " ";

		{
			out << setprecision(1) << fixed << studentAvg[i] << " ";
			double mygradeavg = studentAvg[i];
			double diff = mygradeavg - totalAverage; //Determine what the difference is between the average of the class and the individual's test score
			if (diff <= 5 && diff >= -5)	//Convert that number to a letter grade and store to separate array
			{
				out << "(C)" << endl;
			}
			else if (diff <= 15 && diff > 5)
			{
				out << "(B)" << endl;
			}
			else if (diff >= -15 && diff < -5)
			{
				out << "(D)" << endl;
			}
			else if (diff < -15)
			{
				out << "(E)" << endl;
			}
			else if (diff > 15 && diff <= 25)
			{
				out << "(A)" << endl;
			}
		}
	}
	out << "Class Average Score = " << setprecision(1) << totalAverage;
	delete[] studentAvg;
}

