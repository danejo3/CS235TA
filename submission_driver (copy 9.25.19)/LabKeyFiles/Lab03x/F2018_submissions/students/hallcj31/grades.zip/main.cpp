/*
Cliff Fittr
Section 3
Professor Paul Roper
Lab 1: Grades
Test Case 1:
5 5
Cloud Strife 90 66 89 50 1
Maria Traydor 99 89 85 95 100
Cliff Fittr 100 100 100 100 50
Ashelia Dalmasca 95 82 76 88 96
Brigitte Lindholm 100 50 100 50 100

Expected Output:
Exam Grades:
	Exam 1	0(A)	0(B)	4(C)	1(D)	0(E)
	Exam 2	1(A)	1(B)	1(C)	1(D)	1(E)
	Exam 3	0(A)	2(B)	2(C)	1(D)	0(E)
	Exam 4	2(A)	1(B)	0(C)	0(D)	2(E)
	Exam 5	3(A)	0(B)	0(C)	0(D)	2(E)
Student Final Grades:
Cloud Strife	59.2(E)
Maria Traydor	93.6(B)
Cliff Fittr	90.0(B)
Ashelia Dalmasca	87.4(B)
Brigitte Lindholm	80.0(C)
Class Average Score = 82.0
Result: Passed
*/

#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>
using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif
string WhatIsMyGrade(double average, double studentScore)
{
	const double LARGE_INTERVAL = 15.0;
	const double SMALL_INTERVAL = 5.0;
	if ((studentScore <= average + SMALL_INTERVAL) && (studentScore >= average - SMALL_INTERVAL))
		return "C";
	else if ((studentScore > average + SMALL_INTERVAL) && (studentScore < average + LARGE_INTERVAL))
		return "B";
	else if ((studentScore < average - SMALL_INTERVAL) && studentScore > average - LARGE_INTERVAL)
		return "D";
	else if (studentScore > average + LARGE_INTERVAL)
		return "A";
	else if (studentScore < average - LARGE_INTERVAL)
		return "E";
}

int main(int argc, char* argv[])
{
	const int REQUIRED_ROUND = 1;
	const int REQUIRED_WIDTH = 6;
	const int WHOLE_PRECISION = 0;
	const int NUM_LETTER_GRADES = 5;
	const int A_GRADE = 0;
	const int B_GRADE = 1;
	const int C_GRADE = 2;
	const int D_GRADE = 3;
	const int E_GRADE = 4;
	const int OPEN_ADDRESS = 1;
	const int WRITE_TO_ADDRESS = 2;
	VS_MEM_CHECK               // enable memory leak check
	//	write << argv[1] << endl;	Test what the text file output is.

	ifstream read(argv[OPEN_ADDRESS]);
	ofstream write(argv[WRITE_TO_ADDRESS]);

	// initialize num students and exams to zero
	int numStudents = 0;
	int numExams = 0;
	read >> numStudents >> numExams;
	read.ignore(numeric_limits<int>::max(), '\n'); //skip rest of the line
	//write << numStudents << " " << numExams; //only for testing for correct values
	//Create the arrays for names and the exam scores
	string *studentNames = new string[numStudents];
	double **allScores = new double*[numStudents];
	for (int i = 0; i < numStudents; ++i)
	{
		allScores[i] = new double[numExams];
	}

	if (read.is_open())
	{
		write << "Student Scores:" << endl;
		if (!read.eof())
		{
			//Parse the names, and the scores into the arrays
			for (int i = 0; i < numStudents; i++)
			{
				string firstName;
				string lastName;
				read >> firstName >> lastName;
				string fullName = firstName + " " + lastName;
				studentNames[i] = fullName;
				write << studentNames[i] << "\t";
				for (int j = 0; j < numExams; j++)
				{
					read >> allScores[i][j];
					write << " " << allScores[i][j] << " ";
				}
				write << endl; //hard return to separate the different scores.
			}
		}
		read.close();
	}
	write << "Exam Averages: " << endl;
	double *ExamAverages = new double[numExams];
	// creating a two dimemnsional array. Each row is a different exam. Each column represents a letter grade
	int **letterGrades = new int*[numExams];
	for (int i = 0; i < numExams; ++i)
	{
		letterGrades[i] = new int[NUM_LETTER_GRADES];
		for (int k = 0; k < NUM_LETTER_GRADES; k++)
		{
			letterGrades[i][k] = 0;
		}
	}
	double *studentAverages = new double[numStudents];

	for (int i = 0; i < numExams; i++)
	{
		double anExamTotal = 0.0;
		for (int j = 0; j < numStudents; j++)
		{
			anExamTotal += allScores[j][i];
		}
		write << "\tExam " << i + 1 << " Average = ";
		ExamAverages[i] = anExamTotal / numStudents;
		write << fixed << setprecision(REQUIRED_ROUND) << setw(REQUIRED_WIDTH) << ExamAverages[i] << endl;
	}
	write << "Student Exam Grades: " << endl;
	for (int i = 0; i < numStudents; i++)
	{
		write << right << studentNames[i];
		for (int j = 0; j < numExams; j++)
		{
			write << fixed << setprecision(WHOLE_PRECISION) << setw(REQUIRED_WIDTH) << " " << allScores[i][j] ;
			string studentGradeLevel = WhatIsMyGrade(ExamAverages[j], allScores[i][j]);
			if (studentGradeLevel == "A")
			{
				letterGrades[j][A_GRADE]++;
			}
			else if (studentGradeLevel == "B")
			{
				letterGrades[j][B_GRADE]++;
			}
			else if (studentGradeLevel == "C")
			{
				letterGrades[j][C_GRADE]++;
			}
			else if (studentGradeLevel == "D")
			{
				letterGrades[j][D_GRADE]++;
			}
			else if (studentGradeLevel == "E")
			{
				letterGrades[j][E_GRADE]++;
			}
			write << "(" << studentGradeLevel << ")";
		}
		write << endl; //hard return to separate the different students.
	}
	write << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; i++)
	{
		write << "\tExam " << i + 1 << "\t";
		write << letterGrades[i][A_GRADE] << "(A)\t";
		write << letterGrades[i][B_GRADE] << "(B)\t";
		write << letterGrades[i][C_GRADE] << "(C)\t";
		write << letterGrades[i][D_GRADE] << "(D)\t";
		write << letterGrades[i][E_GRADE] << "(E)\t";
		write << endl;
	}
	write << "Student Final Grades:" << endl;
	for (int i = 0; i < numStudents; i++)
	{
		studentAverages[i] = 0.0;
		for (int j = 0; j < numExams; j++)
		{
			studentAverages[i] += allScores[i][j];
		}
		studentAverages[i] /= numExams;
	}
	double gradePointAverage = 0.0;
	for (int i = 0; i < numStudents; i++)
	{
		gradePointAverage += studentAverages[i];
	}
	gradePointAverage /= numStudents;
	for (int i = 0; i < numStudents; i++)
	{
		write << studentNames[i] << "\t";
		write << fixed << setprecision(REQUIRED_ROUND) << studentAverages[i];
		string finalGrade = WhatIsMyGrade(gradePointAverage, studentAverages[i]);
		write << "(" << finalGrade << ")" << endl;
	}
	write << "Class Average Score = " << gradePointAverage;

	//Deallocated Names, exam averages, student averages, and letter grad count
	delete[] studentNames;
	delete[] ExamAverages;
	delete[] studentAverages;
	for (int i = 0; i < numStudents; ++i)
	{
		delete[] allScores[i];
	}
	for (int i = 0; i < numExams; ++i)
	{
		delete[] letterGrades[i];
	}
	delete[] allScores;
	delete[] letterGrades;
	return 0;
}