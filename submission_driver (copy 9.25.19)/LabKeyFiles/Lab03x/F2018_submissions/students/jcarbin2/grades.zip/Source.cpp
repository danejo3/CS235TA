/*Jordan Carbine
* CS 235
* Lab 1 Grades


*/

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif



int main(int argc, char* argv[])
{
	VS_MEM_CHECK;             // enable memory leak check

	int rows = 100;
	int cols = 200;
	int **myArray = new int*[rows];
	for (int i = 0; i < rows; ++i)
	{
		myArray[i] = new int[cols];
	}



	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	int num_students;
	int num_exams;
	in >> num_students >> num_exams;
	// Skip the rest of the line
	in.ignore(std::numeric_limits<int>::max(), '\n');

	string line;
	getline(in, line);
	size_t p = 0;
	while (!isdigit(line[p])) ++p; //line[p] is the first digit

	string line = line.substr(p);
	// Put this into an istringstream
	istringstream iss(line);
	iss >> scores;

	out << std::setw(20) << name << " ";
	out << std::fixed << std::setprecision(0) << std::setw(6) << scores;

	for (int i = 0; i < rows; ++i)
	{
		delete[] myArray[i];
	}
	delete[] myArray;


	return 0;
}