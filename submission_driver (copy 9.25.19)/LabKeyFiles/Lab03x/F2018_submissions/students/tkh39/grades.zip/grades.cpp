/*
Suav Yaj, CS 235, Section 003
This program will accept a listing of students and their grades on exams
It will then output the scores, averages, grades, and final grades of the students.
*/
#include <iostream>
#include <iomanip>
#include <fstream>
#include <ostream>
#include <string>
#include <sstream>
#include <math.h>
using namespace std;

int main(int argC, char* argV[]) {

	//Error testing
	if (argC < 3) {
		cerr << "Please provide name of input and output files.";
		exit(1);
	}

	ifstream in(argV[1]);
	if (!in) {
		cerr << "Unable to open the input file.";
		exit(1);
	}

	ofstream out(argV[2]);
	if (!out) {
		in.close();
		cerr << "Unable to open the output file.";
		exit(1);
	}

	//Setting up variables and arrays
	const int NUM_LETTERS = 5;
	int numStudents = 0;
	int numExams = 0;
	double classAverage = 0;
	in >> numStudents >> numExams;
	in.ignore(std::numeric_limits<int>::max(), '\n');

	string *studentList = new string[numStudents];
	double **examScores = new double*[numStudents];
	for (int i = 0; i < numStudents; i++) {
		examScores[i] = new double[numExams];
	}
	double *examAverages = new double[numExams];
	int **examGradeCount = new int*[numExams];
	for (int i = 0; i < numExams; i++) {
		examGradeCount[i] = new int[NUM_LETTERS];
	}

	//Fill the arrays
	for (int i = 0; i < numStudents; i++) {
		string line;
		string firstName;
		string lastName;
		getline(in, line);
		istringstream iss(line);
		iss >> firstName >> lastName;
		studentList[i] = firstName + " " + lastName;

		for (int j = 0; j < numExams; j++) {
			iss >> examScores[i][j];
		}
	}
	
	//Output names and scores
	out << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; i++) {
		out << setw(20) << studentList[i] << " ";
		for (int j = 0; j < numExams; j++) {
			out << fixed << setprecision(0) << setw(6) << examScores[i][j];
		}
		out << endl;
	}
	
	//Find and output exam averages
	out << "Exam Averages:" << endl;
	for (int i = 0; i < numExams; i++) {
		examAverages[i] = 0;
		for (int j = 0; j < numStudents; j++) {
			examAverages[i] += examScores[j][i];
		}
		examAverages[i] = examAverages[i] / numStudents;
		out << "\t Exam " << i + 1 << " Average = \t" << setprecision(1) << examAverages[i] << endl;
	}

	//Find and output letter grades
	for (int i = 0; i < numExams; i++) {
		for (int j = 0; j < NUM_LETTERS; j++) {
			examGradeCount[i][j] = 0;
		}
	}

	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; i++) {
		out << setw(20) << studentList[i] << " ";
		for (int j = 0; j < numExams; j++) {
			if (fabs(examScores[i][j] - examAverages[j]) <= 5) {
				out << fixed << setprecision(0) << setw(6) << examScores[i][j] << "(C)";
				examGradeCount[j][2]++;
			}
			else if ((fabs(examScores[i][j] - examAverages[j]) <= 15) && (examScores[i][j] > examAverages[j])) {
				out << fixed << setprecision(0) << setw(6) << examScores[i][j] << "(B)";
				examGradeCount[j][1]++;
			}
			else if ((fabs(examScores[i][j] - examAverages[j]) <= 15) && (examScores[i][j] < examAverages[j])) {
				out << fixed << setprecision(0) << setw(6) << examScores[i][j] << "(D)";
				examGradeCount[j][3]++;
			}
			else if ((fabs(examScores[i][j] - examAverages[j]) > 15) && (examScores[i][j] > examAverages[j])) {
				out << fixed << setprecision(0) << setw(6) << examScores[i][j] << "(A)";
				examGradeCount[j][0]++;
			}
			else if ((fabs(examScores[i][j] - examAverages[j]) > 15) && (examScores[i][j] < examAverages[j])) {
				out << fixed << setprecision(0) << setw(6) << examScores[i][j] << "(E)";
				examGradeCount[j][4]++;
			}
		}
		out << endl;
	}

	//Number of letter grades per exam
	out << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; i++) {
		out << "\tExam " << i + 1 << "\t" << examGradeCount[i][0] << "(A)\t" << examGradeCount[i][1] << "(B)\t" << examGradeCount[i][2] << "(C)\t";
		out << examGradeCount[i][3] << "(D)\t" << examGradeCount[i][4] << "(E)" << endl;
	}

	//Final Scores
	for (int i = 0; i < numExams; i++) {
		classAverage += examAverages[i];
	}
	classAverage = classAverage / numExams;

	out << "Student Final Grades:" << endl;
	for (int i = 0; i < numStudents; i++) {
		double studentFinalScore = 0;
		out << setw(20) << studentList[i] << " ";
		for (int j = 0; j < numExams; j++) {
			studentFinalScore += examScores[i][j];
		}
		studentFinalScore = studentFinalScore / numExams;
		out << setprecision(1) << studentFinalScore;
		if (fabs(studentFinalScore - classAverage) <= 5) {
			out << "(C)";
		}
		else if ((fabs(studentFinalScore - classAverage) <= 15) && (studentFinalScore > classAverage)) {
			out << "(B)";
		}
		else if ((fabs(studentFinalScore - classAverage) <= 15) && (studentFinalScore < classAverage)) {
			out << "(D)";
		}
		else if ((fabs(studentFinalScore - classAverage) > 15) && (studentFinalScore > classAverage)) {
			out << "(A)";
		}
		else if ((fabs(studentFinalScore - classAverage) > 15) && (studentFinalScore < classAverage)) {
			out << "(E)";
		}
		out << endl;
	}
	out << "Class Average Score = " << setprecision(1) << classAverage;

	//Deleteing to avoid memory leaks
	delete [] studentList;
	for (int i = 0; i < numStudents; i++) {
		delete [] examScores[i];
	}
	delete [] examScores;
	delete [] examAverages;
	for (int i = 0; i < numExams; i++) {
		delete [] examGradeCount[i];
	}
	delete [] examGradeCount;

	return 0;
}