#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#include <limits>
//#include <ofstream>

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

std::string curveGrade(double actual, double average)
{
	std::string letterGrade;
	double difference = actual - average;

	if ((difference >= -5 && difference <= 0) || (difference <= 5 && difference > 0))
	{
		letterGrade = "(C)";
	}
	else if (difference <= 15 && difference >= 0)
	{
		letterGrade = "(B)";
	}
	else if (difference >= -15 && difference < 0)
	{
		letterGrade = "(D)";
	}
	else
	{
		if (difference >= 0)
		{
			letterGrade = "(A)";
		}
		else
		{
			letterGrade = "(E)";
		}
	}
	return letterGrade;
}

int main(int argc, char *argv[])
{
	VS_MEM_CHECK //memory leak check


	if (argc < 3) //Following code checks for files
	{
		std::cerr << "Please provide name of input and output files";
		return 1;
	}
	std::cout << "Input file: " << argv[1] << std::endl;
	std::ifstream in(argv[1]);
	if (!in)
	{
		std::cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	std::cout << "Output file: " << argv[2] << std::endl;
	std::ofstream out(argv[2]);

	if (!out)
	{
		in.close();
		std::cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}


	unsigned int numStudents; // finds the number of students and exams
	unsigned int numExams;
	in >> numStudents >> numExams;
	in.ignore(std::numeric_limits<int>::max(), '\n');

	int **myArray = new int *[numStudents]; //creates dynamic 2D array
	for (unsigned i = 0; i < numStudents; ++i)
	{
		myArray[i] = new int[numExams];
	}

	std::string line;
	std::stringstream names;
	std::string first;
	std::string last;
	std::string full;
	std::string score;
	std::string *nameArray = new std::string[numStudents];


	out << "Student Scores:" << std::endl;
	for (unsigned i = 0; i < numStudents; ++i) //Prints file contents and also stores data
	{
		out << std::right << std::setw(20);

		in >> first;
		in >> last;
		full = first + " " + last;
		names << last;

		out << full << " ";
		nameArray[i] = full;
		for (unsigned j = 0; j < numExams; ++j)
		{
			in >> score;
			out << std::right << std::setw(4) << score << " ";
			myArray[i][j] = stoi(score);
		}
		out << std::endl;
	}

	//double average = 0; //prints the exam averages and stores averages
	out << "Exam Averages:" << std::endl;
	//double Average = 0;
	double *examAv = new double[numExams];
	for (unsigned j = 0; j < numExams; ++j)
	{
		double totalScore = 0;
		for (unsigned i = 0; i < numStudents; ++i)
		{
			totalScore = totalScore + myArray[i][j];
		}
		double average = totalScore / numStudents;
		examAv[j] = average;

		out << std::fixed << std::setprecision(1) <<
			"\t Exam " << j + 1 << " Average = " << average << std::endl;
	}


	out << "Student Exam Grades:" << std::endl; //prints out with curve grade
	for (unsigned z = 0; z < numStudents; ++z)
	{
		out << std::right << std::setw(20) << nameArray[z] << " ";
		for (unsigned x = 0; x < numExams; ++x)
		{

			out << std::right << std::setw(5) << myArray[z][x] << curveGrade(myArray[z][x], examAv[x]) << " ";
		}
		out << std::endl;
	}


	out << "Exam Grades:" << std::endl; //coounts and displays grades per exam
	int **letterGradeNum = new int*[numExams];
	for (unsigned i = 0; i < numExams; ++i)
	{
		letterGradeNum[i] = new int[5];
	}
	for (unsigned int i = 0; i < numExams; ++i)
	{

		int A = 0, B = 0, C = 0, D = 0, E = 0;
		for (unsigned int j = 0; j < numStudents; ++j)
		{

			std::string grade = curveGrade(myArray[j][i], examAv[i]);

			letterGradeNum[i][0] = A;
			letterGradeNum[i][1] = B;
			letterGradeNum[i][2] = C;
			letterGradeNum[i][3] = D;
			letterGradeNum[i][4] = E;

			if (grade == "(A)")
			{
				++A;
				letterGradeNum[i][0] = A;
			}
			else if (grade == "(B)")
			{
				++B;
				letterGradeNum[i][1] = B;
			}
			else if (grade == "(C)")
			{
				++C;
				letterGradeNum[i][2] = C;
			}
			else if (grade == "(D)")
			{
				++D;
				letterGradeNum[i][3] = D;
			}
			else
			{
				++E;
				letterGradeNum[i][4] = E;
			}
		}
	}
	std::string letters[5] = { "(A)", "(B)", "(C)", "(D)", "(E)" };
	for (unsigned int i = 0; i < numExams; ++i)
	{
		out << " \t Exam " << i + 1 << " ";
		for (unsigned int j = 0; j < 5; ++j)
		{
			out << std::setw(3) << letterGradeNum[i][j] << letters[j] << " ";
		}
		out << std::endl;
	}


	double *studentFinal = new double[numExams]; //calculates student final grades and stores in array
	out << "Student Final Grade:" << std::endl;
	for (unsigned l = 0; l < numStudents; ++l)
	{
		double temp = 0;
		for (unsigned p = 0; p < numExams; ++p)
		{
			temp = temp + myArray[l][p];
		}

		studentFinal[l] = temp /numExams;
		temp = 0;
	}

	double classAv = 0; //calculates  and store class average
	double classTotal = 0;
	for (unsigned l = 0; l < numStudents; ++l)
	{
		
		classTotal = classTotal + studentFinal[l];
	}
	classAv = classTotal / numStudents;
	


	
	std::string *finalGrade = new std::string[numStudents]; //calculates letter grade and stores on array
	for (unsigned q = 0; q < numStudents; ++q)
	{
		finalGrade[q] = curveGrade(studentFinal[q], classAv);
	}
	

	
	for (unsigned c = 0; c < numStudents; ++c) //prints name, final score, and letter grade
	{
		out << std::right << std::setw(21) << nameArray[c] << " " << studentFinal[c] << " " << finalGrade[c] << std::endl;
	}

	out << "Class Average Score = " << classAv;




	delete[] finalGrade;

	delete[] studentFinal;





	for (unsigned i = 0; i < numExams; ++i)
	{
		delete[] letterGradeNum[i];
	}
	delete[] letterGradeNum;




	delete[] examAv;

	delete[] nameArray;




	for (unsigned i = 0; i < numStudents; ++i)
	{
		delete[] myArray[i];
	}
	delete[] myArray;





		return 0;
}
