#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#ifdef _MSC_VER //from help code, used to detect memory leaks. RUNS FINE
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;

int main(int argc, char* argv[])
{
	VS_MEM_CHECK //enable memory leak check
	

	//opening text files
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	/* cout << "Output file: " << argv[2] << endl; //opening output file
	ofstream out(argv[2]);
	if (!out)
	{
	in.close();
	cerr << "Unable to open " << argv[2] << " for output";
	return 3;
	} 
	//do i need this? can i delete this section of program?
	*/


	//reading and storing from input file
	int num_students; //reading ints from a file (and stores them in num_students and num_exams?)
	int num_exams;
	in >> num_students >> num_exams;
	in.ignore(std::numeric_limits<int>::max(), '\n'); //skip the rest of the line
	





     //this part of code needs to be FIXED

	 //creating dynamic arrays
	double rows = num_students; //creating 2D dynamic double array of scores
	double cols = num_exams;
	int **scoresArray = new int*[rows];
	for (int i = 0; i < rows; ++i)
	{
		scoresArray[i] = new int [cols];
	}
	string student_names;
	for (int i = 0; i < num_students; ++i)
	{
		//reading names from a file
		getline(in, student_names);
		size_t p = 0;
		while (!isdigit(student_names[p])) ++p;	// line[p] is the first digit
		string student_names = student_names.substr(p); //put this into istringstream
		istringstream iss(student_names);
		double student_scores;
		iss >> student_scores;
		for (int j = 0; j < num_exams; ++j)
		{
			scoresArray[i][j] = student_scores;
		}
		//now, put these values into ARRAYS
	}

	/*
	//creating dynamic arrays
	double rows = num_students; //creating 2D dynamic double array of scores
	double cols = num_exams;
	int **scoresArray = new int*[rows];
	int* scores_temp = new int(student_scores);
	for (int i = 0; i < rows; ++i)
	{
		scoresArray[i] = scores_temp;
	}*/

	string **namesArray = new string*[num_students];
	string* temp = new string(student_names);
	for (int i = 0; i < rows; ++i)
	{
		namesArray[i] = temp;
	}






	/*Objective 2:
	Output average score for each exam
	*/

	double aveScore; 
	for (int i = 0; i < num_exams; ++i)
	{
		for (int j = 0; j < num_exams; ++j)
		{
			aveScore = ++scoresArray[j][i];
		}
		aveScore = aveScore / num_students;
		cout << "Exam " << (i + 1) << " Average = " << aveScore;
	}
	
	/*
	Objective 3:
	Output exam grade in even columns
	*/
	
	cout << "Student Exam Grades: " << endl;
	for (int i = 0; i < num_students; ++i)
	{
		for (int j = 0; j < num_students; ++j)
		{
			if ((scoresArray[i][j] >= (aveScore - 5)) && (scoresArray[i][j] <= (aveScore + 5)))
			{
				cout << student_names[i] << scoresArray[i][j] << "(C)" << setw(5);
			}
			if ((scoresArray[i][j] > (aveScore + 5)) && (scoresArray[i][j] < (aveScore + 15)))
			{
				cout << student_names[i] << scoresArray[i][j] << "(B)" << setw(5);
			}
			if ((scoresArray[i][j] > (aveScore - 5)) && (scoresArray[i][j] < (aveScore - 15)))
			{
				cout << student_names[i] << scoresArray[i][j] << "(D)" << setw(5);
			}
			if (scoresArray[i][j] >= (aveScore + 15))
			{
				cout << student_names[i] << scoresArray[i][j] << "(A)" << setw(5);
			}
			if (scoresArray[i][j] <= (aveScore - 15))
			{
				cout << student_names[i] << scoresArray[i][j] << "(E)" << setw(5);
			}
		}
	}

	int A_grade = 0;
	int B_grade = 0;
	int C_grade = 0;
	int D_grade = 0;
	int E_grade = 0;
	for (int i = 0; i < num_students; ++i) //FIX so it outputs exam number THEN scores. ex. Exam 1 1(A) 2(B)
	{
		for (int j = 0; j < num_students; ++j)
		{
			if ((scoresArray[j][i] >= (aveScore - 5)) && (scoresArray[i][j] <= (aveScore + 5)))
			{
				++C_grade;
			}
			if ((scoresArray[j][i] > (aveScore + 5)) && (scoresArray[i][j] < (aveScore + 15)))
			{
				++B_grade;
			}
			if ((scoresArray[j][i] > (aveScore - 5)) && (scoresArray[i][j] < (aveScore - 15)))
			{
				++D_grade;
			}
			if (scoresArray[j][i] >= (aveScore + 15))
			{
				++A_grade;
			}
			if (scoresArray[j][i] <= (aveScore - 15))
			{
				++E_grade;
			}
		}
		cout << "Exam " << (i + 1) << setw(10);
		cout << A_grade << "(A)" << setw(5); //output number of A's, B's, etc.
		cout << B_grade << "(B)" << setw(5);
		cout << C_grade << "(C)" << setw(5);
		cout << D_grade << "(D)" << setw(5);
		cout << E_grade << "(E)" << setw(5);
	}

	for (int i = 0; i < rows; ++i) //use delete function to prevent memory leaks
	{
		delete[] scoresArray[i];
	}
	delete[] scoresArray; //add to end of program 
	for (int i = 0; i < rows; ++i) //use delete function to prevent memory leaks
	{
		delete[] namesArray[i];
	}
	delete[] namesArray;

	return 0;
}