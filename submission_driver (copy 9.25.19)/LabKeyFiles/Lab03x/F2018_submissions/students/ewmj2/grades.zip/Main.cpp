#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>

/*
Author: E.J. Mercer
Class: C S 235, Section 004
Email: ejwmercer@gmail.com

Test Cases (using provided text files):
    Input: lab01_in_01.txt
    Output: lab01_out_01.txt
    
    Input: lab01_in_02.txt
    Output: lab01_out_02.txt

	Input: lab01_in_03.txt
	Output: lab01_out_03.txt
 */

using namespace std;

//Constants
const char* GRADE_LETTERS = "ABCDE";
const int NUMBER_OF_GRADE_LETTERS = 5;
//This is the number of points between each letter grade. The lab requirements ask for 10.
const int LETTER_GAP = 10;
//This is the index of the middle of the grade letters string.
const int MEDIAN_INDEX = 2;

//Global variables
int numStudents;
int numTests;
string* names = nullptr;
double** scores;


/**
    Reads the data from the given file path into the numStudents, numTests, names, and scores variables.

    @param path The path of the input file to be read from.
 */
void loadFromFile(const string& path) {
	ifstream in(path);

	if (!in.is_open()) {
		cout << "Failed to read input file! Aborting!" << endl;
		return;
	}

	in >> numStudents >> numTests;

	names = new string[numStudents];
	scores = new double*[numStudents];
	for (int i = 0; i < numStudents; i++) {
		scores[i] = new double[numTests];

		string first, last;
		stringstream name;
		in >> first >> last;
		name << first << " " << last;
		names[i] = name.str();

		for (int j = 0; j < numTests; j++) {
			in >> scores[i][j];
		}
	}

	in.close();
}

/**
    Prints out the loaded students' scores in a user-readable manner as specified.
 */
void printScores(ofstream& out) {
	out << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; i++) {
		out << setw(20) << names[i];
		out << " ";
		for (int j = 0; j < numTests; j++) {
			out << setw(6) << scores[i][j];
		}
		out << endl;
	}
}

/**
    Calculates, prints, and returns the average scores for each exam.
    
    @param out The output stream to be written to.
    @return a double array containing the average scores for each exam.
 */
double* averageScores(ofstream& out) {
	out << "Exam Averages:" << endl;
	double* averages = new double[numTests];
	for (int j = 0; j < numTests; j++) {
		averages[j] = 0;
		for (int i = 0; i < numStudents; i++) {
			averages[j] += scores[i][j];
		}
		averages[j] /= numStudents;

		out << "    Exam " << (j + 1) << " Average = ";
		out << setw(6) << fixed << setprecision(1) << averages[j] << endl;
	}
	return averages;
}

/**
    Gets the index of the proper letter for a score in the GRADE_LETTERS string.
    The behavior of this method can be modified by changing the LETTER_GAP and MEDIAN_INDEX constants.

    @param score The score that the student earned.
    @param average The average score of the students' classmates.
    @return The index of the proper letter of the GRADE_LETTERS string.
 */
int getIndex(const double score, const double average) {
	const double diff = score > average ? score - average : average - score;
	int index = MEDIAN_INDEX;
	double diffFactor = LETTER_GAP / 2.0;
	while(diff > diffFactor) {
		diffFactor += LETTER_GAP;
		index += score > average ? -1 : 1;
	}
	if (index < 0) index = 0;
	if (index >= NUMBER_OF_GRADE_LETTERS) index = NUMBER_OF_GRADE_LETTERS - 1;
	return index;
}

/**
    Calculates and displays grades for each student for each exam.

    This also simultaneously constructs a 2-D array containing the totals for
    the scores on each test. This can be accessed by the test's index, and
    then by the index of the grade. For example, array[0][0] would access the
    count of As earned on the first exam.

    @param averages An array of the average score for each test.
    @param out The output stream to be written to.
    @return A 2-D array of integers containing the test totals.
 */
int** gradeExams(double* averages, ofstream& out) {
	out << "Student Exam Grades:" << endl;

	int** totals = new int*[numTests];
	for (int i = 0; i < numTests; i++) {
		totals[i] = new int[NUMBER_OF_GRADE_LETTERS];
		for (int j = 0; j < NUMBER_OF_GRADE_LETTERS; j++) {
			totals[i][j] = 0;
		}
	}

	for (int i = 0; i < numStudents; i++) {
		out << setw(20) << names[i];
		for (int j = 0; j < numTests; j++) {
			const int index = getIndex(scores[i][j], averages[j]);
			out << setw(6) << setprecision(0) << scores[i][j] << "(" << GRADE_LETTERS[index] << ")";
			totals[j][index]++;
		}
		out << endl;
	}

	return totals;
}

/**
    Displays the total of each grade letter for each exam.

    @param totals The totals array to be printed. See {@link gradeExams}.
    @param out The output stream to be written to.
 */
void showTotals(int** totals, ofstream& out) {
	out << "Exam Grades:" << endl;
	for (int i = 0; i < numTests; i++) {
		out << "    Exam  " << (i + 1);
		for (int j = 0; j < NUMBER_OF_GRADE_LETTERS; j++) {
			out << setw(5) << totals[i][j] << "(" << GRADE_LETTERS[j] << ")";
		}
		out << endl;
	}
}

/**
    Displays the overall grade for each student as well as the class average.

    These grades are calculated in the same manner that would be used to
    calculate a single exam grade. 

    @param out The output stream to be written to.
 */
void showOverallGrades(ofstream& out) {
	out << "Student Final Grades:" << endl;
	double average = 0;
	double* finalGrades = new double[numStudents];
	for (int i = 0; i < numStudents; i++) {
		finalGrades[i] = 0;
		for (int j = 0; j < numTests; j++) {
			finalGrades[i] += scores[i][j];
		}
		finalGrades[i] /= numTests;
		average += finalGrades[i];
	}
	average /= numStudents;

	for (int i = 0; i < numStudents; i++) {
		out << setw(20) << names[i];
		out << setw(6) << fixed << setprecision(1) << finalGrades[i];
		out << "(" << GRADE_LETTERS[getIndex(finalGrades[i], average)] << ")";
		out << endl;
	}
	out << "Class Average Score = " << average << endl;
	delete[] finalGrades;
}

/**
    Cleans up any structures used during processing, deleting all 2-D arrays.
 */
void cleanup(double*& averages, int**& totals) {
	for (int i = 0; i < numStudents; i++)
		delete[] scores[i];
	for (int i = 0; i < numTests; i++)
		delete[] totals[i];

	delete[] averages;
	delete[] names;
	delete[] scores;
	delete[] totals;
}

/**
    The main program.

    @param argc The number of arguments provided
    @param argv The array of arguments provided
    @return 0 if executed successfully, -1 otherwise
 */
int main(const int argc, const char* argv[]) {
	if(argc < 3) {
		cout << "Invalid arguments! An input and output file are required.";
		return -1;
	}

	loadFromFile(argv[1]);
	if (names == nullptr) return -1;

	ofstream out(argv[2]);
	if (!out.is_open()) {
		cout << "Failed to open output file! Aborting!" << endl;
		return -1;
	}

	printScores(out);
	double* averages = averageScores(out);
	int** totals = gradeExams(averages, out);
	showTotals(totals, out);
	showOverallGrades(out);

	cleanup(averages, totals);

	out.close();

	return 0;
}
