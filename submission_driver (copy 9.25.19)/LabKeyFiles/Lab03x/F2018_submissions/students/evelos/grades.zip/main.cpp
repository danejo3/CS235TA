#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>

using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif


int main(int argc, char* argv[])
{
	VS_MEM_CHECK

	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cout << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cout << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	string line;
	string firstName;
	string lastName;
	int examScore;
	int num_students;
	int num_exams;

	in >> num_students >> num_exams;
	in.ignore();
		
	//String array for the names
	string* nameArray = new string[num_students];
	//Two dimensional array for the exam scores
	int ** scoreArray = new int*[num_students];
	for (int i = 0; i < num_students; ++i)
	{
		scoreArray[i] = new int[num_exams];
	}

	//Placing data into arrays
	for (int i = 0; i < num_students; ++i) 
	{
		getline(in, line);
		stringstream ss(line);
		ss >> firstName;
		ss >> lastName;
		nameArray[i] = firstName + " " + lastName;
		for (int j = 0; j < num_exams; ++j)
		{
			ss >> examScore;
			scoreArray[i][j] = examScore;
		}
		ss.ignore();
	}

	//Output students' scores
	out << "Student Scores:" << endl;
	for (int i = 0; i < num_students; ++i)
	{
		out << setw(20) << nameArray[i];
		for (int j = 0; j < num_exams; ++j)
		{
			out << fixed << setprecision(0) << setw(6) << scoreArray[i][j];
		}
		out << endl;
	}
	//Calculate exam averages
	double sum;
	double examAverage;
	double* averageArray = new double[num_exams];
	out << "Exam Averages:" << endl;
	for (int i = 0; i < num_exams; ++i)
	{
		sum = 0;
		for (int j = 0; j < num_students; ++j)
		{
			sum = sum + scoreArray[j][i];
		}
		examAverage = sum / num_students;
		averageArray[i] = examAverage;
	}

	//Output the exam averages
	for (int i = 0; i < num_exams; ++i)
	{
		out << setw(10) << "Exam " << i + 1 << " Average = ";
		out << fixed << setprecision(1) << averageArray[i] << endl;
	}


	//Calculate and output student exam grades and count number of each grade
	char** gradeArray = new char*[num_students];
	for (int i = 0; i < num_students; ++i)
	{
		gradeArray[i] = new char[num_exams];
	}

	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < num_students; ++i)
	{
		out << setw(20) << nameArray[i];
	
		for (int j = 0; j < num_exams; ++j)
		{
			if (scoreArray[i][j] <= (averageArray[j] + 5) && scoreArray[i][j] >= (averageArray[j] - 5))
			{
				out << fixed << setprecision(0) << setw(6) << scoreArray[i][j] << "(C)";
				gradeArray[i][j] = 'C';
			}
			else if (scoreArray[i][j] < (averageArray[j] + 15) && scoreArray[i][j] > (averageArray[j] - 15))
			{
				if (scoreArray[i][j] > averageArray[j])
				{
					out << fixed << setprecision(0) << setw(6) << scoreArray[i][j] << "(B)";
					gradeArray[i][j] = 'B';
				}
				else
				{
					out << fixed << setprecision(0) << setw(6) << scoreArray[i][j] << "(D)";
					gradeArray[i][j] = 'D';
				}
			}
			else
			{
				if (scoreArray[i][j] > averageArray[j])
				{
					out << fixed << setprecision(0) << setw(6) << scoreArray[i][j] << "(A)";
					gradeArray[i][j] = 'A';
				}
				else
				{
					out << fixed << setprecision(0) << setw(6) << scoreArray[i][j] << "(E)";
					gradeArray[i][j] = 'E';
				}
			}
		}
		out << endl;
	}

	//Output number of exam grades
	out << "Exam Grades:" << endl;
	int numA;
	int numB;
	int numC;
	int numD;
	int numE;

	for (int i = 0; i < num_exams; ++i)
	{
		numA = 0;
		numB = 0;
		numC = 0;
		numD = 0;
		numE = 0;
		out << setw(10) << "Exam  " << i + 1;
		for (int j = 0; j < num_students; ++j)
		{
			if (gradeArray[j][i] == 'A')
			{
				++numA;
			}
			else if (gradeArray[j][i] == 'B')
			{
				++numB;
			}
			else if (gradeArray[j][i] == 'C')
			{
				++numC;
			}
			else if (gradeArray[j][i] == 'D')
			{
				++numD;
			}
			else if (gradeArray[j][i] == 'E')
			{
				++numE;
			}
		}
		out << setw(5) << numA << "(A)" << setw(5) << numB << "(B)" << setw(5) << numC << "(C)";
		out << setw(5) << numD << "(D)" << setw(5) << numE << "(E)" << endl;
	}


	//Extra Credit: Student Final Grades

	
	for (int i = 0; i < num_students; ++i)
	{
		delete [] scoreArray[i];
	}
	delete [] scoreArray;

	for (int i = 0; i < num_students; ++i)
	{
		delete[] gradeArray[i];
	}
	delete[] gradeArray;

	delete[] nameArray;
	delete[] averageArray;


	return 0;
}