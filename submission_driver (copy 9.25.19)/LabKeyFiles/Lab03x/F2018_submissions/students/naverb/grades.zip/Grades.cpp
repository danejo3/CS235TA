#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;


int main(int argc, char * argv[]) {
	VS_MEM_CHECK               // enable memory leak check
// Get Input and Output files //
	if (argc < 3) {
			cerr << "Please provide name of input and output files";
			return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in) {
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out) {
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	int numStudents;
	int numExams;
	in >> numStudents >> numExams;
	// Skip the rest of the line
	in.ignore(1000, '\n');

// Create Arrays //
	double **exams = new double*[numStudents];
	for (int i = 0; i < numStudents; ++i) {
		exams[i] = new double[numExams];
	}

	string **studentExamGrades = new string*[numStudents];
	for (int i = 0; i < numStudents; ++i) {
		studentExamGrades[i] = new string[numExams];
	}

	double *averages = new double[numExams];

	double *studentFinalGrades = new double[numStudents];

	int **letterGrades = new int*[numExams];
	for (int i = 0; i < numExams; ++i) {
		letterGrades[i] = new int[5];
	}

	string **names = new string*[numStudents];
	for (int i = 0; i < numStudents; ++i) {
		names[i] = new string[2];
	}

// Populate Arrays //
	string firstName;
	string lastName;

	for (int i = 0; i < numStudents; i++) {
		in >> names[i][0] >> names[i][1];
		for (int j = 0; j < numExams; j++) {
			in >> exams[i][j];
		}
		in.ignore(1000, '\n');
	}

	for (int i = 0; i < numExams; i++) {
		for (int j = 0; j < 5; j++) {
			letterGrades[i][j] = 0;
		}
	}


// Run calculations on arrays //
	double total;
	double currentAverage;
	double currentScore;
	for (int i = 0; i < numExams; i++) {
		total = 0;
		// Loop down column to grab average score
		for (int j = 0; j < numStudents; j++) {
			total += exams[j][i];
		}
		averages[i] = total / static_cast<double>(numStudents);
		currentAverage = averages[i];
		// Loop down column again to get letter grades
		for (int j = 0; j < numStudents; j++) {
			currentScore = exams[j][i];
			if (currentAverage+15 < currentScore) {
				// student got an A, so mark the ith exam as having another
				letterGrades[i][0]++;
				studentExamGrades[j][i] = "(A)";
			} else if (currentAverage+5 < currentScore && currentScore <= currentAverage+15) {
				// student got a B, so mark the ith exam as having another
				letterGrades[i][1]++;
				studentExamGrades[j][i] = "(B)";
			} else if (currentAverage-5 < currentScore && currentScore <= currentAverage+5) {
				// student got a C, so mark the ith exam as having another
				letterGrades[i][2]++;
				studentExamGrades[j][i] = "(C)";
			} else if (currentAverage-15 < currentScore && currentScore <= currentAverage-5) {
				// student got a D, so mark the ith exam as having another
				letterGrades[i][3]++;
				studentExamGrades[j][i] = "(D)";
			} else if (currentScore <= currentAverage-15) {
				// student got an E, so mark the ith exam as having another
				letterGrades[i][4]++;
				studentExamGrades[j][i] = "(E)";
			}
		}
	}

	double classAverage;
	for (int i = 0; i < numStudents; i++) {
		total = 0;
		for (int j = 0; j < numExams; j++) {
			total += exams[i][j];
		}
		studentFinalGrades[i] = total / static_cast<double>(numExams);
		classAverage += studentFinalGrades[i];
	}
	// classAverage is now total of student grades, so we divide by numStudents
	classAverage /= static_cast<double>(numStudents);

// Output formatted information //
	string fullName;

	out << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; i++) {
		fullName = names[i][0] + " " + names[i][1];
		out << setw(20) << right << fullName;
		for (int j = 0; j < numExams; j++) {
			out << setw(6) << static_cast<int>(exams[i][j]);
		}
		out << endl;
	}

	out << "Exam Averages:" << endl;
	for (int i = 0; i < numExams; i++) {
		out << setw(8) << "Exam";
		out << setw(2) << i+1;
		out << " Average = ";
		out << setw(6) << fixed << setprecision(1) << averages[i];
		out << endl;
	}

	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; i++) {
		fullName = names[i][0] + " " + names[i][1];
		out << setw(20) << right << fullName;
		for (int j = 0; j < numExams; j++) {
			out << setw(6) << static_cast<int>(exams[i][j]) << studentExamGrades[i][j];
		}
		out << endl;
	}

	out << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; i++) {
		out << setw(8) << "Exam";
		out << setw(2) << i+1;
		out << setw(5) << letterGrades[i][0] << "(A)";
		out << setw(5) << letterGrades[i][1] << "(B)";
		out << setw(5) << letterGrades[i][2] << "(C)";
		out << setw(5) << letterGrades[i][3] << "(D)";
		out << setw(5) << letterGrades[i][4] << "(E)";
		out << endl;
	}

	out << "Student Final Grades:" << endl;
	for (int i = 0; i < numStudents; i++) {
		currentScore = studentFinalGrades[i];

		fullName = names[i][0] + " " + names[i][1];
		out << setw(20) << right << fullName;
		out << setw(6) << fixed << setprecision(1) << currentScore;
		
		if (classAverage+15 < currentScore) {
			// student got an A, so mark the ith exam as having another
			out << "(A)";
		} else if (classAverage+5 < currentScore && currentScore <= classAverage+15) {
			// student got a B, so mark the ith exam as having another
			out << "(B)";
		} else if (classAverage-5 < currentScore && currentScore <= classAverage+5) {
			// student got a C, so mark the ith exam as having another
			out << "(C)";
		} else if (classAverage-15 < currentScore && currentScore <= classAverage-5) {
			// student got a D, so mark the ith exam as having another
			out << "(D)";
		} else if (currentScore <= classAverage-15) {
			// student got an E, so mark the ith exam as having another
			out << "(E)";
		}
		
		out << endl;
	}
	out << "Class Average Score = ";
	out << fixed << setprecision(1) << classAverage;

// Free Memory
	// Delete sub-arrays
    for (int i = 0; i < numStudents; ++i) {
		delete[] exams[i];
	}
    for (int i = 0; i < numStudents; ++i) {
		delete[] studentExamGrades[i];
	}
	for (int i = 0; i < numExams; ++i) {
		delete[] letterGrades[i];
	}
	for (int i = 0; i < numStudents; ++i) {
		delete[] names[i];
	}
	// Delete arrays
	delete[] exams;
	delete[] studentExamGrades;
	delete[] averages;
	delete[] studentFinalGrades;
	delete[] letterGrades;
	delete[] names;

	system("PAUSE");
	return 0;
}
