#include <fstream>
#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;

int main(int argc, char* argv[]) 
{
	VS_MEM_CHECK               // enable memory leak check

		//C:\\Users\\thebl\\Desktop\\TestInput.txt
		//C:\\Users\\thebl\\Desktop\\TestOutput.txt
	ifstream IS(argv[1]);
	ofstream OS(argv[2]);
	const int GRADE_MARGIN_MIN = 5;
	const int GRADE_MARGIN_MAX = 15;
	const int NUM_LETTER_GRADES = 5;
	
	int numStudents, numExams;
	IS >> numStudents >> numExams;

	string *studentNames = new string[numStudents];
	int **studentExams = new int*[numStudents];
	for (int i = 0; i < numStudents; i++) 
	{
		studentExams[i] = new int[numExams];
	}

	string lastName;								//Inputs names of students and their exam scores
	for (int i = 0; i < numStudents; i++) 
	{
		IS >> studentNames[i] >> lastName;
		studentNames[i] += " ";
		studentNames[i] += lastName;
		for (int j = 0; j < numExams; j++) 
		{
			IS >> studentExams[i][j];
		}
	}

	OS << "Student Scores:" << endl;				//outputs student names and exam scores
	for (int i = 0; i < numStudents; i++)
	{
		OS << right << setw(15) << studentNames[i] << " ";
		for (int j = 0; j < numExams; j++)
		{
			OS << setw(3) << studentExams[i][j] << " ";
		}
		OS << endl;
	}
	OS << endl;

	double examAvg = 0;							//Outputs average score for each exam
	double *listAvgs = new double[numExams];
	OS << "Exam Averages: " << endl;
	for (int i = 0; i < numExams; i++) 
	{
		examAvg = 0;
		for (int j = 0; j < numStudents; j++) 
		{
			examAvg += studentExams[j][i];
		}
		examAvg /= numStudents;
		listAvgs[i] = examAvg;
		OS  << "Exam " << right << setw(2) << i + 1 << " Average = " 
			<< setw(4) << fixed << setprecision(1) << right << examAvg << endl;
	}
	OS << endl;

	int **letterGrades = new int*[numExams];
	for (int i = 0; i < numExams; i++)
	{
		letterGrades[i] = new int[NUM_LETTER_GRADES];
	}
	for (int i = 0; i < numExams; i++)
	{
		for (int j = 0; j < NUM_LETTER_GRADES; j++)
		{
			letterGrades[i][j] = 0;
		}
	}
	OS << "Student Exam Grades:" << endl;				//outputs student names and exam scores with a letter grade
	for (int i = 0; i < numStudents; i++)
	{
		OS << right << setw(15) << studentNames[i] << " ";
		for (int j = 0; j < numExams; j++)
		{
			OS << setw(3) << studentExams[i][j];
			if (abs(studentExams[i][j] - listAvgs[j]) <= GRADE_MARGIN_MIN) 
			{
				OS << "(C) ";
				letterGrades[j][2] += 1;
			}
			if (studentExams[i][j] - listAvgs[j] > GRADE_MARGIN_MIN
				&& studentExams[i][j] - listAvgs[j] <= GRADE_MARGIN_MAX)
			{
				OS << "(B) ";
				letterGrades[j][1] += 1;
			}
			if (studentExams[i][j] - listAvgs[j] > GRADE_MARGIN_MAX)
			{
				OS << "(A) ";
				letterGrades[j][0] += 1;
			}
			if (studentExams[i][j] - listAvgs[j] < (-1 * GRADE_MARGIN_MIN) 
				&& studentExams[i][j] - listAvgs[j] >= (-1 * GRADE_MARGIN_MAX))
			{
				OS << "(D) ";
				letterGrades[j][3] += 1;
			}
			if (studentExams[i][j] - listAvgs[j] < (-1 * GRADE_MARGIN_MAX))
			{
				OS << "(E) ";
				letterGrades[j][4] += 1;
			}
		}
		OS << endl;
	}
	OS << endl;

	OS << "Exam Grades: " << endl;					//outputs total letter grades per exam
	for (int i = 0; i < numExams; i++)
	{
		OS << "Exam  " << i + 1 << " ";
		for (int j = 0; j < NUM_LETTER_GRADES; j++)
		{
			OS << right << setw(2) << letterGrades[i][j] << "(" << static_cast<char>(j + 'A') << ") ";
		}
		OS << endl;
	}
	OS << endl;

	OS << "Student Final Grades: " << endl;			//outputs students final avg exam grades and letter grade
	double classFinalAvg;
	for (int i = 0; i < numStudents; i++)
	{
		OS << setw(25) << right << studentNames[i] << " ";
		examAvg = 0;
		for (int j = 0; j < numExams; j++)
		{
			examAvg += studentExams[i][j];
		}
		examAvg /= numExams;
		OS << fixed << setw(3) << examAvg;
		classFinalAvg = 0;
		for (int j = 0; j < numExams; j++)
		{
			classFinalAvg += listAvgs[j];
		}
		classFinalAvg /= numExams;
		if (abs(examAvg - classFinalAvg) <= GRADE_MARGIN_MIN)
		{
			OS << "(C) ";
		}
		if (examAvg - classFinalAvg > GRADE_MARGIN_MIN &&
			examAvg - classFinalAvg <= GRADE_MARGIN_MAX)
		{
			OS << "(B) ";
		}
		if (examAvg - classFinalAvg > GRADE_MARGIN_MAX)
		{
			OS << "(A) ";
		}
		if (examAvg - classFinalAvg < (-1 * GRADE_MARGIN_MIN) &&
			examAvg - classFinalAvg >= (-1 * GRADE_MARGIN_MAX))
		{
			OS << "(D) ";
		}
		if (examAvg - classFinalAvg < (-1 * GRADE_MARGIN_MAX))
		{
			OS << "(E) ";
		}
		OS << endl;
	}
	OS << "Class Average Score = " << classFinalAvg << endl;

	delete[] studentNames;
	for (int i = 0; i < numStudents; i++) 
	{
		delete[] studentExams[i];
	}
	delete[] studentExams;
	delete[] listAvgs;
	for (int i = 0; i < numExams; i++)
	{
		delete[] letterGrades[i];
	}
	delete[] letterGrades;

	IS.close();
	OS.close();

	return 0;
}
