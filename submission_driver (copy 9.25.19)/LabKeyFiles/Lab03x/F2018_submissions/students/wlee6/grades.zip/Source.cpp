#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <sstream>
#include <iomanip>
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

using namespace std;

//double averages;
//double studentGrades;
int breakDownA = 15;
int breakDownB = 5;



string letterGrades(double averages, double studentGrades) {
	string letterGrades;
	if (studentGrades > averages && (studentGrades - averages) > breakDownB && (studentGrades - averages) < breakDownA) {
		letterGrades = "B";
	}
	if (studentGrades > averages && (studentGrades - averages) >= breakDownA) {
		letterGrades = "A";
	}
	if (abs(studentGrades - averages) <= breakDownB) {
		letterGrades = "C";
	}
	if (studentGrades < averages && (averages - studentGrades) > breakDownB && (averages - studentGrades) < breakDownA) {
		letterGrades = "D";
	}
	if (studentGrades < averages && (averages - studentGrades) >= breakDownA) {
		letterGrades = "E";
	}
	return letterGrades;
}

int main(int argc, char *argv[2]) {
	VS_MEM_CHECK
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);
	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	int num_students;
	int num_exams;
	//double exam_ave;
	int sum = 0;

	in >> num_students >> num_exams;
	// Skip the rest of the  line
	//in.ignore(std::numeric_limits<int>::max(), '\n');

	int rows = num_students;
	//int cols = num_exams;
	int temp = 0;
	/*int numA = 0;
	int numB = 0;
	int numC = 0;
	int numD = 0;*/

	double averageScores;
	//vector<string> studentName;
	string* studentName = new string[num_students];
	string firstName;
	string lastName;
	string fullName;
	//const int arraySize = num_students;
	//string studentsName[arraySize];
	//vector<int> scores;
	//vector<double> averages;
	double* averages = new double[num_exams];
	int **data = new int*[rows];
	for (int i = 0; i < rows; ++i) {
		data[i] = new int[num_exams];
	}

	for (int i = 0; i < num_students; ++i) {
		in >> firstName;
		in >> lastName;
		fullName = firstName + " " + lastName;
		//cout << fullName << endl;
		studentName[i] = fullName;

		for (int j = 0; j < num_exams; ++j) {
			in >> temp;
			data[i][j] = temp;
		}
	}



	for (int i = 0; i < num_exams; ++i) {
		for (int j = 0; j < num_students; ++j) {
			sum += data[j][i];
		}
		averageScores = sum / double(num_students);
		averages[i] = averageScores;
		averageScores = 0;
		sum = 0;
	}

	int sumOfA = 0;
	int sumOfB = 0;
	int sumOfC = 0;
	int sumOfD = 0;
	int sumOfE = 0;
	string gradeA = "A";
	string gradeB = "B";
	string gradeC = "C";
	string gradeD = "D";
	string gradeE = "E";
	ofstream writeout;
	writeout.open(argv[2]);
	writeout << "Student Scores:" << endl;
	for (int i = 0; i < num_students; ++i) {
		//cout << right << setw(20);
		writeout << studentName[i] << "     ";
		for (int j = 0; j < num_exams; ++j) {
			writeout << data[i][j] << "   ";
		}
		writeout << endl;
	}


	writeout << "Exam Averages: " << endl;
	for (int i = 0; i < num_exams; ++i) {
		writeout << fixed << setprecision(1);
		writeout << "    Exam " << (i+1) << " Average =   " << averages[i] << endl;
	}


	writeout << "Student Exam Grades:" << endl;
	for (int i = 0; i < num_students; ++i) {
		writeout << studentName[i] << "\t\t";
		for (int j = 0; j < num_exams; ++j) {
			//cout << a[i][j] << endl;
			//cout << averages.at(j) << endl;
			writeout << data[i][j];
			writeout << "(" << letterGrades(averages[j], data[i][j]) << ")" << "   ";
			//cout << averages.at(j) << " ";
		}
		writeout << endl;
	}
	writeout << "Exam Grades:" << endl;
	for (int i = 0; i < num_exams; ++i) {
		for (int j = 0; j < num_students; ++j) {
			//cout << a[j][i] << " ";
			//cout << j << " ";
			//cout << i << " " << endl;
			if (letterGrades(averages[i], data[j][i]) == "A") {
				sumOfA++;
			}
			if (letterGrades(averages[i], data[j][i]) == "B") {
				sumOfB++;
			}
			if (letterGrades(averages[i], data[j][i]) == "C") {
				sumOfC++;
			}
			if (letterGrades(averages[i], data[j][i]) == "D") {
				sumOfD++;
			}
			if (letterGrades(averages[i], data[j][i]) == "E") {
				sumOfE++;
			}
			//cout << "Exam " << i << " Average =  " << averages.at(i) << "    " << sumOfA << "(A)    " << sumOfB << "(B)    " << sumOfC << "(C)    " << sumOfD << "(D)    " << endl;
		}
		writeout << "    Exam " << (i+1) <<  "    " << sumOfA << "(A)    " << sumOfB << "(B)    " << sumOfC << "(C)    " << sumOfD << "(D)    " << sumOfE << "(E)    "<< endl;
		sumOfA = 0;
		sumOfB = 0;
		sumOfC = 0;
		sumOfD = 0;
		sumOfE = 0;

	}
	writeout << "Student Final Grades:" << endl;
	//vector<double>studentAverage;
	double* studentAverage = new double[num_students];
	double personSum = 0;
	double studentAverages;
	for (int i = 0; i < num_students; ++i) {
		for (int j = 0; j < num_exams; ++j) {
			personSum += data[i][j];
		}
		studentAverages = personSum / double(num_exams);
		studentAverage[i] = studentAverages;
		personSum = 0;
		studentAverages = 0;
		//cout << studentName.at(i) << "  " << studentAverages <<"(" << LetterGrades(studentAverages, average.at()
	}
	/*for (int i = 0; i < num_students; ++i) {
		cout << studentAverage.at(i) << " ";
	}*/
	double totalAverage = 0;
	double sumOfAll = 0;
	for (int i = 0; i < num_students; ++i) {
		sumOfAll += studentAverage[i];
		totalAverage = sumOfAll / num_students;
		//cout << studentName.at(i) << "  " << studentAverage.at(i) << LetterGrades(studentAverage.at(i), );

			//writeout.close();	
	}
	for (int i = 0; i < num_students; ++i) {
		writeout << studentName[i] << "  " << studentAverage[i] << "(" << letterGrades(totalAverage, studentAverage[i]) << ")" << endl;
	}
	//cout << totalAverage;
	writeout << "Class Average Score = " << totalAverage << endl;
	//system("pause");
	for (int i = 0; i < rows; ++i)
	{
		delete[] data[i];
	}
	delete[] data;
	delete[] studentAverage;
	delete[] studentName;
	delete[] averages;


		return 0;
}