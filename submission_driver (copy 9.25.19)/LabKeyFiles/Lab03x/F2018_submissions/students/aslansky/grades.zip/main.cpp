/*
lizardon
CS 235, sec. #

INPUT: file
	#rows #columns
	First Last	###	###	~
	~
EXPECTED OUTPUT:
	Student Scores:
		First Last	###	###	~
		~
	Exam Averages:
		Exam  # Average =	###.#
		~
	Student Exam Grades:
		First Last	###(L)	###(L)	~
		~
	Exam Grades:
		Exam  #		#(A)	#(B)	#(C)	#(D)	#(E)
		~
	Student Final Grades:
		First Last	###.#(L)
		~
*/

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

char getLetterGrade(double grade, double examAverage);
double getClassAverage(int** scores, int numRows, int column);
double getClassAverage(double* finalScores, int numRows);
double getStudentAverage(int** scores, int row, int numCols);
int getTotalLetterGrades(int** scores, int numRows, int column, double examAverage, char letter);


int main(int argc, const char* argv[]) {
	VS_MEM_CHECK;
    
	if (argc < 3) {
		cerr << "Error: Please provide names of input and output files." << endl;
		return 1;
    }
	ifstream in(argv[1]);
	if (!in) {
		cerr << "Error: Unable to open " << argv[1] << " for input" << endl;
		return 2;
    }
	ofstream out(argv[2]);
	if (!out) {
		in.close();
		cerr << "Error: Unable to open " << argv[2] << " for output" << endl;
		return 3;
    }
    

    int numCols;
    int numRows;
	in >> numRows >> numCols;
	in.ignore(numeric_limits<streamsize>::max(), '\n');

	string* names = new string[numRows];
	int** scores = new int*[numRows];
	for (int i = 0; i < numRows; i++) {
		scores[i] = new int[numCols];
    }
	char** letters = new char*[numRows];
	for (int i = 0; i < numRows; i++) {
		letters[i] = new char[numCols];
	}
	double* finalScores = new double[numRows];
    
	for (int i = 0; i < numRows; i++) {
		string temp;
		for (int k = 0; k < 2; k++) {	//names[]
			in >> temp;
			temp.push_back(' ');
			names[i].append(temp);
		}
		for (int j = 0; j < numCols; j++) {	//scores[][]
			in >> scores[i][j];
		}
		in.ignore(numeric_limits<streamsize>::max(), '\n');
	}
	for (int i = 0; i < numRows; i++) {	//letters[][]
		for (int j = 0; j < numCols; j++) {
			letters[i][j] = getLetterGrade(scores[i][j], getClassAverage(scores, numRows, j));
		}
	}
	for (int i = 0; i < numRows; i++) {	//finalScores[]
		finalScores[i] = getStudentAverage(scores, i, numCols);
	}


	out << "Student Scores:" << endl;
	for (int i = 0; i < numRows; i++) {
		out << setw(20) << names[i];
		for (int j = 0; j < numCols; j++) {
			out << '\t' << setw(3) << scores[i][j];
		}
		out << endl;
	}
	out << "Exam Averages:" << endl;
	for (int i = 0; i < numCols; i++) {
		double avg = getClassAverage(scores, numRows, i);
		out << "\tExam " << setw(2) << i + 1 << " Average = " << fixed << setprecision(1) << avg << endl;
	}
	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < numRows; i++) {
		out << setw(20) << names[i];
		for (int j = 0; j < numCols; j++) {
			out << '\t' << setw(3)
				<< scores[i][j] << '(' << letters[i][j] << ')';
		}
		out << endl;
	}
	out << "Exam Grades:" << endl;
	for (int i = 0; i < numCols; i++) {
		out << "\tExam " << setw(2) << i + 1 << '\t';
		double avg = getClassAverage(scores, numRows, i);
		out << '\t' << getTotalLetterGrades(scores, numRows, i, avg, 'A') << "(A)"
			<< '\t' << getTotalLetterGrades(scores, numRows, i, avg, 'B') << "(B)"
			<< '\t' << getTotalLetterGrades(scores, numRows, i, avg, 'C') << "(C)"
			<< '\t' << getTotalLetterGrades(scores, numRows, i, avg, 'D') << "(D)"
			<< '\t' << getTotalLetterGrades(scores, numRows, i, avg, 'E') << "(E)" << endl;
	}
	out << "Student Final Grades" << endl;
	for (int i = 0; i < numRows; i++) {
		out << setw(20) << names[i] << fixed << setprecision(1) << finalScores[i]
			<< '(' << getLetterGrade(finalScores[i], getClassAverage(finalScores, numRows)) << ')' << endl;
	}
	out << fixed << setprecision(1) << "Class Average Score = " << getClassAverage(finalScores, numRows) << endl;


	for (int i = 0; i < numRows; i++) {
        delete[] scores[i];
		delete[] letters[i];
    }
	delete[] names;
    delete[] scores;
	delete[] letters;
	delete[] finalScores;
    
    in.close();
	if (in) {
		cerr << "Error: Input file not closed" << endl;
        return 4;
    }
    out.close();
	if (out) {
		cerr << "Error: Output file not closed" << endl;
        return 5;
    }
    
    return 0;
}


char getLetterGrade(double grade, double examAverage) {
	char letterGrade;
	const double LOW_CUTOFF = 5.0;
	const double HIGH_CUTOFF = 15.0;

	if		(grade > examAverage + HIGH_CUTOFF)	{ letterGrade = 'A'; }
	else if (grade > examAverage + LOW_CUTOFF)	{ letterGrade = 'B'; }
	else if (grade >= examAverage - LOW_CUTOFF)	{ letterGrade = 'C'; }
	else if (grade > examAverage - HIGH_CUTOFF)	{ letterGrade = 'D'; }
	else										{ letterGrade = 'E'; }

	return letterGrade;
}
double getClassAverage(int** scores, int numRows, int column) {
	double avg = 0.0;

	for (int i = 0; i < numRows; i++) {
		avg += scores[i][column];
	}
	avg /= static_cast<double>(numRows);

	return avg;
}
double getClassAverage(double* finalScores, int numRows) {
	double avg = 0.0;

	for (int i = 0; i < numRows; i++) {
		avg += finalScores[i];
	}
	avg /= static_cast<double>(numRows);

	return avg;
}
double getStudentAverage(int** scores, int row, int numCols) {
	double avg = 0;

	for (int i = 0; i < numCols; i++) {
		avg += scores[row][i];
	}
	avg /= static_cast<double>(numCols);

	return avg;
}
int getTotalLetterGrades(int** scores, int numRows, int column, double examAverage, char letter) {
	int total = 0;

	for (int i = 0; i < numRows; i++) {
		if (letter == getLetterGrade(scores[i][column], examAverage)) {
			total++;
		}
	}

	return total;
}