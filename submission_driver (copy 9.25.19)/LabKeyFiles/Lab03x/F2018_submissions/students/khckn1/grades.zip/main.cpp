//
//  main.cpp
//  Lab1: Grades
//
//  Created by Kai Hicken on 9/17/18.
//  Copyright © 2018 Kai Hicken. All rights reserved.
//

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <cmath>

using namespace std;

const int TIER_ONE_RANGE = 5;
const int TIER_TWO_RANGE = 15;
const int ONE_DECIMAL = 1;
const int WIDTH_NAMES = 20;
const int WIDTH_LETTER_GRADES = 6;
const int WIDTH_EXAM_LETTERING = 9;
const int WIDTH_PRINTING_GRADES = 7;

void initializeArray (int array[], int size)
{
    for (int i = 0; i < size; i++)
    {
        array[i] = 0;
    }
}

int main(int argc, const char* argv[])
{
    VS_MEM_CHECK
    string name;
    ifstream in(argv[1]);
    ofstream out(argv[2]);
    int numStudents;
    int numTests;
    
    if (in.is_open())
    {
        in >> numStudents;
        in >> numTests;
        string student;
        string studentNames[numStudents];
        int scores[numStudents][numTests];
        //read from file
        for (int i = 0; i < numStudents; i++)
        {
            string firstName, lastName, fullName;
            in >> firstName >> lastName;
            studentNames[i] = firstName + " " + lastName;
            for (int j = 0; j < numTests; j++)
            {
                in >> scores[i][j];
            }
        }
        
        //print original file
        out << "Student Scores:\n";
        for (int i = 0; i < numStudents; i++)
        {
            out << setw(WIDTH_NAMES) << studentNames[i];
            for (int j = 0; j < numTests; j++)
            {
                out << setw(WIDTH_PRINTING_GRADES) << scores[i][j];
            }
            out << endl;
        }
        //calculate average test scores
        double averages[numTests];
        double scoreTotal = 0.0;
        for (int i = 0; i < numTests; i++)
        {
            scoreTotal = 0;
            for (int j = 0; j < numStudents; j++)
            {
                scoreTotal += scores[j][i];
            }
            averages[i] = scoreTotal / numStudents;
        }
        string grades[numStudents][numTests];
        for (int i = 0; i < numStudents; i++)
        {
            for (int j = 0; j < numTests; j++)
            {
                if (fabs(averages[j] - (double)scores[i][j]) <= TIER_ONE_RANGE)
                {
                    grades[i][j] = "C";
                } else if ((averages[j] - (double)scores[i][j]) >= -TIER_TWO_RANGE && (averages[j] - (double)scores[i][j]) <= 0)
                {
                    grades[i][j] = "B";
                } else if ((averages[j] - (double)scores[i][j]) <= TIER_TWO_RANGE && (averages[j] - (double)scores[i][j]) >= 0)
                {
                    grades[i][j] = "D";
                } else if ((averages[j] - (double)scores[i][j]) <= -TIER_TWO_RANGE)
                {
                    grades[i][j] = "A";
                } else if ((averages[j] - (double)scores[i][j]) >= TIER_TWO_RANGE)
                {
                    grades[i][j] = "E";
                }
            }
        }
        int numA[numTests];
        int numB[numTests], numC[numTests], numD[numTests], numE[numTests];
        //int numGrade[numStudents][numTests];
        initializeArray(numA, numTests);
        initializeArray(numB, numTests);
        initializeArray(numC, numTests);
        initializeArray(numD, numTests);
        initializeArray(numE, numTests);
        
        for (int i = 0; i < numStudents; i++)
        {
            for (int j = 0; j < numTests; j++)
            {
                if (grades[i][j] == "A")
                {
                    numA[j]++;
                } else if (grades[i][j] == "B")
                {
                    numB[j]++;
                } else if (grades[i][j] == "C")
                {
                    numC[j]++;
                } else if (grades[i][j] == "D")
                {
                    numD[j]++;
                } else if (grades[i][j] == "E")
                {
                    numE[j]++;
                }
            }
        }
        //Exam Averages
        out << "Exam Averages:\n";
        for (int i = 0; i < numTests; i++)
        {
            out << setw(WIDTH_EXAM_LETTERING) << right << "Exam " << i + 1 << " Average = " << setw(6) << fixed << setprecision(ONE_DECIMAL) << averages[i] << endl;
        }
        //Student Exam Grades
        out << "Student Exam Grades:\n";
        for (int i = 0; i < numStudents; i++)
        {
            out << setw(WIDTH_NAMES) << right << studentNames[i];
            for (int j = 0; j < numTests; j++)
            {
                out << setw(WIDTH_LETTER_GRADES) << right << scores[i][j] << "(" << grades[i][j] << ")";
            }
            out << endl;
        }
        //Exam Grades
        out << "Exam Grades:\n";
        for (int i = 0; i < numTests; i++)
        {
            out << setw(8) << right << "Exam" << setw(3) << i + 1;
            out << setw(5) << right << numA[i] << "(A)";
            out << setw(5) << right << numB[i] << "(B)";
            out << setw(5) << right << numC[i] << "(C)";
            out << setw(5) << right << numD[i] << "(D)";
            out << setw(5) << right << numE[i] << "(E)";
            out << endl;
        }
        //calculate students' final grade in class
        double finalGrade[numStudents];
        int totalScore;
        for (int i = 0; i < numStudents; i++)
        {
            totalScore = 0;
            for (int j = 0; j < numTests; j++)
            {
                totalScore += scores[i][j];
            }
            finalGrade[i] = (double)totalScore / numTests;
        }
        
        //average of all test scores
        double finalAverage = 0.0;
        for (int i = 0; i < numTests; i++)
        {
            finalAverage += averages[i];
        }
        finalAverage = finalAverage / numTests;
        //Student Final Grades
        string finalLetterGrade[numStudents];
        for (int i = 0; i < numStudents; i++)
        {
                if (fabs(finalAverage - (double)finalGrade[i]) <= TIER_ONE_RANGE)
                {
                    finalLetterGrade[i] = "C";
                } else if ((finalAverage - (double)finalGrade[i]) >= -TIER_TWO_RANGE && (finalAverage - (double)finalGrade[i]) <= 0)
                {
                    finalLetterGrade[i] = "B";
                } else if ((finalAverage - (double)finalGrade[i]) <= TIER_TWO_RANGE && (finalAverage - (double)finalGrade[i]) >= 0)
                {
                    finalLetterGrade[i] = "D";
                } else if ((finalAverage - (double)finalGrade[i]) <= -TIER_TWO_RANGE)
                {
                    finalLetterGrade[i] = "A";
                } else if ((finalAverage - (double)finalGrade[i]) >= TIER_TWO_RANGE)
                {
                    finalLetterGrade[i] = "E";
                }
        }
        out << "Student Final Grades:\n";
        for (int i = 0; i < numStudents; i++)
        {
            out << setw(WIDTH_NAMES) << studentNames[i];
            out << setw(6) << fixed << setprecision(ONE_DECIMAL) << finalGrade[i] << "(" << finalLetterGrade[i] << ")\n";
        }
        out << "Class Average Score = " << fixed << setprecision(ONE_DECIMAL) << finalAverage << endl;
        
        
        
    }
    else if (in.fail())
    {
        cerr << "fail\n";
    }
    return 0;
}
