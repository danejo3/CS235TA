/*
Riley Isom
CS 235 Lab 01 Grades
*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

int main(int argc, char* argv[]) {
	int numStudents = 0;
	int numExams = 0;
	ifstream input;
	input.open(argv[1]);
	if (!input) {
		cout << "File could not be opened" << endl;
		return 0;
	}
	ofstream output;
	output.open(argv[2]);
	if (!output) {
		cout << "File could not be opened" << endl;
		return 0;
	}

	//Outputting student grades
	output << "Student Scores: " << endl;
	input >> numStudents >> numExams;
	string studentFirstName;
	string studentLastName;
	string studentFullName;
	for (unsigned int i = 0; i < numStudents; i++) {
		input >> studentFirstName >> studentLastName;
		studentFullName = studentFirstName + " " + studentLastName;
		output << "\t" << fixed << setw(20) << studentFullName << " ";
		int examScore = 0;
		for (unsigned int j = 0; j < numExams; j++) {
			input >> examScore;
			output << fixed << setprecision(0) << setw(6) << examScore << " ";
		}
		output << endl;
	}

	input.close();
	output.close();
	system("pause");
	return 0;
}