/*
Name of file: main.cpp
Description: This program reads input from a user defined file, calculates the exam average, counts the number of each letter
grade, and outputs this information along with each student's numerical and letter grade for each exam to a user defined
output file.
Author Alias: LightFromAStone
*/
#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <limits>

using namespace std;
/**
	This function takes a students numerical grade and computes the letter grade based on the class average.
	@param classAverage the average of all students exam scores per exam
	@param examScore the particular score we wish to convert to a letter grade
	@return The grade letter which can be 'A', 'B', 'C','D', or 'E'.
*/
char determineGrade(double classAverage, double examScore)
{
	if (examScore <= classAverage + 5 && examScore >= classAverage - 5) { return 'C'; }
	else if (examScore <= classAverage - 15) { return 'E'; }
	else if (examScore >= classAverage + 15) { return 'A'; }
	else if (examScore < classAverage - 5 && examScore > classAverage - 15) { return 'D'; }
	else { return 'B'; }
}

int main(int argc, char* argv[])
{
	VS_MEM_CHECK               // enable memory leak check
	const int GRADE_PRECISION = 0;
	const int AVERAGES_PRECISION = 1;
	const int NAME_WIDTH = 20;
	const int GRADE_WIDTH = 6;
	const int EXAM_WIDTH = 10;
	const int COUNT_WIDTH = 5;

	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		return 1;
	}
	ofstream out(argv[2]);
	if (!out)
	{
		cerr << "Unable to open " << argv[2] << " for output";
		return 1;
	}

	int numStudents = 0;
	int numExams = 0;
	in >> numStudents >> numExams;
	in.ignore(numeric_limits<std::streamsize>::max(), '\n');

	// Create Dynamic Arrays for Grades and Names //
	int **studentGrades = new int*[numStudents];
	for (int i = 0; i < numStudents; ++i)
	{
		studentGrades[i] = new int[numExams];
	}
	string *studentNames = new string[numStudents];

	// Populate Name and Grades Arrays //
	string fullName;
	out << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		string firstName;
		string lastName;
		in >> firstName >> lastName;
		fullName = firstName + " " + lastName;
		studentNames[i] = fullName;
		out << setw(NAME_WIDTH) << fullName << " ";
		for (int j = 0; j < numExams; ++j)
		{
			in >> studentGrades[i][j];
			out << setw(GRADE_WIDTH) << studentGrades[i][j];
		}
		out << endl;
		in.ignore(numeric_limits<std::streamsize>::max(), '\n');
	}

	// Calculate Averages //
	double averageScore = 0.0;
	double classTotalScore = 0.0;
	double *examAverages = NULL;
	examAverages = new double[numExams];
	for (int i = 0; i < numExams; ++i)
	{
		double totalScore = 0.0;
		for (int j = 0; j < numStudents; ++j)
		{
			totalScore += studentGrades[j][i];
		}
		averageScore = totalScore / numStudents;
		classTotalScore += averageScore;
		examAverages[i] = averageScore;
	}

	// Print Exam Averages
	out << fixed << setprecision(AVERAGES_PRECISION);
	out << "Exam Averages:" << endl;
	for (int i = 0; i < numExams; ++i)
	{
		out << setw(EXAM_WIDTH) << "Exam " << i + 1 << " Average = ";
		out << setw(GRADE_WIDTH) << examAverages[i] << endl;
	}

	// Print Names and Grades //
	out << setprecision(GRADE_PRECISION);
	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		out << setw(NAME_WIDTH) << studentNames[i];
		for (int j = 0; j < numExams; ++j)
		{
			out << setw(GRADE_WIDTH) << studentGrades[i][j] << "(" << determineGrade(examAverages[j], studentGrades[i][j]) << ")";
		}
		out << endl;
	}

	// Print Exam Grades //
	out << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; ++i)
	{
		int countA = 0;
		int countB = 0;
		int countC = 0;
		int countD = 0;
		int countE = 0;
		out << setw(EXAM_WIDTH) << "Exam  " << i + 1;
		for (int j = 0; j < numStudents; ++j)
		{
			if (determineGrade(examAverages[i], studentGrades[j][i]) == 'A')
			{
				++countA;
			}
			else if (determineGrade(examAverages[i], studentGrades[j][i]) == 'B')
			{
				++countB;
			}
			else if (determineGrade(examAverages[i], studentGrades[j][i]) == 'C')
			{
				++countC;
			}
			else if (determineGrade(examAverages[i], studentGrades[j][i]) == 'D')
			{
				++countD;
			}
			else
			{
				++countE;
			}
		}
		out << setw(COUNT_WIDTH) << countA << "(A)";
		out << setw(COUNT_WIDTH) << countB << "(B)";
		out << setw(COUNT_WIDTH) << countC << "(C)";
		out << setw(COUNT_WIDTH) << countD << "(D)";
		out << setw(COUNT_WIDTH) << countE << "(E)" << endl;
	}

	// Print Student Final Grades //
	double classAverageScore = classTotalScore / numExams;
	out << "Student Final Grades:" << endl;
	out << fixed << setprecision(AVERAGES_PRECISION);
	for (int i = 0; i < numStudents; ++i)
	{
		out << setw(NAME_WIDTH) << studentNames[i];
		double totalStudentScore = 0.0;
		for (int j = 0; j < numExams; ++j)
		{
			totalStudentScore += studentGrades[i][j];
		}
		double studentFinalGrade = totalStudentScore / numExams;
		out << "  " << studentFinalGrade << "(" << determineGrade(classAverageScore, studentFinalGrade) << ")";
		out << endl;
	}
	out << "Class Average Score = " << classAverageScore << endl;

	// Delete Array Memory //
	for (int i = 0; i < numStudents; ++i)
	{
		delete[] studentGrades[i];
	}
	delete[] studentGrades;
	delete[] studentNames;
	delete[] examAverages;

	return 0;
}