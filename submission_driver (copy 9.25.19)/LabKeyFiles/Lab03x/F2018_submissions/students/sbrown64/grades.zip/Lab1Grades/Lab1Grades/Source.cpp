/*
Author: Sebastian Brown (sebascientist@gmail.com)
NetID: sbrown64
Class: C S 235 Section 003
Date: 21/9/18
Lab 1: Grades
Input(s): Input and output file names from command line
Output(s): Text file with name specified in command line
*/


//PREPROCESSOR MACROS
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>

#ifdef _MSC_VER
	#define _CRTDBG_MAP_ALLOC  
	#include <crtdbg.h>
	#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
	#define VS_MEM_CHECK
#endif

using namespace std;


//GLOBAL CONSTANTS
int MAXROWS = 100;
int MAXCOLS = 200;
int TYPICALWIDTH = 20;
int SHORTWIDTH = 7;


//NON-MAIN FUNCTIONS
/** Ensures that program will run correctly (checks command line arguments and whether input and output files opened correctly)
   @param int arg: Number of command line arguments
   @param char *argv[]: Pointer to array containing command line arguments
   @param ifstream &in: Input file stream
   @param ofsteam &out: Output file stream
   @return int: Error/success code (0 == no errors detected)
*/
int initialCheck(int argc, char *argv[], ifstream &in, ofstream &out) {
	//Checks for command line arguments 
	if (argc < 3) {
		cerr << "Please provide name of input and output files";
		return 1;
	}

	//Checks if file opened correctly
	if (!in) {
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}

	//Checks if output file opened correctly; closes input file before returning 
	if (!out) {
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	return 0;
}


/** Returns the index at which student scores start in line (i.e. where characters become numeric)
   @param string line: The line of the input file in question
   @return int digitStart: The aforementioned index
*/
int getStartingDigit(string line) {
	int digitStart = 0;
	while (!isdigit(line[digitStart])) {
		++digitStart;
	}
	return digitStart;
}


/** Gets student's first and last names from line, concatenates them (with a space in between), and returns the resulting string
   @param line: The line of the input file in question
   @return name: The student's full name (first & last together)
*/
string getFullName(string line) {
	string first_name;
	string last_name;
	istringstream name_stream(line); // puts student's name into name_stream (along with rest of line)
	name_stream >> first_name >> last_name;
	string name = first_name + " " + last_name;
	return name;
}


/** Inputs student scores into score array and writes them to output file
   @param string scoreLine: A string containing all of a student's exam scores
   @param int **studentArray: The pointer to the 2D dynamic array containing student scores
   @param const int &studentCounter: Refers to row index of the 2D dynamic array (student number)
   @param int &testCounter: Refers to column index of the 2D dynamic array (test number)
   @param ofstream &out: Output file stream
*/
void addScores(string scoreLine, int **studentArray, const int &studentCounter, int &testCounter, ofstream &out) {
	istringstream iss(scoreLine);
	string score;
	testCounter = 1;
	while (iss >> score) {
		studentArray[studentCounter][testCounter] = stoi(score);
		out << setw(SHORTWIDTH) << score; //writes scores to output file
		testCounter++;
	}
	return;
}


/** Fills averagesArray with average exam scores and writes them to output file
   @param int **studentArray: The pointer to the 2D dynamic array containing student scores
   @param double *averagesArray: The pointer to the dynamic array containing exam averages
   @param const int &studentTotal: Refers to total number of students
   @param const int &testTotal: Refers to total number of students
   @param ofstream &out: Output file stream
*/
void getAverages(int **studentArray, double *averagesArray, const int &studentTotal, const int &testTotal, ofstream &out) {
	for (int test = 1; test <= testTotal; test++) {
		int test_score_total = 0;
		for (int student = 1; student <= studentTotal; student++) {
			test_score_total += studentArray[student][test]; //sums all student scores for a test
		}

		double test_score_avg = test_score_total / static_cast<double>(studentTotal);

		test_score_avg = static_cast<int>(test_score_avg * 10 + 0.5) / 10.0; //rounds test score to one decimal place
		averagesArray[test] = test_score_avg; //stores test average
		out << setw(TYPICALWIDTH) << right << "Exam " << test << " Average = ";
		out << fixed << setprecision(1) << test_score_avg << endl;
	}
	return;
}


/** Writes student exam grades to output file
   @param int **studentArray: The pointer to the 2D dynamic array containing student scores
   @param string *nameArray: The pointer to the dynamic array containing student names
   @param double *averagesArray: The pointer to the dynamic array containing exam averages
   @param const int &studentTotal: Refers to total number of students
   @param const int &testTotal: Refers to total number of students
   @param ofstream &out: Output file stream
*/
void outputStudentGrades(int **studentArray, string *nameArray, double *averagesArray, const int &studentTotal, const int &testTotal, ofstream &out) {
	string gradeOutput;
	for (int student = 1; student <= studentTotal; ++student) {
		out << setw(TYPICALWIDTH) << right << nameArray[student];
		for (int test = 1; test <= testTotal; ++test) {
			if (studentArray[student][test] >= averagesArray[test] + 15) {
				gradeOutput = " " + to_string(studentArray[student][test]) + "(A)";
				out << setw(SHORTWIDTH) << right << gradeOutput;
			}
			else if ((studentArray[student][test] > averagesArray[test] + 5) && (studentArray[student][test] < averagesArray[test] + 15)) {
				gradeOutput = " " + to_string(studentArray[student][test]) + "(B)";
				out << setw(SHORTWIDTH) << right << gradeOutput;
			}
			else if ((studentArray[student][test] >= averagesArray[test] - 5) && (studentArray[student][test] <= averagesArray[test] + 5)) {
				gradeOutput = " " + to_string(studentArray[student][test]) + "(C)";
				out << setw(SHORTWIDTH) << right << gradeOutput;
			}
			else if ((studentArray[student][test] > averagesArray[test] - 15) && (studentArray[student][test] < averagesArray[test] - 5)) {
				gradeOutput = " " + to_string(studentArray[student][test]) + "(D)";
				out << setw(SHORTWIDTH) << right << gradeOutput;
			}
			else if (studentArray[student][test] <= averagesArray[test] - 15) {
				gradeOutput = " " + to_string(studentArray[student][test]) + "(E)";
				out << setw(SHORTWIDTH) << right << gradeOutput;
			}
		}
		out << endl;
	}
	return;
}


/** Writes total number of each grade for each test to output file
   @param int **studentArray: The pointer to the 2D dynamic array containing student scores
   @param double *averagesArray: The pointer to the dynamic array containing exam averages
   @param const int &studentTotal: Refers to total number of students
   @param const int &testTotal: Refers to total number of students
   @param ofstream &out: Output file stream
*/
void outputExamGradeCounts(int **studentArray, double *averagesArray, const int &studentTotal, const int &testTotal, ofstream &out) {
	for (int test = 1; test <= testTotal; ++test) {
		int a_counter = 0;
		int b_counter = 0;
		int c_counter = 0;
		int d_counter = 0;
		int e_counter = 0;
		string a_count_output;
		string b_count_output;
		string c_count_output;
		string d_count_output;
		string e_count_output;
		for (int student = 1; student <= studentTotal; ++student) {
			if (studentArray[student][test] >= averagesArray[test] + 15) {
				a_counter++;
			}
			else if ((studentArray[student][test] > averagesArray[test] + 5) && (studentArray[student][test] < averagesArray[test] + 15)) {
				b_counter++;
			}
			else if ((studentArray[student][test] >= averagesArray[test] - 5) && (studentArray[student][test] <= averagesArray[test] + 5)) {
				c_counter++;
			}
			else if ((studentArray[student][test] > averagesArray[test] - 15) && (studentArray[student][test] < averagesArray[test] - 5)) {
				d_counter++;
			}
			else if (studentArray[student][test] <= averagesArray[test] - 15) {
				e_counter++;
			}
		}
		a_count_output = " " + to_string(a_counter) + "(A)";
		b_count_output = " " + to_string(b_counter) + "(B)";
		c_count_output = " " + to_string(c_counter) + "(C)";
		d_count_output = " " + to_string(d_counter) + "(D)";
		e_count_output = " " + to_string(e_counter) + "(E)";
		out << "Exam " << test << a_count_output << b_count_output << c_count_output << d_count_output << e_count_output << endl;
	}
	return;
}


/** Writes students' final grades and total class average to output file
   @param int **studentArray: The pointer to the 2D dynamic array containing student scores
   @param string *nameArray: The pointer to the dynamic array containing student names
   @param double *averagesArray: The pointer to the dynamic array containing exam averages
   @param const int &studentTotal: Refers to total number of students
   @param const int &testTotal: Refers to total number of students
   @param ofstream &out: Output file stream
*/
void outputFinalGrades(int **studentArray, string *nameArray, double *averagesArray, const int &studentTotal, const int &testTotal, ofstream &out) {
	//UNDER CONSTRUCTION (FOR USE IN EXTRA CREDIT PART OF LAB)
	return;
}


/**Closes and deletes as needed to prevent memory leaks
   @param int **studentArray: The pointer to the 2D dynamic array containing student scores
   @param string *nameArray: The pointer to the dynamic array containing student names
   @param double *averagesArray: The pointer to the dynamic array containing exam averages
   @param ifstream &in: Input file stream
   @param ofstream &out: Output file stream
*/
void cleanup(int **studentArray, string *nameArray, double *averagesArray, ifstream &in, ofstream &out) {
	//First arrays
	for (int i = 0; i < MAXROWS; ++i) {
		delete[] studentArray[i];
	}
	delete[] studentArray;
	delete[] nameArray;
	delete[] averagesArray;

	//Then streams
	in.close();
	out.close();
	return;
}


//MAIN FUNCTION
int main(int argc, char *argv[]) {
	VS_MEM_CHECK // enables memory leak check

	ifstream in(argv[1]);
	ofstream out(argv[2]);
	int initialErrorCheckNum = initialCheck(argc, argv, in, out);
	if (initialErrorCheckNum != 0) { // exits program with appropriate error code unless 0
		return initialErrorCheckNum;
	}

	//Gets number of students and exams from input stream
	int num_students;
	int num_exams;
	in >> num_students >> num_exams;
	
	in.ignore(numeric_limits<int>::max(), '\n'); // skips the rest of the first line
	
	//Block below initializes dynamic arrays to hold names and scores
	int **studentArray = new int *[MAXROWS]; // for holding scores 
	for (int i = 0; i < MAXROWS; ++i)
	{
		studentArray[i] = new int[MAXCOLS];
	}
	string *nameArray = new string[MAXROWS]; //for holding names

	out << "Student Scores:\n"; //writes section header to output file
	int studentCounter = 1;
	int testCounter = 1;
	string line;
	while (getline(in, line)) { // stores the next line in line variable
		string name = getFullName(line);
		nameArray[studentCounter] = name; // stores student name in dynamic array
		out << setw(TYPICALWIDTH) << right << name << " "; // writes name to output file

		int digitStart = getStartingDigit(line); // line[digit_start] will be the first digit in the line
		string scoreLine = line.substr(digitStart); // scoreLine will only have scores

		addScores(scoreLine, studentArray, studentCounter, testCounter, out); // inputs scores into array and writes them to output file

		out << endl;

		studentCounter++; // iteration required so addScores will update the correct elements of 2D dynamic array
	}

	//Code block below stores total number of students and exams
	int studentTotal = studentCounter - 1;
	int testTotal = testCounter - 1;

	out << "Exam Averages:\n";
	double *averagesArray = new double[MAXROWS]; // creates dynamic array to store exam averages
	getAverages(studentArray, averagesArray, studentTotal, testTotal, out); // fills averagesArray with average exam scores and writes them to output file

	out << "Student Exam Grades:\n";
	outputStudentGrades(studentArray, nameArray, averagesArray, studentTotal, testTotal, out); // writes student exam grades to output file
	
	out << "Exam Grades:\n";
	outputExamGradeCounts(studentArray, averagesArray, studentTotal, testTotal, out); // writes total number of each grade for each test to output file
	
	out << "Student Final Grades :\n";
	outputFinalGrades(studentArray, nameArray, averagesArray, studentTotal, testTotal, out); // writes students' final grades and total class average to output file

	cleanup(studentArray, nameArray, averagesArray, in, out); // closes and deletes as needed to prevent memory leaks

	return 0;
}