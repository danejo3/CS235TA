/*Description
"Write a program that reads from an input file a person's name followed by all their exam scores. 
Calculate and write the average score for all students on each exam to an output file. 
Then, write each student's name to the output file followed by the student's score and grade on each exam."
*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

int main(int argc, char* argv[])
{
	//Enable memory leak check
	VS_MEM_CHECK
	

	//
	//COLLECTION SECTION OF PROGRAM
	//

	//Open input and output files
	ifstream in(argv[1]);
	if (!in) return 1;
	ofstream out(argv[2]);
	if (!out) return 2;
	
	//First line of input: (# of students) (# of exams)
	//Get numbers in order to pass them arrays
	int numStudents = 0;
	in >> numStudents;
	int numExams = 0;
	in >> numExams;
    
	//Collect Names and put in studentNames, collect scores and put in 2d array studentScores
    string *studentNames = new string[numStudents];
	double **studentScores = new double*[numStudents];
	for (int i = 0; i < numStudents; ++i)
	{
		studentScores[i] = new double[numExams];
	}

	//Repeats for each student in file to collect each student's data
	for (int i = 0; i < numStudents; ++i)
	{
		//collect student name: 1st two entries on line
		//Note: can't concatenate string literal and string object, thus the "addSpace" variable
		string firstName;
		string lastName;
		string addSpace = " ";
		string fullName;
		in  >> firstName;
		in  >> lastName;
		fullName = firstName + addSpace + lastName;
		studentNames[i] = fullName;

		//and one line's worth of grades and add it to a column in studentScores
		//Note: Column index corresponds to name of student in the same column index in "numStudents"
		for (int j = 0; j < numExams; ++j)
		{
			in >> studentScores[i][j];
		}
	}
	
	
	
	
	//
	// DISPLAY & CALCULATION SECTION OF PROGRAM
	//

	const int PRETTY_DISPLAY_WIDTH_1 = 20;
	const int PRETTY_COL_WIDTH_1 = 6;
	const int PRETTY_DISPLAY_WIDTH_2 = 9;

	//Display Student Scores
	out << "Student Scores: " << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		//format output, setw used to make it line up and look pretty
		out << setw(PRETTY_DISPLAY_WIDTH_1) << studentNames[i];
		for (int j = 0; j < numExams; ++j)
		{
			out << " " << setw(PRETTY_COL_WIDTH_1) << studentScores[i][j];
		}
		out << endl;
	}


	//Iterates through each student and takes score from exam (at index i)
	//to calculate average for that exam, stores average in array at index i
	out << "Exam Averages: " << endl;
	double *examAverages = new double[numExams];
	for (int i = 0; i < numExams; ++i)
	{
		double sumExamScores = 0.0;

		for (int j = 0; j < numStudents; ++j)
		{
			sumExamScores += studentScores[j][i];
		}

		double averageScore = (sumExamScores / numStudents);
		examAverages[i] = averageScore;
		out << setw(PRETTY_DISPLAY_WIDTH_2) << "Exam " << i+1 << " Average = ";//index i is one less than Exam #
		out << setw(PRETTY_COL_WIDTH_1)     <<  fixed  << setprecision(1) <<examAverages[i] << endl;
	}



	//Assigns grade to each test score of each student according to the following set of thresholds
	//-----A: 15 or more ABOVE average
	//-----B: more than 5 ABOVE average but not 15 or more ABOVE average
	//-----C: within 5 points of the average, inclusive
	//------D: more than 5 BELOW average but NOT 15 or more BELOW the average
	//------E: 15 or more BELOW the average
	double thresholdC = 5.0;
	double thresholdAE = 15.0;

	//Stores grades in corresponding 2d array
	//Counts number of As, Bs, Cs, Ds, and Es received and places in array
	//with column 0 corresponding to # of As, column 1 to # of Bs, etc.
	string **studentLetterGrades = new string*[numStudents];
	for (int i = 0; i < numStudents; ++i)
	{
		studentLetterGrades[i] = new string[numExams];
	}


	//Keeps track of # of As, Bs, Cs, Ds, Es for each exam
	const int NUM_LETTER_GRADES = 5;
	int **examLetterAmounts = new int*[numExams];
	for (int i = 0; i < numExams; ++i)
	{
		examLetterAmounts[i] = new int[NUM_LETTER_GRADES];
		for (int j = 0; j < NUM_LETTER_GRADES; ++j)
		{
			examLetterAmounts[i][j] = 0; //initialize total of every letter grade per exam to 0
		}
	}

	out << "Student Exam Grades: " << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		out << setw(PRETTY_DISPLAY_WIDTH_1) << studentNames[i];
		for (int j = 0; j < numExams; ++j)
		{
            double maxEScore = examAverages[j] - thresholdAE;
			double minCScore = examAverages[j] - thresholdC;
			double maxCScore = examAverages[j] + thresholdC;
			double minAScore = examAverages[j] + thresholdAE;
			//Note: Order matters in these if statements
			if (studentScores[i][j] <= maxEScore) //if student scored thresholdAE or below average receive an E
			{
				studentLetterGrades[i][j] = "(E)";
				examLetterAmounts[j][4] += 1; //(4 = index of E grade) Increase count of (E) grade on Exam # j by one 
			}
			else if (studentScores[i][j] < minCScore)//if student scored above thresholdAE less than avg but below thresholdC less than avg receive D
			{
				studentLetterGrades[i][j] = "(D)";
				examLetterAmounts[j][3] += 1; //(3 = index of D grade) Increase count of (D) grade on Exam # j by one 
			}
			else if (studentScores[i][j] <= maxCScore)//if student scored thresholdC or more above avg but no more than thresholdC above the avg receive C
			{
				studentLetterGrades[i][j] = "(C)";
				examLetterAmounts[j][2] += 1; //(2 = index of C grade) Increase count of (C) grade on Exam # j by one 
			}
			else if (studentScores[i][j] < minAScore)//if student scored more than thresholdC above average but less than thresholdAE above average receive B
			{
				studentLetterGrades[i][j] = "(B)";
				examLetterAmounts[j][1] += 1; //(1 = index of B grade) Increase count of (B) grade on Exam # j by one 
			}
			else //Student therefore scored high enough to receive A
			{
				studentLetterGrades[i][j] = "(A)";
				examLetterAmounts[j][0] += 1; //(0 = index of A grade) Increase count of (A) grade on Exam # j by one 
			}

			out << setw(PRETTY_COL_WIDTH_1) << static_cast<int>(studentScores[i][j]) << studentLetterGrades[i][j]; //print out grade and score of each test taken
			
			
		}
		out << endl;
	}
	


	//Display the Total # of Letter grades for various quizes
	int PRETTY_DISPLAY_WIDTH_3 = 10;
	int PRETTY_COL_WIDTH_2 = 5;
	string possibleLetterGrades[] = { "(A)", "(B)", "(C)", "(D)", "(E)"};

	out << "Exam Grades: " << endl;
	for (int i = 0; i < numExams; ++i)
	{
		out << setw(PRETTY_DISPLAY_WIDTH_3) << "Exam  " << i+1;//Exam 1 is at i = 0, Exam 2 at i = 1, etc.
		for (int j = 0; j < NUM_LETTER_GRADES; ++j)
		{
			out << setw(PRETTY_COL_WIDTH_2) << static_cast<int>(examLetterAmounts[i][j]) << possibleLetterGrades[j];
		}
		out << endl;
	}
	



	//Clean up dynamically allocated Memory
	delete[] studentNames;
	for (int i = 0; i < numStudents; ++i)
	{
		delete[] studentScores[i];
		delete[] studentLetterGrades[i];
	}
	delete[] studentScores;
	delete[] studentLetterGrades;
	for (int i = 0; i < numExams; ++i)
	{
		delete[] examLetterAmounts[i];
	}
	delete[] examLetterAmounts;
	delete[] examAverages;
	


	//Close input and output files
	in.close();
	out.close();

	return 0;
}