#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <string>

using namespace std;

int main (int argc, char* argv[])
{
	string line;
	
	//for (int i = 1; i < argc; i++)
	{
		ifstream in(argv[1]);
		int NumStudent = 0;
		int NumScore = 0;

		if (in.is_open())
		{
			cout << "Student Scores: " << endl;

			if (!in.eof())
			{
				in >> NumStudent >> NumScore;
				in.ignore(std::numeric_limits<int>::max(), '\n');
			}

			string* StudentName = new string[NumStudent];
			int** ExamScores = new int*[NumStudent];
			
			for (int i = 0; i < NumStudent; i++)
			{
				ExamScores[i] = new int[NumScore];
			}


			int idx = 0;
			
			while (!in.eof() && idx < NumStudent)
			{
				getline(in, line);
				int pos = line.find(" ");
				int start = 0;
				string FirstName = line.substr(start, pos);
				start = pos + 1;
				pos = line.find(" ", start);
				string LastName = line.substr(start, pos-start);
				StudentName[idx] = FirstName + " " + LastName;
				cout << StudentName[idx] << " ";

				for (int i = 0 ; i < NumScore; i++)
				{
					start = pos + 1;
					while (line[start] == ' ')
					{
						start++;
					}
					pos = line.find(" ", start);
					


					string StudentScore = "";
					
					if (pos == -1)
					{
						StudentScore = line.substr(start, line.length() - start);
					}
					
					else
					{
						StudentScore = line.substr(start, pos - start);
					}

					int ScoreNumber = atoi(StudentScore.c_str());
					ExamScores[idx][i] = ScoreNumber;
					cout << ScoreNumber << " ";
				}

				idx++;
				cout << endl;
			}

			in.close();

			// calculate the average scores
			double* AverageScores = new double[NumScore];
			for (int j = 0; j < NumScore; j++)
			{
				AverageScores[j] = 0;
			}
			for (int i = 0; i < NumStudent; i++)
			{
				for (int j = 0; j < NumScore; j++)
				{
					AverageScores[j] += ExamScores[i][j];
				}
			}
			for (int j = 0; j < NumScore; j++)
			{
				AverageScores[j] = AverageScores[j] / NumStudent;
			}
				
				
			for (int j = 0; j < NumScore; j++)
			{
				cout << setprecision(1) << fixed << "Exam " << j+1 << " Average "   << AverageScores[j] << endl;
			}


			// output student scores
			string** StudentGrades = new string*[NumStudent];
			for (int i = 0; i < NumStudent; i++)
			{
				StudentGrades[i] = new string[NumScore];
			}
			int ** GradeCounts = new int*[NumScore];
			for (int i = 0; i < NumScore; i++)
			{
				GradeCounts[i] = new int[5];
			}

			for (int i = 0; i < NumStudent; i++)
			{
				for (int j = 0; j < NumScore; j++)
				{
					double diff = ExamScores[i][j] - AverageScores[j];
					if (diff > 15)
					{
						StudentGrades[i][j] = "A";
						GradeCounts[j][0] += 1;
					}
					else if (diff > 5)
					{
						StudentGrades[i][j] = "B";
						GradeCounts[j][1] += 1;
					}
					else if (diff >= -5)
					{
						StudentGrades[i][j] = "C";
						GradeCounts[j][2] += 1;
					}
					else if (diff >= -15)
					{
						StudentGrades[i][j] = "D";
						GradeCounts[j][3] += 1;
					}
					else
					{
						StudentGrades[i][j] = "E";
						GradeCounts[j][4] += 1;
					}
				}
			}

			for (int i = 0; i < NumStudent; i++)
			{
				cout << StudentName[i];
				for (int j = 0; j < NumScore; j++)
				{
					cout << setprecision(1) << fixed << ExamScores[i][j] << "(" << StudentGrades[i][j] << ") ";
				}
				cout << endl;
			}

			//output final grades
			double* FinalGrades = new double[NumStudent];
			double ClassAverage = 0;
			for (int i = 0; i < NumStudent; i++)
			{
				for (int j = 0; j < NumScore; j++)
				{
					ClassAverage += ExamScores[i][j];
					FinalGrades[i] += ExamScores[i][j];

					double FinalDiff = ExamScores[i][j] - FinalGrades[j];
					if (FinalDiff > 15)
					{
						//change which array these are pulling from
						StudentGrades[i][j] = "A";
					}
					else if (FinalDiff > 5)
					{
						StudentGrades[i][j] = "B";
					}
					else if (FinalDiff >= -5)
					{
						StudentGrades[i][j] = "C";
					}
					else if (FinalDiff >= -15)
					{
						StudentGrades[i][j] = "D";
					}
					else
					{
						StudentGrades[i][j] = "E";
					}

				}

				FinalGrades[i] = FinalGrades[i] / NumScore;
			
			}
			ClassAverage = ClassAverage / (NumStudent * NumScore);

					   			 
			// clean up all my memory

			for (int i = 0; i < NumStudent; i++)
			{
				delete[] StudentGrades[i];
				delete[] ExamScores[i];
			}
			for (int i = 0; i < NumScore; i++)
			{
				delete[] GradeCounts[i];
			}
			delete[] GradeCounts;
			delete[] AverageScores;
			delete[] FinalGrades;
			delete[] StudentGrades;
			delete[] ExamScores;
			delete[] StudentName;

		
		}

		else
		{
			cout << "Error";
		}

	}
}