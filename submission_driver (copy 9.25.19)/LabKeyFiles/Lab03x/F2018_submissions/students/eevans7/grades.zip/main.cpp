#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <iomanip>
#include <ios>

using namespace std;

//The function takes in a score and returns the grade it would recieve based on the average score
string calculateGrade(int score, double average) {
	const int C_MARGIN = 5;
	const int B_MARGIN = 15;
	const int D_MARGIN = -15;
	const int A_MARGIN = 15;
	const int E_MARGIN = -15;
	if (((score - average) <= 5.0001) && (score - average >= -5.251)){ 
		return "(C)";
	}
	else if ((score - average) < 14.999 && (score - average > 5.0001)) {
		return "(B)";
	}
	else if ((score - average) > -14.999 && (score - average) < -5.251) {
		return "(D)";
	}
	else if ((score - average) >= 14.999) {
		return "(A)";
	}
	else if ((score - average) <= -14.999) {
		return "(E)";
	}
	else {
		return " ";
	}
}

int main(int argc, char* argv[]) {
	const int NAME_WIDTH = 20;
	const int NUM_WIDTH = 7;
	const int EXAM_GRADES_FORMAT = 5;
	const int EXAM_FORMAT = 10;
	const int EXAM_AVERAGE_FORMAT = 9;
	if (argc != 3) {
		cout << "Pass the arguments";
		system("pause");
		return 1;
	}
	ifstream inFS(argv[1]);
	if (!inFS)
	{
		cout << "you dun messed up\n";
	}
	ofstream outFS(argv[2]);
	int numStudents;
	int numExams;
	inFS >> numStudents;
	inFS >> numExams;
	string* studentList = new string[numStudents];
	int** examScores = new int*[numStudents];
	for (int x = 0; x < numStudents; ++x) {
		examScores[x] = new int[numExams];
	}
	for (int x = 0; x < numStudents; ++x) {
		string firstName;
		string lastName;
		inFS >> firstName;
		inFS >> lastName;
		studentList[x] = firstName + " " + lastName;
		for (int y = 0; y < numExams; ++y) {
			inFS >> examScores[x][y];
		}
	}
	outFS << "Student Scores:" << endl;
	for (int x = 0; x < numStudents; ++x) {
		outFS << setw(NAME_WIDTH) << right << studentList[x];
		for (int y = 0; y < numExams; ++y) {
			outFS << setw(NUM_WIDTH) << right << examScores[x][y];
		}
		outFS << endl;
	}
	outFS << "Exam Averages:" << endl;
	double* examAverages = new double[numExams];
	for (int y = 0; y < numExams; ++y) {
		double examAverage = 0;
		for (int x = 0; x < numStudents; ++x) {
			examAverage += examScores[x][y];
		}
		examAverage /= numStudents;
		outFS << setw(EXAM_AVERAGE_FORMAT) << right << "Exam " << y + 1 << " Average =";
		outFS << setw(NUM_WIDTH) << right << fixed << setprecision(1) << examAverage << endl;
		examAverages[y] = examAverage;
	}
	outFS << "Student Exam Grades:" << endl;

	for (int x = 0; x < numStudents; ++x) {
		outFS << setw(NAME_WIDTH) << right << studentList[x];
		for (int y = 0; y < numExams; ++y) {
			outFS << setw(NUM_WIDTH - 1) << right << examScores[x][y]
				<< calculateGrade(examScores[x][y], examAverages[y]);
		}
		outFS << endl;
	}
	outFS << "Exam Grades:" << endl;
	for (int y = 0; y < numExams; ++y) {
		int numAs = 0, numBs = 0, numCs = 0, numDs = 0, numEs = 0;
		for (int x = 0; x < numStudents; ++x) {
			if (calculateGrade(examScores[x][y], examAverages[y]) == "(A)") {
				numAs++;
			}
			else if (calculateGrade(examScores[x][y], examAverages[y]) == "(B)") {
				numBs++;
			}
			else if (calculateGrade(examScores[x][y], examAverages[y]) == "(C)") {
				numCs++;
			}
			else if (calculateGrade(examScores[x][y], examAverages[y]) == "(D)") {
				numDs++;
			}
			else if (calculateGrade(examScores[x][y], examAverages[y]) == "(E)") {
				numEs++;
			}
		}
		outFS << setw(EXAM_FORMAT) << right << "Exam  " << y + 1;
		outFS << setw(EXAM_GRADES_FORMAT) << right << numAs << "(A)";
		outFS << setw(EXAM_GRADES_FORMAT) << right << numBs << "(B)";
		outFS << setw(EXAM_GRADES_FORMAT) << right << numCs << "(C)";
		outFS << setw(EXAM_GRADES_FORMAT) << right << numDs << "(D)";
		outFS << setw(EXAM_GRADES_FORMAT) << right << numEs << "(E)" << endl;
	}
	outFS << "Student Final Grades:" << endl;
	double classAverage = 0;
	for (int x = 0; x < numStudents; ++x) {
		for (int y = 0; y < numExams; ++y) {
			classAverage += examScores[x][y];
		}
	}
	classAverage /= (numStudents * numExams);
	for (int x = 0; x < numStudents; ++x) {
		double studentAverage = 0;
		for (int y = 0; y < numExams; ++y) {
			studentAverage += examScores[x][y];
		}
		studentAverage /= numExams;
		outFS << setw(NAME_WIDTH) << right << studentList[x];
		outFS << " " << fixed << setprecision(1) << studentAverage
			<< calculateGrade(studentAverage, classAverage) << endl;
	}
	outFS << "Class Average Score = " << fixed << setprecision(1) << classAverage;
	for (int x = 0; x < numStudents; ++x) {
		delete[] examScores[x];
	}
	delete[] examScores;
	delete[] studentList;
	delete[] examAverages;
}

