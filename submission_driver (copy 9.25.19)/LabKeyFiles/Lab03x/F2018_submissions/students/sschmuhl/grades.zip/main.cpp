#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>

using namespace std;

// This function will calculate the grade of a test based on the average score of that test
string calculateGrade(int testScore, double testAverage)
{
	const double C_MARGIN = 5.175;
	const double B_D_MARGIN = 15.0;
	
	if (((testScore >= testAverage - C_MARGIN) && (testScore <= testAverage)) || ((testScore <= testAverage + C_MARGIN) && (testScore >= testAverage)))
	{
		return "(C)";
	}
	else if (testScore > testAverage - B_D_MARGIN && testScore < testAverage - C_MARGIN)
	{
		return "(D)";
	}
	else if (testScore < testAverage + B_D_MARGIN && testScore > testAverage + C_MARGIN)
	{
		return "(B)";
	}
	else if (testScore >= testAverage + B_D_MARGIN)
	{
		return "(A)";
	}
	else if (testScore <= testAverage - B_D_MARGIN)
	{
		return "(E)";
	}
}

int main(int argc, char** argv)
{
	VS_MEM_CHECK
	ifstream inFS(argv[1]);
	ofstream outFS(argv[2]);
	int numStudents = 0;
	int numExams = 0;
	double classAverage = 0.0;
	string* studentNames = NULL;
	int** studentScores = NULL;
	double* examAverages = NULL;
	// The following are various constants used for setw
	const int NAME_WIDTH = 20;
	const int EXAM_WIDTH = 7;
	const int AVERAGE_WIDTH = 9;
	const int DECIMAL_LENGTH = 1;
	const int NUMBER_WIDTH = 5;

	// Reading in the file inputs
	inFS >> numStudents;
	inFS >> numExams;

	// Allocating memory
	studentNames = new string[numStudents];
	studentScores = new int*[numStudents];
	examAverages = new double[numExams];

	for (int i = 0; i < numStudents; ++i)
	{
		studentScores[i] = new int[numExams];
	}

	for (int i = 0; i < numStudents; ++i)
	{
		string firstName;
		string lastName;

		inFS >> firstName;
		inFS >> lastName;
		studentNames[i] = firstName + " " + lastName;
		for (int j = 0; j < numExams; ++j)
		{
			inFS >> studentScores[i][j];
		}
	}

	// Calculating the average scores for each exam indiviually
	for (int i = 0; i < numExams; ++i)
	{
		double testAverage = 0.0;

		for (int j = 0; j < numStudents; ++j)
		{
			testAverage = testAverage + studentScores[j][i];
		}
		testAverage = testAverage / numStudents;
		examAverages[i] = testAverage;
	}

	// Calculating the average score of all tests taken
	for (int i = 0; i < numStudents; ++i)
	{
		for (int j = 0; j < numExams; ++j)
		{
			classAverage = classAverage + studentScores[i][j];
		}
		if (i == numStudents - 1)
		{
			classAverage = classAverage / (numStudents * numExams);
		}
	}

	// Outputting the students' names and scores
	outFS << "Student Scores:" << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		outFS << setw(NAME_WIDTH) << right;
		outFS << studentNames[i];
		for (int j = 0; j < numExams; ++j)
		{
			outFS << setw(EXAM_WIDTH) << right;
			outFS << studentScores[i][j];
		}
		outFS << endl;
	}

	// Outputting the average of each exam
	outFS << "Exam Averages:" << endl;
	for (int i = 0; i < numExams; ++i)
	{
		outFS << setw(AVERAGE_WIDTH) << right;
		outFS << "Exam " << i + 1 << " Average =";
		outFS << setw(EXAM_WIDTH) << right;
		outFS << fixed << setprecision(DECIMAL_LENGTH);
		outFS << examAverages[i] << endl;
	}
	
	// Outputting the students' names and grades on each individual test
	outFS << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		outFS << setw(NAME_WIDTH) << right;
		outFS << studentNames[i];
		for (int j = 0; j < numExams; ++j)
		{
			outFS << setw(AVERAGE_WIDTH) << right;
			outFS << studentScores[i][j];
			outFS << calculateGrade(studentScores[i][j], examAverages[j]);
		}
		outFS << endl;
	}

	// Outputting the total amounts of each letter grade earned on each test
	outFS << "Exam Grades:" << endl;
	for (int i = 0; i < numExams; ++i)
	{
		int numA = 0;
		int numB = 0;
		int numC = 0;
		int numD = 0;
		int numE = 0;
		
		outFS << setw(AVERAGE_WIDTH) << right;
		outFS << "Exam " << " " << i + 1;
		for (int j = 0; j < numStudents; ++j)
		{

			if (calculateGrade(studentScores[j][i], examAverages[i]) == "(A)")
			{
				numA = ++numA;
			}
			else if (calculateGrade(studentScores[j][i], examAverages[i]) == "(B)")
			{
				numB = ++numB;
			}
			else if (calculateGrade(studentScores[j][i], examAverages[i]) == "(C)")
			{
				numC = ++numC;
			}
			else if (calculateGrade(studentScores[j][i], examAverages[i]) == "(D)")
			{
				numD = ++numD;
			}
			else if (calculateGrade(studentScores[j][i], examAverages[i]) == "(E)")
			{
				numE = ++numE;
			}
		}
		outFS << setw(NUMBER_WIDTH) << right;
		outFS << numA << "(A)";
		outFS << setw(NUMBER_WIDTH) << right;
		outFS << numB << "(B)";
		outFS << setw(NUMBER_WIDTH) << right;
		outFS << numC << "(C)";
		outFS << setw(NUMBER_WIDTH) << right;
		outFS << numD << "(D)";
		outFS << setw(NUMBER_WIDTH) << right;
		outFS << numE << "(E)" << endl;
	}

	// Outputting the students' names and average score of all their taken exams, along with their letter grade in comparison to the class average
	outFS << "Student Final Grades:" << endl;
	for (int i = 0; i < numStudents; ++i)
	{
		double tempAverage = 0.0;
		outFS << setw(NAME_WIDTH) << right << studentNames[i] << "  ";

		for (int j = 0; j < numExams; ++j)
		{
			tempAverage = tempAverage + studentScores[i][j];
		}

		tempAverage = tempAverage / numExams;

		outFS << tempAverage << calculateGrade(tempAverage, classAverage) << endl;
	}

	outFS << setprecision(DECIMAL_LENGTH) << "Class Average Score = " << classAverage;

	delete[] examAverages;
	delete[] studentNames;
	for (int i = 0; i < numStudents; ++i)
	{
		delete[] studentScores[i];
	}
	delete[] studentScores;

	return 0;
}

