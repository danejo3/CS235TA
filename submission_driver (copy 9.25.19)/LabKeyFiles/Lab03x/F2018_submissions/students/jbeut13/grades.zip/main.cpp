#include <iostream>
#include <cmath>
#include <iomanip>
#include <string>
#include <sstream> 
#include <fstream>
using namespace std;

int main(int argc, char *argv[]) {
	if (argc < 3)
	{
		cerr << "Please provide name of input and output files";
		system("PAUSE");
		return 1;
	}
	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);
	if (!in)
	{
		cerr << "Unable to open " << argv[1] << " for input";
		system("PAUSE");
		return 2;
	}
	cout << "Output file: " << argv[2] << endl;
	ostream& out = (argc > 2) ? *(new ofstream(argv[2])) : cout;

	if (!out)
	{
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		system("PAUSE");
		return 3;
	}
	//read number of students and exams
	int num_students;
	int num_exams;
	in >> num_students >> num_exams;
	// Skip the rest of the line
	in.ignore(std::numeric_limits<int>::max(), '\n');
	//cout << num_students << " " << num_exams << endl;
	//out << num_students << " " << num_exams << endl;

	//create 2d dynamically allocated array of exam scores
	int **exam_scores = new int*[num_students];
	for (int i = 0; i < num_students; ++i)
	{
		exam_scores[i] = new int[num_exams];
	}

	int read_score;
	int sum_class_scores = 0;
	int sum_student_scores = 0;
	double class_avg_grade;
	string line;
	string first_name;
	string last_name;
	string full_name;

	//create dynamic array to hold student final scores
	double* student_final_grades = NULL;
	student_final_grades = new double[num_students];

	//create dynamic array to hold student names
	string* student_names = NULL;
	student_names = new string[num_students];

	size_t p = 0;
	cout << "Student Scores:" << endl;
	out << "Student Scores:" << endl;

	//fill student names, 2d student exam scores, and student final grades arrays 
	//and generate student and class average grades
	for (int i = 0; i < num_students; ++i)
	{
		in >> first_name >> last_name;
		student_names[i] = first_name + " " + last_name;
		cout << first_name << " " << last_name << " ";
		out << first_name << " " << last_name << " ";
		getline(in, line);
		istringstream iss(line);
		sum_student_scores = 0;

		for (int j = 0; j < num_exams; ++j)
		{
			iss >> read_score;
			cout << read_score << " ";
			out << read_score << " ";
			exam_scores[i][j] = read_score;
			sum_class_scores += read_score;
			sum_student_scores += read_score;
		}
		student_final_grades[i] = sum_student_scores / (double)num_exams;
		cout << endl;
		out << endl;
	}
	class_avg_grade = sum_class_scores / ((double)num_students * double(num_exams));

	double sum_scores_exam;
	double avg_score_exam;
	//create dynamic array to hold an average score for each exam
	double* exam_avg_scores = NULL;
	exam_avg_scores = new double[num_exams];

	cout << "Exam Averages:" << endl;
	out << "Exam Averages:" << endl;

	//generate average score for each exam and store that score in exam_avg_scores array
	for (int i = 0; i < num_exams; ++i)
	{
		sum_scores_exam = 0.0;
		avg_score_exam = 0.0;
		for (int j = 0; j < num_students; ++j)
		{
			sum_scores_exam += exam_scores[j][i];
		}
		avg_score_exam = sum_scores_exam / (double)num_students;
		cout << "Exam " << i + 1 << " Average = " << setprecision(1) << fixed << avg_score_exam << endl;
		out << "Exam " << i + 1 << " Average = " << setprecision(1) << fixed << avg_score_exam << endl;
		exam_avg_scores[i] = avg_score_exam;
		//cout << avg_score_exam << endl; 
		//cout << exam_avg_scores[i] << endl;
	}

	//create 2d dynamically allocated array student_letter_grades[exam][student]
	string **student_letter_grades = new string*[num_exams];
	for (int i = 0; i < num_exams; ++i)
	{
		student_letter_grades[i] = new string[num_students];
	}

	cout << "Student Exam Grades:" << endl;
	out << "Student Exam Grades:" << endl;

	//fill exam letter grades array with letter grades based on student exam grades
	string calculated_letter;
	for (int i = 0; i < num_students; ++i)
	{
		cout << student_names[i] << " ";
		out << student_names[i] << " ";
		for (int j = 0; j < num_exams; ++j)
		{
			double student_diff_avg = exam_scores[i][j] - exam_avg_scores[j];
			if (abs(student_diff_avg) <= 5)
			{
				calculated_letter = "C";
			}
			else if (abs(student_diff_avg) <= 15)
			{
				if (student_diff_avg > 0)
				{
					calculated_letter = "B";
				}
				else
				{
					calculated_letter = "D";
				}
			}
			else
			{
				if (student_diff_avg > 0)
				{
					calculated_letter = "A";
				}
				else
				{
					calculated_letter = "E";
				}
			}
			student_letter_grades[j][i] = calculated_letter;
			cout << exam_scores[i][j] << "(" << calculated_letter << ") ";
			out << exam_scores[i][j] << "(" << calculated_letter << ") ";
		}
		cout << endl;
		out << endl;
	}

	int a_counter;
	int b_counter;
	int c_counter;
	int d_counter;
	int e_counter;

	cout << "Exam Grades:" << endl;
	out << "Exam Grades:" << endl;

	//create 2d dynamically allocated array of exam scores
	int **letter_count_by_exam = new int*[num_exams];
	for (int i = 0; i < num_exams; ++i)
	{
		letter_count_by_exam[i] = new int[5];
	}

	for (int i = 0; i < num_exams; ++i)
	{
		a_counter = 0;
		b_counter = 0;
		c_counter = 0;
		d_counter = 0;
		e_counter = 0;
		cout << "Exam " << i+1 << " ";
		out << "Exam " << i+1 << " ";
		for (int j = 0; j < num_students; ++j)
		{
			if (student_letter_grades[i][j] == "A")
			{
				a_counter++;
			}
			else if (student_letter_grades[i][j] == "B")
			{
				b_counter++;
			}
			else if (student_letter_grades[i][j] == "C")
			{
				c_counter++;
			}
			else if (student_letter_grades[i][j] == "D")
			{
				d_counter++;
			}
			else if (student_letter_grades[i][j] == "E")
			{
				e_counter++;
			}
		}
		letter_count_by_exam[i][0] = a_counter;
		letter_count_by_exam[i][1] = b_counter;
		letter_count_by_exam[i][2] = c_counter;
		letter_count_by_exam[i][3] = d_counter;
		letter_count_by_exam[i][4] = e_counter;
		cout << a_counter << "(A) "
			<< b_counter << "(B) "
			<< c_counter << "(C) "
			<< d_counter << "(D) "
			<< e_counter << "(E) " << endl;
		out << a_counter << "(A) "
			<< b_counter << "(B) "
			<< c_counter << "(C) "
			<< d_counter << "(D) "
			<< e_counter << "(E) " << endl;
	}

	string calculated_final_letter;

	cout << "Student final grades:" << endl;
	out << "Student final grades:" << endl;

	for (int i = 0; i < num_students; i++)
	{
		double student_final_diff_avg = student_final_grades[i] - class_avg_grade;
		if (abs(student_final_diff_avg) <= 5)
		{
			calculated_final_letter = "C";
		}
		else if (abs(student_final_diff_avg) <= 15)
		{
			if (student_final_diff_avg > 0)
			{
				calculated_final_letter = "B";
			}
			else
			{
				calculated_final_letter = "D";
			}
		}
		else
		{
			if (student_final_diff_avg > 0)
			{
				calculated_final_letter = "A";
			}
			else
			{
				calculated_final_letter = "E";
			}
		}

		cout << student_names[i] << " " << student_final_grades[i] << "(" << calculated_final_letter << ")" << endl;
		out << student_names[i] << " " << student_final_grades[i] << "(" << calculated_final_letter << ")" << endl;
	}

	cout << "Class Average Score: " << class_avg_grade << endl;
	out << "Class Average Score: " << class_avg_grade << endl;

	//deallocate memory
	for (int i = 0; i < num_students; ++i)
	{
		delete[] exam_scores[i];
	}

	for (int i = 0; i < num_exams; ++i)
	{
		delete[] student_letter_grades[i];
	}

	for (int i = 0; i < num_exams; ++i)
	{
		delete[] letter_count_by_exam[i];
	}

	delete[] exam_scores;
	delete[] exam_avg_scores;
	delete[] student_names;
	delete[] student_final_grades;

	if (&out != &cout) delete(&out);
   	in.close();
	system("PAUSE");
	return 0;

}