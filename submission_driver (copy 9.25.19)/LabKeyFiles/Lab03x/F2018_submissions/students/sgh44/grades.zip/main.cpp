#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

// Finds the average score, given an array of int.
double averageScore(const int num_elements, int **scoreTable, const string type, int bookmark) {
	// Bookmark holds the row or column so we can iterate over it
	int length;
	double total = 0;

	if (type == "student") {
		for (length = 0; length < num_elements; ++length) {
			total = total + scoreTable[bookmark][length];
		}
	}
	else if (type == "exam") {
		for (length = 0; length < num_elements; ++length) {
			total = total + scoreTable[length][bookmark];
		}
	}

	double average = total / length;

	return average;
}

char compareGrade(double examAverage, double studentScore) {
	if (abs(studentScore - examAverage) <= 5) {
		return 'C';
	}
	else if (abs(studentScore - examAverage) <= 15) {
		if ((studentScore - examAverage) <= -5) {
			return 'D';
		}
		else if (abs(studentScore - examAverage) >= 5) {
			return 'B';
		}
	}
	else if (abs(studentScore - examAverage) > 15) {
		if ((studentScore - examAverage) <= -5) {
			return 'E';
		}
		else if (abs(studentScore - examAverage) >= 5) {
			return 'A';
		}
	}
	else {
		return 'F';
	}
}

int main(int argc, char* argv[]) {
	// Check for memory leaks, precious
	VS_MEM_CHECK

	//Set input and output streams, check for errors.
	if (argc < 3) {
		cerr << "Please provide name of input and output files";
		return 1;
	}

	cout << "Input file: " << argv[1] << endl;
	ifstream in(argv[1]);

	if (!in) {
		cerr << "Unable to open " << argv[1] << " for input";
		return 2;
	}

	cout << "Output file: " << argv[2] << endl;
	ofstream out(argv[2]);

	if (!out) {
		in.close();
		cerr << "Unable to open " << argv[2] << " for output";
		return 3;
	}

	// Read in the number of students and of exams.
	int num_students;
	int num_exams;
	in >> num_students >> num_exams;

	in.ignore(numeric_limits<int>::max(), '\n');

	// Initialize the list of students.
	string *studentList;
	studentList = new string[num_students];

	// Initialize the table of scores.
	int **scoreTable = new int*[num_students];
	for (int i = 0; i < num_students; ++i) {
		scoreTable[i] = new int[num_exams];
	}

	// Take each line, put the student names in a string array, and the scores into a 2D array.
	for (int i = 0; i < num_students; ++i) {
		string line;
		getline(in, line);
		size_t p = 0;
		string studentName;

		// Reads characters from istream until a number, the first score, is reached.
		while (!isdigit(line[p])) {
			studentName.push_back(line[p]);
			++p;	// line[p] is the first digit
		}

		studentList[i] = studentName;

		// Reads scores from the remainder of the line, puts them in the table.
		string scores = line.substr(p);
		istringstream iss(scores);
		int n;
		int j = 0;
		while (iss >> n) {
			scoreTable[i][j] = n;
			++j;
		}
	}

	// Output this table, with the names of the students
	out << "Student Scores:" << endl;
	for (int i = 0; i < num_students; ++i) {
		out << setw(20) << studentList[i] << " ";
		for (int j = 0; j < num_exams; ++j) {
			out << fixed << setprecision(0) << setw(6) << scoreTable[i][j] << " ";
		}
		out << endl;
	}
	
	// Calculate and output the average scores for each exam
	double* examAverages; 
	examAverages = new double[num_exams];

	out << "Exam Averages: " << endl;
	for (int i = 0; i < num_exams; ++i) {
		examAverages[i] = averageScore(num_students, scoreTable, "exam", i);
	}
	for (int i = 0; i < num_exams; ++i) {
		out << setw(10) << fixed << setprecision(1) << "Exam " << i + 1 << " Average = ";
		out << examAverages[i] << endl;
	}

	// Compare each student's score with the exam average to get letter grades
	char** gradeTable = new char*[num_students];
	for (int i = 0; i < num_students; ++i) {
		gradeTable[i] = new char[num_exams];
	}

	// Generate a table of letter grades
	for (int i = 0; i < num_students; ++i) {
		for (int j = 0; j < num_exams; ++j) {
			gradeTable[i][j] = compareGrade(examAverages[j], scoreTable[i][j]);
		}
	}

	// Output this table, with the names of the students
	out << "Student Exam Grades: " << endl;
	for (int i = 0; i < num_students; ++i) {
		out << setw(20) << studentList[i] << " ";
		for (int j = 0; j < num_exams; ++j) {
			out << fixed << setprecision(0) << setw(6) << scoreTable[i][j] << "(" << gradeTable[i][j] << ") ";
		}
		out << endl;
	}

	// Count and output each type of letter grade in the table
	out << "Exam Grades: " << endl;
	int as, bs, cs, ds, es;
	for (int j = 0; j < num_exams; ++j) {
		as = 0; 
		bs = 0; 
		cs = 0; 
		ds = 0;
		es = 0;
		for (int i = 0; i < num_students; ++i) {
			if (gradeTable[i][j] == 'A') {
				++as;
			}
			else if (gradeTable[i][j] == 'B') {
				++bs;
			}
			else if (gradeTable[i][j] == 'C') {
				++cs;
			}
			else if (gradeTable[i][j] == 'D') {
				++ds;
			}
			else if (gradeTable[i][j] == 'E') {
				++es;
			}
		}
		out << setw(10) << "Exam " << j + 1 << " " << as << "(A) " << bs << "(B) ";
		out << cs << "(C) " << ds << "(D) " << es << "(E) " << endl;
	}

	// Calculate student final scores
	double* studentAverages = new double[num_students]; 
	for (int i = 0; i < num_students; ++i) {
		studentAverages[i] = averageScore(num_exams, scoreTable, "student", i);
	}

	// Calculate class average
	double classAverage;
	double total = 0;
	int i = 0;
	for (i; i < num_students; ++i) {
		total = total + studentAverages[i];
	}

	classAverage = total / i;

	// Output final scores
	out << fixed << setprecision(1) << "Student Final Grades : " << endl;
	for (int i = 0; i < num_students; ++i) {
		out << setw(20) << studentList[i] << " " << studentAverages[i] << "(";
		out << compareGrade(classAverage, studentAverages[i]) << ")" << endl;
	}
	out << "Class Average Score = " << classAverage;

	// Deallocate memory for arrays
	for (int i = 0; i < num_students; ++i)
	{
		delete[] scoreTable[i];
		delete[] gradeTable[i];
	}
	delete[] scoreTable;
	delete[] gradeTable;
	delete[] studentAverages;
	delete[] studentList;
	delete[] examAverages;

	return 0;
}