#ifdef _MSC_VER
#define _CRTDBG_MAP_ALLOC  
#include <crtdbg.h>
#define VS_MEM_CHECK _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#else
#define VS_MEM_CHECK
#endif

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

void CreateTables(ifstream& in, const int& numStudents, const int& numExams, string* studentNames, int** studentGrades);
void PrintTables(const int& numStudents, const int& numExams, string* studentNames, int** studentGrades, ofstream& out);
void FindExamAverages(const int& numStudents, const int& numExams, float* gradeAverages, int** studentGrades);
void CalculateStudentGrade(const int& numStudents, const int& numExams, string* studentNames, int** studentGrades, float* gradeAverages, ofstream& out);
void NumGradesForEachExam(const int& numStudents, const int& numExams, string* studentNames, int** studentGrades, float* gradeAverages, ofstream& out);

int main(int argc, char* argv[]) {
	VS_MEM_CHECK               // enable memory leak check

	int numStudents;
	int numExams;

	//check if input file exists
	ifstream in(argv[1]);
	if (!in) {
		cerr << "Unable to open " << argv[1] << " for input.";
		exit(0);
	}

	//check if output file exists
	ofstream out(argv[2]);
	if (!out) {
		in.close();
		cerr << "Unable to open " << argv[2] << " for output.";
		exit(0);
	}

	//gets first line of code which should contain number of students and grades
	in >> numStudents;
	in >> numExams;
	in.ignore(std::numeric_limits<int>::max(), '\n');
	
	//create and initialize arrays that contain student names and student exam scores
	string* studentNames = new string[numStudents];
	int** studentGrades = new int*[numStudents];
	CreateTables(in, numStudents, numExams, studentNames, studentGrades);

	//prints out the student tables for testing
	PrintTables(numStudents, numExams, studentNames, studentGrades, out);

	//create and initialize an array with all the exam averages
	float* gradeAverages = new float[numExams];
	FindExamAverages(numStudents, numExams, gradeAverages, studentGrades);

	//prints out exam averages
	out << "Exam Averages: " << endl;
	for (int i = 0; i < numExams; i++) {
		out << setprecision(1) << setw(10) << "Exam " << i + 1 << " Average = " << setw(6) << gradeAverages[i] << endl;
	}

	//caculate and print out the normalised grades for each exam of each student
	CalculateStudentGrade(numStudents, numExams, studentNames, studentGrades, gradeAverages, out);

	//print out the number of students that got a particular grade 
	NumGradesForEachExam(numStudents, numExams, studentNames, studentGrades, gradeAverages, out);

	//delete memory allocation
	for (int i = 0; i < numStudents; i++)
	{
		delete [] studentGrades[i];
	}
	delete [] studentGrades;
	delete [] studentNames;
	delete [] gradeAverages;
	return 0;
}

void CreateTables(ifstream& in, const int& numStudents, const int& numExams, string* studentNames, int** studentGrades) {
	string studentName;
	string studentNameTemp;
	for (int i = 0; i < numStudents; i++) {
		studentGrades[i] = new int[numExams];
		in >> studentName >> studentNameTemp;
		studentName = studentName + " " + studentNameTemp;
		studentNames[i] = studentName;
		for (int j = 0; j < numExams; j++) {
			in >> studentGrades[i][j];
		}
	}
}

void PrintTables(const int& numStudents, const int& numExams, string* studentNames, int** studentGrades, ofstream& out) {
	out << "Student Scores: " << endl;
	for (int i = 0; i < numStudents; i++) {
		out << setw(20) << studentNames[i] << " ";
		for (int j = 0; j < numExams; j++) {
			out << fixed << setprecision(0) << setw(6) << studentGrades[i][j] << " ";
		}
		out << endl;
	}
}

void FindExamAverages(const int& numStudents, const int& numExams, float* gradeAverages, int** studentGrades) {
	float gradeAverage = 0;
	for (int i = 0; i < numExams; i++) {
		for (int j = 0; j < numStudents; j++) {
			gradeAverage += studentGrades[j][i];
		}
		gradeAverage /= numStudents;
		gradeAverages[i] = gradeAverage;
		gradeAverage = 0;
	}
}

void CalculateStudentGrade(const int& numStudents, const int& numExams, string* studentNames, int** studentGrades, float* gradeAverages, ofstream& out) {
	int benchmark1 = 5;
	int benchmark2 = 15;
	out << "Student Exam Grades:" << endl;
	for (int i = 0; i < numStudents; i++) {
		out << setw(20) << studentNames[i] << " ";
		for (int j = 0; j < numExams; j++) {
			if (studentGrades[i][j] <= gradeAverages[j] - benchmark2) {
				out << fixed << setprecision(0) << setw(6) << studentGrades[i][j] << "(E)";
			}
			else if (studentGrades[i][j] > gradeAverages[j] - benchmark2 && studentGrades[i][j] < gradeAverages[j] - benchmark1) {
				out << fixed << setprecision(0) << setw(6) << studentGrades[i][j] << "(D)";
			}
			else if (studentGrades[i][j] >= gradeAverages[j] - benchmark1 && studentGrades[i][j] <= gradeAverages[j] + benchmark1) {
				out << fixed << setprecision(0) << setw(6) << studentGrades[i][j] << "(C)";
			}
			else if (studentGrades[i][j] > gradeAverages[j] + benchmark1 && studentGrades[i][j] < gradeAverages[j] + benchmark2) {
				out << fixed << setprecision(0) << setw(6) << studentGrades[i][j] << "(B)";
			}
			else if (studentGrades[i][j] >= gradeAverages[j] + benchmark2) {
				out << fixed << setprecision(0) << setw(6) << studentGrades[i][j] << "(A)";
			}
			else {
				cerr << "EVERYBODY PANIC";
				exit(1);
			}
		}
		out << endl;
	}
}

void NumGradesForEachExam(const int& numStudents, const int& numExams, string* studentNames, int** studentGrades, float* gradeAverages, ofstream& out) {
	char start = 65;
	int benchmark1 = 5;
	int benchmark2 = 15;
	int numGrades[5];

	out << "Exam Grades: " << endl;
	for (int i = 0; i < numExams; i++) {
		//resets all the number of Grades to 0
		for (int i = 0; i < 5; i++) {
			numGrades[i] = 0;
		}

		out << setw(10) << "Exam " << i + 1;
		for (int j = 0; j < numStudents; j++) {
			if (studentGrades[j][i] <= gradeAverages[i] - benchmark2) {
				numGrades[4] += 1;
			}
			else if (studentGrades[j][i] > gradeAverages[i] - benchmark2 && studentGrades[j][i] < gradeAverages[i] - benchmark1) {
				numGrades[3] += 1;
			}
			else if (studentGrades[j][i] >= gradeAverages[i] - benchmark1 && studentGrades[j][i] <= gradeAverages[i] + benchmark1) {
				numGrades[2] += 1;
			}
			else if (studentGrades[j][i] > gradeAverages[i] + benchmark1 && studentGrades[j][i] < gradeAverages[i] + benchmark2) {
				numGrades[1] += 1;
			}
			else if (studentGrades[j][i] >= gradeAverages[i] + benchmark2) {
				numGrades[0] += 1;
			}
			else {
				cerr << "EVERYBODY PANIC";
				exit(1);
			}
		}
		for (int j = 0; j < 5; j++) {
			out << setw(5) << numGrades[j] << "(" << char(start + j) << ")";
		}
		out << endl;
	}
//	delete numGrades;
}