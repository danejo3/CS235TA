#ifndef STUDENT
#define STUDENT

#include <vector>
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

class Student
{
public:
	Student(string name, vector<float> scores);
	string GetName() { return name; };
	float GetScore(int examNum) { return scores.at(examNum); };
	void AddGrade(char grade) { letterGrades.push_back(grade); };
	friend ostream& operator<< (ostream& os, Student& student) 
	{		
		os << stringForm(student);
		return os;
	};

private:
	string name;
	vector<float> scores;
	vector<char> letterGrades;
	static string stringForm(Student& student);
};
#endif