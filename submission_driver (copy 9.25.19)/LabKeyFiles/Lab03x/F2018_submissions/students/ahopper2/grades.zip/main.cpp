/*
Ashley Hopper
ahopper2

Lab 1 - Grades
Description: Reads student scores from a file and calculates exam averages and 
student letter grades. Outputs student scores with letter grades to a file

*/
#include <iomanip>
#include <fstream>
#include <math.h>
#include "Student.h"
using namespace std;

// how close to the average a student's score has to be for them to get a C
const int GRADE_THRESHOLD_C = 5;
// how close to the average a student's score has to be for them to get a B or a D
const int GRADE_THRESHOLD_B_D = 10;
// Any score outside the B/D threshold is either an A or an E

static char FindLetterGrade(float average, float score)
{
	// Find the difference between the student's score and the average score
	float difference = score - average;

	// Determine the letter grade
	if (fabs(difference) < GRADE_THRESHOLD_C)
	{
		return 'C';
	}
	else if (fabs(difference) < GRADE_THRESHOLD_B_D)
	{
		if (difference > 0)
		{
			return 'B';
		}
		else
		{
			return 'D';
		}
	}
	else
	{
		if (difference > 0)
		{
			return 'A';
		}
		else
		{
			return 'E';
		}
	}
}

int main(int argc, char* argv[])
{
	// information gained from the file
	int numStudents;
	int numExams;
	
	// All the students and their scores
	vector<Student> students;

	// file to read from
	string inFilename = argv[1];
	ifstream in(inFilename);

	// checks if the file was opened
	if (in.is_open())
	{
		// The first line of the file indicates how many 
		// students there are and how many exams there are
		string line;
		getline(in, line);
		stringstream lineStream(line);
		lineStream >> numStudents;
		lineStream >> numExams;

		// get a new line for each student and store the info
		while (getline(in, line))
		{
			// gets a string stream version of the first line
			lineStream.clear();
			lineStream.str(line);

			// first two bits are the name
			string firstName = "";
			lineStream >> firstName;
			string lastName = "";
			lineStream >> lastName;
			string name = firstName + " " + lastName;
			
			// Is it reading the name? --> have to clear the stream first
			
			// get student.h file to work

			vector<float> examScores;

			// all other bits are the exam scores
			for (int exam = 0; exam < numExams; exam++)
			{
				// each score is added to the list of scores
				float score;
				lineStream >> score;
				examScores.push_back(score);
			}
			Student newStudent(name, examScores);
			students.push_back(newStudent);
		}

		// close the reader
		in.close();
	}
	else
	{
		cout << "Could not open file " << inFilename << endl;
	}

	// find the average score for each exam
	vector<float> examAverages;
	for (int exam = 0; exam < numExams; exam++)
	{
		float examSum = 0;
		for (int student = 0; student < numStudents; student++)
		{
			examSum += students.at(student).GetScore(exam);
		}
		float examAvg = (examSum / numStudents);
		examAverages.push_back(examAvg);
	}


	// file to output
	string outFilename = argv[2];
	ofstream out(outFilename);
	
	// checks that the file has opened
	if (out.is_open())
	{
		// for each student
		for (int student = 0; student < numStudents; student++)
		{
			// find the letter grade for the exam
			for (int exam = 0; exam < numExams; exam++)
			{
				students.at(student).AddGrade(FindLetterGrade(examAverages[exam], students[student].GetScore(exam)));
			}

			// output the student's scores and grades to the output file
			out << students.at(student) << endl;
		}
		out.close();
	}
	else
	{
		cout << "Could not open file " << outFilename << endl;
	}

	return 0;
}