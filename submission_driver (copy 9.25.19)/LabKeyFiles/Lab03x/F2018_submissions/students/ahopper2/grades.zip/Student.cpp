#include "Student.h"

Student::Student(string name, vector<float> scores)
{
	this->name = name;
	this->scores = scores;
	//this->letterGrades = vector<char>() {};
}

// returns the string format of Student
string Student::stringForm(Student& student)
{
	int examNum = student.scores.size();
	stringstream stringBuilder(student.name);
	for (int i = 0; i < examNum; i++)
	{
		stringBuilder << " " << student.scores.at(i) << "(" << student.letterGrades.at(i) << ")";
	}
	return stringBuilder.str();
}