/*Ryan Worsham, Section 3
Test Case:
Input:
	6 8
	Cody Coder  84 100 100 70 100 80 100 65
	Harry Houdini  77 68 65 100 96 100 86 100
	Harry Potter  100 100 95 91 100 70 71 72
	Mad Mulligun  88 96 100 90 93 100 100 100
	George Washington  100 72 100 76 82 71 82 98
	Abraham Lincoln  93 88 100 100 99 77 76 93
Expected output:
	Student Scores:
			  Cody Coder     84   100   100    70   100    80   100    65
		   Harry Houdini     77    68    65   100    96   100    86   100
			Harry Potter    100   100    95    91   100    70    71    72
			Mad Mulligun     88    96   100    90    93   100   100   100
	   George Washington    100    72   100    76    82    71    82    98
		 Abraham Lincoln     93    88   100   100    99    77    76    93
	Exam Averages:
		Exam 1 Average =   90.3
		Exam 2 Average =   87.3
		Exam 3 Average =   93.3
		Exam 4 Average =   87.8
		Exam 5 Average =   95.0
		Exam 6 Average =   83.0
		Exam 7 Average =   85.8
		Exam 8 Average =   88.0
	Student Exam Grades:
			  Cody Coder    84(D)   100(B)   100(B)    70(E)   100(C)    80(C)   100(B)    65(E)
		   Harry Houdini    77(D)    68(E)    65(E)   100(B)    96(C)   100(A)    86(C)   100(B)
			Harry Potter   100(B)   100(B)    95(C)    91(C)   100(C)    70(D)    71(D)    72(E)
			Mad Mulligun    88(C)    96(B)   100(B)    90(C)    93(C)   100(A)   100(B)   100(B)
	   George Washington   100(B)    72(E)   100(B)    76(D)    82(D)    71(D)    82(C)    98(B)
		 Abraham Lincoln    93(C)    88(C)   100(B)   100(B)    99(C)    77(D)    76(D)    93(C)
	Exam Grades:
		Exam  1    0(A)    2(B)    2(C)    2(D)    0(E)
		Exam  2    0(A)    3(B)    1(C)    0(D)    2(E)
		Exam  3    0(A)    4(B)    1(C)    0(D)    1(E)
		Exam  4    0(A)    2(B)    2(C)    1(D)    1(E)
		Exam  5    0(A)    0(B)    5(C)    1(D)    0(E)
		Exam  6    2(A)    0(B)    1(C)    3(D)    0(E)
		Exam  7    0(A)    2(B)    2(C)    2(D)    0(E)
		Exam  8    0(A)    3(B)    1(C)    0(D)    2(E)
	Student Final Grades:
			  Cody Coder  87.4(C)
		   Harry Houdini  86.5(C)
			Harry Potter  87.4(C)
			Mad Mulligun  95.9(B)
	   George Washington  85.1(C)
		 Abraham Lincoln  90.8(C)
	Class Average Score = 88.8
*/

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>
using namespace std;

char GradeCalculator(double examScore, double examAvg) //Determines the letter grade based off the average
{
	const int RANGE_ABOVE_C = 5;
	const int RANGE_BELOW_C = -5;
	const int RANGE_ABOVE_B = 15;
	const int RANGE_BELOW_D = -15;

	double valueFromAvg = 0.0;
	valueFromAvg = examScore - examAvg;

	if (valueFromAvg >= RANGE_BELOW_C && valueFromAvg <= RANGE_ABOVE_C)
	{
		return 'C';
	}
	else if (valueFromAvg > RANGE_ABOVE_C && valueFromAvg < RANGE_ABOVE_B)
	{
		return 'B';
	}
	else if (valueFromAvg < RANGE_BELOW_C && valueFromAvg > RANGE_BELOW_D)
	{
		return 'D';
	}
	else if (valueFromAvg >= RANGE_ABOVE_B)
	{
		return 'A';
	}
	else
	{
		return 'E';
	}
}

int main(int argc, char** argV)
{
	int numStudents = 0;
	int numExams = 0;

	ifstream in(argV[1]);
	ofstream out(argV[2]);

	if (in.is_open() && out.is_open())
	{
		/*--------------------------------------------------------------------------------------------------
			BELOW: Gets # of students and # of exams from file, declares pointers and allocates memory
		----------------------------------------------------------------------------------------------------*/
		in >> numStudents; //store # students
		in >> numExams; //store # exams


		string *studentLastName = NULL;
		studentLastName = new string[numStudents];


		string *studentNames = NULL; //declare pointer to string
		studentNames = new string[numStudents]; //allocate numStudents strings

		double **examScores = NULL; //declare pointer to pointer to double
		examScores = new double*[numStudents]; //allocates numStudents pointers to double
		for (int j = 0; j < numStudents; ++j)
		{
			examScores[j] = new double[numExams]; //allocates numExams doubles
		}

		/*--------------------------------------------------------------------------------------------
			BELOW: Gets information from input file and outputs to the output file
		----------------------------------------------------------------------------------------------*/

		out << "Student Scores:" << endl;
		const int WIDTH_TEN = 10;
		const int WIDTH_FIVE = 5;
		const int WIDTH_NAMES = 20;
		while (!in.eof())
		{
			for (int i = 0; i < numStudents; ++i)
			{
				in >> studentNames[i]; //input from file
				in >> studentLastName[i]; //input from file
				
				ostringstream fullName;
				fullName.str();
				fullName << studentNames[i] << " " << studentLastName[i];

				out << right << setw(WIDTH_NAMES) << fullName.str(); //output to file

				for (int j = 0; j < numExams; ++j)
				{
					in >> examScores[i][j];
					out << setw(WIDTH_FIVE) << examScores[i][j]; //output to file
				}
				out << endl;
			}
		}

		/*--------------------------------------------------------------------------------------
			BELOW: Determines average and outputs to file 
		----------------------------------------------------------------------------------------*/

		double *examAvg = NULL; //Declare pointer to double
		examAvg = new double[numExams]; //allocate numExam pointers to double

		for (int j = 0; j < numExams; ++j)
		{
			double sumScores = 0.0;

			for (int i = 0; i < numStudents; ++i)
			{
				sumScores += examScores[i][j];
			}

			examAvg[j] = sumScores / numStudents; //Determines average exam scores
		}

		out << "Exam Averages:" << endl;
		const int PRECISION_ONE = 1;
		for (int i = 0; i < numExams; ++i)
		{
			out << right << setw(WIDTH_TEN) << "Exam " << i + 1 << " Average = ";
			out << fixed << setprecision(PRECISION_ONE) << examAvg[i] << endl;
		}

		/*---------------------------------------------------------------------------------------
			BELOW: Determines students exam letter grade and outputs to file
		-----------------------------------------------------------------------------------------*/

		out << "Student Exam Grades:" << endl;
		for (int i = 0; i < numStudents; ++i)
		{
			ostringstream fullName;
			fullName.str();
			fullName << studentNames[i] << " " << studentLastName[i];

			out << right << setw(WIDTH_NAMES) << fullName.str() << " ";
			for (int j = 0; j < numExams; ++j)
			{
				out << right << setw(WIDTH_FIVE) << setprecision(0) << examScores[i][j] << "(";
				out << GradeCalculator(examScores[i][j], examAvg[j]) << ") ";
			}
			out << endl;
		}

		/*-------------------------------------------------------------------------------------
			BELOW: Outputs # of letter grades for each exam
		---------------------------------------------------------------------------------------*/

		out << "Exam Grades:" << endl;	
		char grade;
		for (int i = 0; i < numExams; ++i)
		{
			out << right << setw(WIDTH_TEN) << "Exam " << i + 1;

			int numA_Returned = 0;
			int numB_Returned = 0;
			int numC_Returned = 0;
			int numD_Returned = 0;
			int numE_Returned = 0;

			for (int j = 0; j < numStudents; ++j)
			{
				grade = GradeCalculator(examScores[j][i], examAvg[i]);
				if (grade == 'A')
				{
					++numA_Returned;
				}
				else if (grade == 'B')
				{
					++numB_Returned;
				}
				else if (grade == 'C')
				{
					++numC_Returned;
				}
				else if (grade == 'D')
				{
					++numD_Returned;
				}
				else
				{
					++numE_Returned;
				}
			}
			
			out << right << setw(WIDTH_FIVE) << numA_Returned << "(A) ";
			out << right << setw(WIDTH_FIVE) << numB_Returned << "(B) ";
			out << right << setw(WIDTH_FIVE) << numC_Returned << "(C) ";
			out << right << setw(WIDTH_FIVE) << numD_Returned << "(D) ";
			out << right << setw(WIDTH_FIVE) << numE_Returned << "(E)";

			out << endl;
		}

		/*-------------------------------------------------------------------------------------
			BELOW: Determines students final grade
		---------------------------------------------------------------------------------------*/
		
		double *studentAvg = NULL;
		studentAvg = new double[numStudents];

		for (int i = 0; i < numStudents; ++i)
		{
			double sumScores = 0;

			for (int j = 0; j < numExams; ++j)
			{
				sumScores += examScores[i][j];
			}
			studentAvg[i] = sumScores / numExams;			
		}

		double sumStudentScores = 0.0;
		double classAvg = 0.0;

		for (int i = 0; i < numStudents; ++i)
		{
			sumStudentScores += studentAvg[i];
		}
		classAvg = sumStudentScores / numStudents;

		out << "Student Final Grades:" << endl;

		for (int i = 0; i < numStudents; ++i)
		{
			ostringstream fullName;
			fullName.str();
			fullName << studentNames[i] << " " << studentLastName[i];

			out << right << setw(WIDTH_NAMES) << fullName.str() << " ";
			out << right << setw(WIDTH_FIVE) << setprecision(PRECISION_ONE) << studentAvg[i];
			out << "(" << GradeCalculator(studentAvg[i], classAvg) << ")" << endl;
		}

		out << "Class Average Score = ";
		out << classAvg << endl;
		
		/*-------------------------------------------------------------------------------------
			BELOW: Frees memory and closes both input and output files
		---------------------------------------------------------------------------------------*/

		delete[] studentNames; //free memory pointed to by studentNames
		delete[] studentLastName; //free memory pointed to by studentLastName
		for (int i = 0; i < numStudents; ++i)
		{
			delete[] examScores[i]; //free memory pointed to by examScores
		}
		delete[] examScores; //free memory pointed to by pointer 
		delete[] examAvg; //free memory pointed to by examAvg
		delete[] studentAvg; //free memory pointed to by studentAvg

		in.close();
		out.close();
	}
	else cout << "Error";

	return 0;
}